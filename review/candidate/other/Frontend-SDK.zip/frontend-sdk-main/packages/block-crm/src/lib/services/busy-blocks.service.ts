import type { Transport, PageResult } from '@23blocks/contracts';
import { decodeOne, decodePageResult } from '@23blocks/jsonapi-codec';
import type {
  BusyBlock,
  CreateBusyBlockRequest,
  ListBusyBlocksParams,
} from '../types/busy-block.js';
import { busyBlockMapper } from '../mappers/busy-block.mapper.js';

export interface BusyBlocksService {
  /**
   * List busy blocks for a specific user with optional filtering, pagination, and sorting.
   * @param userUniqueId - The unique identifier of the user.
   * @param params - Optional filtering (status, startTime, endTime, search), pagination, and sorting.
   * @returns Paginated result containing BusyBlock objects and metadata.
   */
  list(userUniqueId: string, params?: ListBusyBlocksParams): Promise<PageResult<BusyBlock>>;

  /**
   * Create a new busy block for a user, marking a time range as unavailable.
   * @param userUniqueId - The unique identifier of the user.
   * @param data - The busy block creation payload with title, time range, all-day flag, and recurrence settings.
   * @returns The newly created BusyBlock object.
   */
  create(userUniqueId: string, data: CreateBusyBlockRequest): Promise<BusyBlock>;

  /**
   * Delete a busy block for a user, freeing up the time range.
   * @param userUniqueId - The unique identifier of the user.
   * @param uniqueId - The unique identifier of the busy block to delete.
   * @returns Resolves when the busy block has been deleted.
   */
  delete(userUniqueId: string, uniqueId: string): Promise<void>;
}

export function createBusyBlocksService(transport: Transport, _config: { apiKey: string }): BusyBlocksService {
  return {
    async list(userUniqueId: string, params?: ListBusyBlocksParams): Promise<PageResult<BusyBlock>> {
      const queryParams: Record<string, string> = {};
      if (params?.page) queryParams['page'] = String(params.page);
      if (params?.perPage) queryParams['records'] = String(params.perPage);
      if (params?.status) queryParams['status'] = params.status;
      if (params?.startTime) queryParams['start_time'] = params.startTime.toISOString();
      if (params?.endTime) queryParams['end_time'] = params.endTime.toISOString();
      if (params?.search) queryParams['search'] = params.search;
      if (params?.sortBy) queryParams['sort'] = params.sortOrder === 'desc' ? `-${params.sortBy}` : params.sortBy;

      const response = await transport.get<unknown>(`/users/${userUniqueId}/busy_blocks`, { params: queryParams });
      return decodePageResult(response, busyBlockMapper);
    },

    async create(userUniqueId: string, data: CreateBusyBlockRequest): Promise<BusyBlock> {
      const response = await transport.post<unknown>(`/users/${userUniqueId}/busy_blocks`, {
        busy_block: {
          title: data.title,
          starts_at: data.startsAt.toISOString(),
          ends_at: data.endsAt.toISOString(),
          all_day: data.allDay,
          timezone: data.timezone,
          transparency: data.transparency,
          status: data.status,
          location: data.location,
          source: data.source,
          source_id: data.sourceId,
          external_event_id: data.externalEventId,
          metadata: data.metadata,
        },
      });
      return decodeOne(response, busyBlockMapper);
    },

    async delete(userUniqueId: string, uniqueId: string): Promise<void> {
      await transport.delete(`/users/${userUniqueId}/busy_blocks/${uniqueId}`);
    },
  };
}
