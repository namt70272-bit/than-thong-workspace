export { getConfig } from './core';
