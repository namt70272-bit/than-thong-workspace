---
name: Bug report
about: Something went wrong
title: "[Bug] "
labels: bug
---

**What happened?**

**Expected behavior**

**Environment**
- OS: [e.g. Windows 11, macOS 15, Ubuntu 24]
- Node.js version: [e.g. 22.x]
- AI agent: [e.g. Claude Code, Codex, Gemini CLI]
- skill-freeze version: [e.g. 0.1.0]

**`npx skill-freeze status` output**
```
(paste here)
```
