# n8n Community Node Development Guide

Based on experience from developing n8n-nodes-serverchan.

## Project Structure Best Practices

**Essential Files:**
```
project/
├── nodes/
│   └── YourNode/
│       ├── YourNode.node.ts          # Main node implementation
│       ├── GenericFunctions.ts        # Shared utility functions
│       └── icon.svg                   # Node icon
├── credentials/
│   ├── YourApi.credentials.ts        # Credential type definition
│   └── icon.svg                       # Credential icon (same as node)
├── package.json
├── tsconfig.json
└── README.md
```

**package.json Configuration:**
```json
{
  "name": "n8n-nodes-yournode",
  "version": "1.0.0",
  "description": "n8n community node for YourService",
  "keywords": ["n8n-community-node-package", "n8n", "yourservice"],
  "license": "MIT",
  "main": "dist/nodes/YourNode/YourNode.node.js",
  "scripts": {
    "build": "tsc && npm run copy:icons",
    "copy:icons": "cp nodes/YourNode/icon.svg dist/nodes/YourNode/ && cp credentials/icon.svg dist/credentials/",
    "prepublishOnly": "npm run build"
  },
  "files": ["dist", "credentials"],
  "n8n": {
    "n8nNodesApiVersion": 1,
    "credentials": ["dist/credentials/YourApi.credentials.js"],
    "nodes": ["dist/nodes/YourNode/YourNode.node.js"]
  },
  "devDependencies": {
    "n8n-workflow": "^1.112.0",
    "typescript": "^5.0.0"
  }
}
```

## Credential System

### 1. Credential Type Definition

```typescript
export class YourApi implements ICredentialType {
  name = 'yourApi';
  displayName = 'Your API';
  documentationUrl = 'https://your-service.com/';
  icon = 'file:icon.svg' as const;  // Use 'as const' for Icon type

  properties: INodeProperties[] = [
    {
      displayName: 'Recipients Configuration (JSON)',
      name: 'recipients',
      type: 'json',
      typeOptions: { rows: 10 },
      default: '[\n  {\n    "name": "User 1",\n    "apiKey": "key123"\n  }\n]',
      description: 'Configure recipients list in JSON format',
    },
  ];

  // Credential validation test
  test: ICredentialTestRequest = {
    request: {
      method: 'POST',
      url: '=https://api.example.com/{{JSON.parse($credentials.recipients)[0].apiKey}}/test',
      body: {
        title: 'Credential Test',
        message: 'Testing API key validity',
      },
    },
  };
}
```

**Key Points:**
- Use `icon = 'file:icon.svg' as const` to satisfy TypeScript's Icon type
- `type: 'json'` for complex credential data (fixedCollection doesn't work in credentials - n8n Issue #6693)
- Implement `test` property for credential validation
- Use expression syntax `={{...}}` in test URLs to access credential values

### 2. Using Credentials in Nodes

```typescript
credentials: [
  {
    name: 'yourApi',
    required: false,  // Allow optional credentials
  },
],
```

### 3. Loading Options from Credentials

```typescript
methods = {
  loadOptions: {
    async getRecipients(this: ILoadOptionsFunctions): Promise<INodePropertyOptions[]> {
      try {
        const credentials = await this.getCredentials('yourApi');
        const recipients = JSON.parse(credentials.recipients as string);

        return recipients.map((recipient: any) => ({
          name: `${recipient.name || 'Unnamed'} (${recipient.apiKey.slice(0,8)}...)`,
          value: recipient.apiKey,
        }));
      } catch (error) {
        return [];
      }
    },
  },
};
```

## Node UI Design Patterns

### 1. Icon Configuration
- Same icon for both node and credential
- Use SVG format
- Reference with `icon: 'file:icon.svg'`
- Copy icons to dist folder in build script

### 2. Available UI Separator Types
n8n has **limited** options for visual grouping:
- `type: 'notice'` - Yellow box separator (not pretty, but functional)
- `type: 'collection'` - Best for grouping optional fields
- **No horizontal line separators available**

**Recommendation**: Use flat parameter structure with clear naming instead of separators.

### 3. Parameter Organization

```typescript
properties: [
  // Credential selector automatically appears first
  {
    displayName: 'Select from Credentials',
    name: 'selectedRecipients',
    type: 'multiOptions',
    typeOptions: { loadOptionsMethod: 'getRecipients' },
    default: [],
  },
  {
    displayName: 'Additional Items',
    name: 'manualInput',
    type: 'string',
    typeOptions: { rows: 3 },
    default: '',
  },
  {
    displayName: 'Title',
    name: 'title',
    type: 'string',
    required: true,
    default: '',
  },
  {
    displayName: 'Optional Fields',
    name: 'additionalFields',
    type: 'collection',
    placeholder: 'Add Field',
    default: {},
    options: [/* ... */],
  },
],
```

### 4. Collection Best Practices
- Use `type: 'collection'` for truly optional fields only
- Set `default: {}` for collapsible (user clicks to add)
- Set `default: { field1: '', field2: '' }` to show all fields expanded
- Collections work well for grouping, but add interaction overhead

### 5. Parameter Types
Common types:
- `string`, `number`, `boolean`
- `options`, `multiOptions` (dropdowns)
- `collection` (grouping)
- `json` (complex data)
- `notice` (separator/info)
- `dateTime`, `color`

## Node Execution Pattern

### Flexible Input Strategy (Credentials + Manual)

```typescript
async execute(this: IExecuteFunctions): Promise<INodeExecutionData[][]> {
  const items = this.getInputData();
  const returnData: INodeExecutionData[] = [];

  for (let i = 0; i < items.length; i++) {
    try {
      const targets: string[] = [];

      // 1. Get from credentials
      const selected = this.getNodeParameter('selectedRecipients', i, []) as string[];
      targets.push(...selected);

      // 2. Get from manual input
      const manual = this.getNodeParameter('manualInput', i, '') as string;
      if (manual) {
        const parsed = manual.split('\n').map(k => k.trim()).filter(k => k);
        targets.push(...parsed);
      }

      // 3. Deduplicate
      const unique = [...new Set(targets)];

      if (unique.length === 0) {
        throw new Error('At least one target required');
      }

      // Process...
      const responseData = await yourApiCall(unique);

      const executionData = this.helpers.constructExecutionMetaData(
        this.helpers.returnJsonArray(responseData),
        { itemData: { item: i } },
      );
      returnData.push(...executionData);
    } catch (error: any) {
      if (this.continueOnFail()) {
        returnData.push(this.helpers.returnJsonArray({ error: error.message })[0]);
        continue;
      }
      throw error;
    }
  }

  return [returnData];
}
```

**Key Patterns:**
- Always support both credential-based and manual input
- Deduplicate merged inputs with `[...new Set()]`
- Use `continueOnFail()` for error handling
- Use `constructExecutionMetaData()` for proper output format

## Development Workflow

### 1. Local Development

```bash
# Link to n8n
cd ~/.n8n/custom
npm link /path/to/your-node

# Watch mode
npm run dev

# Restart n8n after changes
```

### 2. Common Issues

| Issue | Solution |
|-------|----------|
| "Unrecognized node type" | Restart n8n (not a code issue) |
| Icon not showing | Check icon path, ensure copied to dist, use `as const` |
| Credential not loading | Verify `n8n.credentials` path in package.json |
| TypeScript icon error | Use `icon = 'file:icon.svg' as const` |
| fixedCollection in credentials | Use `type: 'json'` instead (known limitation) |

### 3. Build & Publish

```bash
# Build
npm run build

# Test locally
npm link

# Publish to npm
npm publish --otp=YOUR_CODE  # If 2FA enabled
```

## UI/UX Guidelines

### 1. Field Naming
- Use clear, descriptive English names
- Follow n8n conventions (Title, Content, not Message Title, Message Content)
- Group related fields logically

### 2. Descriptions
- Provide helpful descriptions for all fields
- Include format examples in placeholders
- Link to documentation with HTML: `<a href="..." target="_blank">docs</a>`

### 3. Required vs Optional
- Mark truly required fields with `required: true`
- Group optional fields in `collection` for cleaner UI
- Provide sensible defaults

### 4. International Support
- Use English for all interface text (required for n8n verified nodes)
- Provide bilingual README (English + your language)
- Keep service-specific terms in original language

## Publishing Checklist

- [ ] Version number updated in package.json
- [ ] README reflects current functionality
- [ ] All Chinese text converted to English (if targeting verified status)
- [ ] Icons copied to dist folder
- [ ] Build successful: `npm run build`
- [ ] Tested locally with `npm link`
- [ ] package.json metadata complete (description, keywords, repository, author)
- [ ] Credentials tested and working
- [ ] Error handling implemented
- [ ] Documentation examples updated

## Verified Node Requirements (Optional)

To achieve "verified" status on n8n:
- ❌ **NO runtime dependencies** (only devDependencies)
- ✅ Full English interface
- ✅ Comprehensive documentation
- ✅ Proper error handling
- ✅ Follow n8n design patterns

**Trade-off**: For community nodes, runtime dependencies are acceptable if they provide value (like using official SDKs).

## Common Patterns Summary

**Subtitle Expression:**
```typescript
subtitle: '={{$parameter["title"]}}',  // Show main parameter value
```

**Multi-Select with Load Options:**
```typescript
{
  type: 'multiOptions',
  typeOptions: { loadOptionsMethod: 'getItems' },
  default: [],
}
```

**Conditional Display:**
```typescript
displayOptions: {
  show: {
    operation: ['send'],
  },
}
```

**Expression Support:**
All string fields automatically support expressions like `={{$json.field}}`.

## Lessons Learned

1. **Start simple**: Build basic functionality first, add features incrementally
2. **Credentials are powerful**: Saved credentials improve UX significantly
3. **Deduplication matters**: Users may combine multiple sources, handle it gracefully
4. **UI iteration is normal**: Expect to refine the interface multiple times
5. **Documentation is crucial**: Clear examples prevent support requests
6. **Test locally first**: `npm link` saves time vs. publishing test versions
7. **Follow n8n patterns**: Study official nodes for best practices
8. **Flat is better**: Avoid over-nesting with collections unless truly necessary

---

Generated from n8n-nodes-serverchan v1.0.0 development experience.
