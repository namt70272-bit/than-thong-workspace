# n8n-nodes-serverchan

[![npm version](https://badge.fury.io/js/n8n-nodes-serverchan.svg)](https://www.npmjs.com/package/n8n-nodes-serverchan)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

n8n community node for [ServerChan Turbo](https://sct.ftqq.com/) - Send WeChat notifications directly from your n8n workflows.

[中文文档](#中文说明) | [Installation](#installation) | [Usage](#usage)

## Features

- ✅ Send messages to WeChat via ServerChan Turbo
- ✅ **Flexible SendKey Management**: Configure recipients in credentials + manual input
- ✅ **Credential Validation**: Test SendKey validity before saving
- ✅ Support multiple SendKeys (parallel sending with automatic deduplication)
- ✅ Support Markdown formatting
- ✅ Support tags and short description
- ✅ Expression support for dynamic content
- ✅ Clean, intuitive English interface

## Installation

### For Self-Hosted n8n

#### Option 1: Via npm (Recommended)

```bash
# Navigate to your n8n custom nodes directory
cd ~/.n8n/custom

# Install the package
npm install n8n-nodes-serverchan

# Restart n8n
```

#### Option 2: Via Docker

```bash
# Enter n8n container
docker exec -it n8n sh

# Install the package
cd ~/.n8n/custom
npm install n8n-nodes-serverchan

# Exit and restart
exit
docker restart n8n
```

## Usage

### 1. Get Your SendKey

Visit [https://sct.ftqq.com/sendkey](https://sct.ftqq.com/sendkey) to get your SendKey(s).

### 2. (Optional) Configure Credentials

For frequently used recipients, you can create a **ServerChan API** credential:

1. Go to **Credentials** → **Create New** → **ServerChan API**
2. Configure recipients in JSON format:
```json
[
  {
    "name": "Alice",
    "sendKey": "sctpXXXXtYYYYYY..."
  },
  {
    "name": "Bob",
    "sendKey": "sctpZZZZtWWWWWW..."
  }
]
```
3. Click **Test** to validate the first SendKey
4. Save the credential

### 3. Add ServerChan Node to Your Workflow

Search for "ServerChan" in the n8n node panel.

### 4. Configure the Node

**Credential to connect with:**
- Select your **ServerChan API** credential (if configured)

**Recipients:**
- **Select from Credentials**: Choose one or multiple recipients from saved credentials
- **Additional SendKeys**: Manually enter additional SendKeys (one per line)
- Both methods can be used together and will be automatically merged and deduplicated

**Message:**
- **Title** (Required): Message title (max 32 characters)
- **Short** (Optional): Short description for message card
- **Content** (Optional): Message content (supports Markdown, max 32KB)
- **Tags** (Optional): Message tags (separated by `|`)

### Usage Examples

**Example 1: Using Saved Credentials**
```
Credential: ServerChan account
Select from Credentials: Alice, Bob
Title: Team Notification
Content: Important update for everyone!
```

**Example 2: Manual SendKeys Only**
```
Additional SendKeys:
sctpXXXXtYYYYYY...
sctpZZZZtWWWWWW...

Title: Daily Report
Content: Today's summary...
```

**Example 3: Credentials + Manual (Mixed Mode)**
```
Credential: ServerChan account
Select from Credentials: Alice, Bob
Additional SendKeys: sctpTEMPtKEYYYY...

Title: Urgent Notification
Content: Sent to saved recipients + temporary recipient
```

## Response Format

The node returns detailed sending results:

```json
{
  "results": [
    {
      "sendKey": "sctp****YYYY",
      "success": true,
      "message": "Success"
    }
  ],
  "summary": {
    "total": 1,
    "success": 1,
    "failure": 0
  }
}
```

## Requirements

- n8n version: 0.200.0 or higher
- Node.js version: 18.0.0 or higher

## License

MIT

---

## 中文说明

### 简介

n8n 社区节点，用于通过 [Server酱 Turbo](https://sct.ftqq.com/) 发送微信通知。

### 功能特性

- ✅ 直接发送消息到微信
- ✅ **灵活的 SendKey 管理**：凭据配置 + 手动输入
- ✅ **凭据验证**：保存前可测试 SendKey 有效性
- ✅ 支持多个 SendKey（并发发送，自动去重）
- ✅ 支持 Markdown 格式
- ✅ 支持标签和简短描述
- ✅ 简洁直观的英文界面

### 安装方法

```bash
cd ~/.n8n/custom
npm install n8n-nodes-serverchan
# 重启 n8n
```

### 使用方法

#### 1. 获取 SendKey

访问 [https://sct.ftqq.com/sendkey](https://sct.ftqq.com/sendkey) 获取你的 SendKey。

#### 2. （可选）配置凭据

对于常用接收者，可以创建 **ServerChan API** 凭据：

1. 进入 **凭据** → **新建凭据** → **ServerChan API**
2. 配置接收者（JSON 格式）：
```json
[
  {
    "name": "张三",
    "sendKey": "sctpXXXXtYYYYYY..."
  },
  {
    "name": "李四",
    "sendKey": "sctpZZZZtWWWWWW..."
  }
]
```
3. 点击 **Test** 验证第一个 SendKey
4. 保存凭据

#### 3. 配置节点

**Credential to connect with：**
- 选择你的 **ServerChan API** 凭据（如果已配置）

**接收者：**
- **Select from Credentials**：从保存的凭据中选择一个或多个接收者
- **Additional SendKeys**：手动输入额外的 SendKey（每行一个）
- 两种方式可以同时使用，会自动合并并去重

**消息：**
- **Title**（必填）：消息标题（最多 32 字符）
- **Short**（可选）：消息卡片的简短描述
- **Content**（可选）：消息内容（支持 Markdown，最多 32KB）
- **Tags**（可选）：消息标签（用 `|` 分隔）

### 使用示例

**示例 1：使用保存的凭据**
```
Credential: ServerChan account
Select from Credentials: 张三, 李四
Title: 团队通知
Content: 重要更新！
```

**示例 2：仅手动输入**
```
Additional SendKeys:
sctpXXXXtYYYYYY...
sctpZZZZtWWWWWW...

Title: 每日报告
Content: 今日摘要...
```

**示例 3：凭据 + 手动输入（混合模式）**
```
Credential: ServerChan account
Select from Credentials: 张三, 李四
Additional SendKeys: sctpTEMPtKEYYYY...

Title: 紧急通知
Content: 发送给固定接收者 + 临时接收者
```

---

Made with ❤️ for n8n community
