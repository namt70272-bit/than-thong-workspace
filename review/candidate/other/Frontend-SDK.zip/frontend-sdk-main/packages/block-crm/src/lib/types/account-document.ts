import type { IdentityCore, EntityStatus } from '@23blocks/contracts';

/**
 * Document category types
 */
export type DocumentCategory = 'license' | 'certification' | 'insurance' | 'credential';

/**
 * Document attached to an account
 */
export interface AccountDocument extends IdentityCore {
  accountUniqueId: string;
  name: string;
  originalName?: string;
  description?: string;
  fileType?: string;
  fileSize?: number;
  url?: string;
  status: EntityStatus;
  enabled: boolean;
  payload?: Record<string, unknown>;

  // Category fields
  /** Document type category: 'license', 'certification', 'insurance', 'credential' */
  categoryName?: DocumentCategory;
  /** Link to Category record */
  categoryUniqueId?: string;

  // Expiration tracking fields
  /** Whether document can expire (default: false) */
  isExpirable?: boolean;
  /** Expiration date */
  expiresAt?: Date;
  /** Issue date */
  issuedAt?: Date;
  /** Issuing authority name */
  issuedBy?: string;
  /** Flexible metadata for additional data */
  metadata?: Record<string, unknown>;
}

// Request types
export interface AddAccountDocumentRequest {
  name: string;
  originalName?: string;
  description?: string;
  fileType?: string;
  fileSize?: number;
  url: string;
  payload?: Record<string, unknown>;

  // Category fields
  categoryName?: DocumentCategory;
  categoryUniqueId?: string;

  // Expiration tracking fields
  /** Whether document can expire (default: false) */
  isExpirable?: boolean;
  /** Expiration date (ISO 8601) */
  expiresAt?: string;
  /** Issue date (ISO 8601) */
  issuedAt?: string;
  /** Issuing authority name */
  issuedBy?: string;
  /** Flexible metadata for additional data */
  metadata?: Record<string, unknown>;
}

export interface PresignDocumentRequest {
  filename: string;
  contentType?: string;
}

export interface PresignDocumentResponse {
  uploadUrl: string;
  publicUrl: string;
  key: string;
}

export interface MultipartPresignRequest {
  filename: string;
  contentType: string;
  partCount: number;
}

export interface MultipartPresignResponse {
  uploadId: string;
  key: string;
  partUrls: string[];
}

export interface MultipartCompleteRequest {
  uploadId: string;
  key: string;
  parts: Array<{ partNumber: number; etag: string }>;
}

export interface MultipartCompleteResponse {
  url: string;
  publicUrl: string;
}
