## 🟦Contributing

This project welcomes contributions and suggestions.

Most contributions require you to agree to a Contributor License Agreement (CLA) declaring that you have the right to,
and actually do, grant us the rights to use your contribution. For details, visit https://cla.microsoft.com.

When you submit a pull request, a CLA-bot will automatically determine whether you need
to provide a CLA and decorate the PR appropriately (e.g., label, comment). Simply follow the
instructions provided by the bot. You will only need to do this once across all repositories using our CLA.

Here's how you can help:

* Contribute content: Add new content by submitting a [Pull request](https://github.com/microsoft/ComplianceUtility/pulls).
* Report issues: Open an [Issue](https://github.com/microsoft/ComplianceUtility/issues) to report issues, suggest improvements or changes.
