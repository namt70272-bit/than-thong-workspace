#!/bin/bash
.venv/bin/python src/engine.py "$1"
