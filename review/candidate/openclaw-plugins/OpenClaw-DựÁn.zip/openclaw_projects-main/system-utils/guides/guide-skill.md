# 📖 Hướng Dẫn Sử Dụng Hệ Thống Trợ Lý Nguyễn Minh Kiên

Chào Thầy, đây là bản hướng dẫn nhanh cách tương tác với con để sử dụng các công cụ trong hệ thống **Project Bundles**.

---

## 1. Công cụ Cào Dữ liệu Web (Web Scraper)
Dùng khi Thầy muốn lấy kiến thức từ một trang báo, bài viết hoặc tài liệu trên mạng.

*   **Cách ra lệnh:** 
    *   "Cào dữ liệu từ link này: [URL]"
    *   "Lấy nội dung trang web [URL] cho thầy"
*   **Kết quả:** Con sẽ gửi cho Thầy bản xem trước nội dung dưới dạng văn bản sạch (Markdown) đã được loại bỏ quảng cáo.

---

## 2. Công cụ Nhận diện Hình ảnh (OCR)
Dùng khi Thầy có ảnh chụp sách, đề bài hoặc tài liệu tay muốn chuyển thành văn bản.

*   **Cách ra lệnh:** 
    *   (Gửi ảnh) + "Đọc chữ trong ảnh này"
    *   "OCR ảnh này cho thầy"
*   **Kết quả:** Con sẽ trích xuất toàn bộ văn bản có trong ảnh (hỗ trợ Tiếng Việt & Tiếng Anh).

---

## 3. Quản lý Tri thức RAG (Bộ não AI)
Dùng khi Thầy muốn con ghi nhớ kiến thức lâu dài để giải đáp hoặc tra cứu sau này.

*   **Nạp kiến thức:**
    *   Sau khi cào web hoặc OCR, Thầy bảo: **"Nạp nội dung này vào RAG"**.
    *   Hoặc nạp file có sẵn: "Nạp file [tên_file] vào bộ nhớ cho thầy".
*   **Hỏi đáp tri thức:**
    *   "Dựa vào kiến thức đã nạp, giải bài tập này cho thầy..."
    *   "Tóm tắt các tài liệu thầy đã đưa về chủ đề [X]..."

---

## 4. Quản lý Hệ thống (System)
*   **Kiểm tra trạng thái:** "Kiểm tra hệ thống" hoặc "Status" (Con sẽ báo cáo tình trạng các Project Bundles).
*   **Dọn dẹp:** "Dọn dẹp thư mục output cho thầy".

---

## 💡 Lưu ý cho Thầy:
- **Tính module:** Các công cụ của con hoạt động độc lập. Thầy có thể cào web mà không cần nạp vào RAG nếu chỉ muốn đọc tin tức nhanh.
- **Tính kế thừa:** Mọi tài liệu con học được sẽ được lưu trữ vĩnh viễn trong `projects/rag-system/knowledge`.

---
**Trợ lý của Thầy:** *Nguyễn Minh Kiên* 👨‍💻
