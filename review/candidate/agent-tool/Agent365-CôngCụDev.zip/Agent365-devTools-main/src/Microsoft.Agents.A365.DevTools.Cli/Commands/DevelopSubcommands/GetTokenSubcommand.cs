// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

using Microsoft.Agents.A365.DevTools.Cli.Constants;
using Microsoft.Agents.A365.DevTools.Cli.Helpers;
using Microsoft.Agents.A365.DevTools.Cli.Models;
using Microsoft.Agents.A365.DevTools.Cli.Services;
using Microsoft.Agents.A365.DevTools.Cli.Services.Helpers;
using Microsoft.Extensions.Logging;
using System.CommandLine;
using System.Text.Json;

namespace Microsoft.Agents.A365.DevTools.Cli.Commands.DevelopSubcommands;

/// <summary>
/// GetToken subcommand - Retrieves bearer tokens for MCP server authentication
/// </summary>
internal static class GetTokenSubcommand
{
    public static Command CreateCommand(
        ILogger logger,
        IConfigService configService,
        AuthenticationService authService)
    {
        var command = new Command(
            "get-token",
            "Retrieve bearer tokens for MCP server authentication\n" +
            "Scopes are read from ToolingManifest.json or specified via command line");

        var configOption = new Option<FileInfo>(
            ["--config", "-c"],
            getDefaultValue: () => new FileInfo("a365.config.json"),
            description: "Configuration file path");

        var appIdOption = new Option<string?>(
            ["--app-id"],
            description: "Application (client) ID to get token for. If not specified, uses the client app ID from config")
        {
            IsRequired = false
        };

        var manifestOption = new Option<FileInfo?>(
            ["--manifest", "-m"],
            description: "Path to ToolingManifest.json (defaults to current directory)");

        var scopesOption = new Option<string[]?>(
            ["--scopes"],
            description: "Specific scopes to request (e.g., McpServers.Mail.All McpServers.Calendar.All). If not specified, uses all scopes from ToolingManifest.json")
        {
            AllowMultipleArgumentsPerToken = true
        };

        var outputFormatOption = new Option<string>(
            ["--output", "-o"],
            getDefaultValue: () => "table",
            description: "Output format: table, json, or raw");

        var verboseOption = new Option<bool>(
            ["--verbose", "-v"],
            description: "Show detailed output including full token");

        var forceRefreshOption = new Option<bool>(
            ["--force-refresh"],
            description: "Force token refresh even if cached token is valid");

        var resourceOption = new Option<string?>(
            ["--resource"],
            description: "Resource keyword to get token for. Available: mcp (default), powerplatform. " +
                         "When specified, --scopes is required.")
        {
            IsRequired = false
        };

        var resourceIdOption = new Option<string?>(
            ["--resource-id"],
            description: "Resource application ID (GUID) to get token for. " +
                         "When specified, --scopes is required.")
        {
            IsRequired = false
        };

        command.AddOption(configOption);
        command.AddOption(appIdOption);
        command.AddOption(manifestOption);
        command.AddOption(scopesOption);
        command.AddOption(outputFormatOption);
        command.AddOption(verboseOption);
        command.AddOption(forceRefreshOption);
        command.AddOption(resourceOption);
        command.AddOption(resourceIdOption);

        command.SetHandler(async (System.CommandLine.Invocation.InvocationContext context) =>
        {
            // Extract option values from context
            var config = context.ParseResult.GetValueForOption(configOption)!;
            var appId = context.ParseResult.GetValueForOption(appIdOption);
            var manifest = context.ParseResult.GetValueForOption(manifestOption);
            var scopes = context.ParseResult.GetValueForOption(scopesOption);
            var outputFormat = context.ParseResult.GetValueForOption(outputFormatOption)!;
            var verbose = context.ParseResult.GetValueForOption(verboseOption);
            var forceRefresh = context.ParseResult.GetValueForOption(forceRefreshOption);
            var resource = context.ParseResult.GetValueForOption(resourceOption);
            var resourceId = context.ParseResult.GetValueForOption(resourceIdOption);

            try
            {
                // Validate mutual exclusivity of --resource and --resource-id
                if (!string.IsNullOrWhiteSpace(resource) && !string.IsNullOrWhiteSpace(resourceId))
                {
                    logger.LogError("Cannot specify both --resource and --resource-id. Use one or the other.");
                    Environment.Exit(1);
                    return;
                }

                // Determine if custom resource is being used
                bool isCustomResource = !string.IsNullOrWhiteSpace(resource) || !string.IsNullOrWhiteSpace(resourceId);

                logger.LogInformation("Retrieving bearer token...");
                logger.LogInformation("");

                // Check if config file exists or if --app-id was provided
                Agent365Config? setupConfig = null;
                if (File.Exists(config.FullName))
                {
                    // Load configuration if it exists
                    setupConfig = await configService.LoadAsync(config.FullName);
                }
                else if (string.IsNullOrWhiteSpace(appId))
                {
                    // Config doesn't exist and no --app-id provided
                    logger.LogError("Configuration file not found: {ConfigPath}", config.FullName);
                    logger.LogInformation("");
                    logger.LogInformation("To retrieve bearer tokens, you must either:");
                    logger.LogInformation("  1. Create a config file using: a365 config init");
                    logger.LogInformation("  2. Specify the application ID using: a365 develop gettoken --app-id <your-app-id>");
                    logger.LogInformation("");
                    logger.LogInformation("Example: a365 develop gettoken --app-id 12345678-1234-1234-1234-123456789abc --scopes McpServers.Mail.All");
                    Environment.Exit(1);
                    return;
                }

                // Determine environment
                var environment = setupConfig?.Environment ?? "prod";

                // Resolve resource app ID
                string resourceAppId;
                string resourceDisplayName;
                string? resourceUrl = null;
                if (!string.IsNullOrWhiteSpace(resourceId))
                {
                    // Validate that resource ID is a valid GUID
                    if (!Guid.TryParse(resourceId, out _))
                    {
                        logger.LogError("Invalid resource application ID: {ResourceId}. Expected a valid GUID.", resourceId);
                        logger.LogInformation("");
                        logger.LogInformation("Example: a365 develop get-token --resource-id 12345678-1234-1234-1234-123456789abc --scopes .default");
                        Environment.Exit(1);
                        return;
                    }

                    // User provided explicit resource ID
                    resourceAppId = resourceId;
                    resourceDisplayName = $"Custom Resource ({resourceId})";
                    logger.LogInformation("Using custom resource ID: {ResourceId}", resourceId);
                }
                else
                {
                    // Resolve resource keyword to GUID (default to "mcp" if null)
                    var resolved = ResolveResourceApp(resource, environment);
                    if (resolved == null)
                    {
                        logger.LogError("Unknown resource keyword '{Resource}'. Valid options: mcp, powerplatform", resource);
                        Environment.Exit(1);
                        return;
                    }

                    resourceAppId = resolved.Value.resourceAppId;
                    resourceDisplayName = resolved.Value.displayName;
                    resourceUrl = resolved.Value.url;
                    logger.LogInformation("Using resource: {DisplayName}", resourceDisplayName);
                }

                if (scopes != null && scopes.Length > 0)
                {
                    // Explicit scopes — single token against the resolved resource
                    logger.LogInformation("Using user-specified scopes: {Scopes}", string.Join(", ", scopes));
                    logger.LogInformation("");
                    logger.LogInformation("Resource App ID: {AppId}", resourceAppId);
                    logger.LogInformation("Requesting scopes: {Scopes}", string.Join(", ", scopes));
                    logger.LogInformation("");

                    await AcquireAndDisplayTokenAsync(
                        resourceAppId, resourceDisplayName, resourceUrl,
                        scopes, appId, setupConfig,
                        outputFormat, verbose, forceRefresh, authService, logger);
                }
                else if (isCustomResource)
                {
                    logger.LogError("The --scopes option is required when using --resource or --resource-id.");
                    logger.LogInformation("");
                    logger.LogInformation("Manifest-based scopes are only supported for the default flow.");
                    logger.LogInformation("Please omit the --resource and --resource-id options if you'd like to use manifest-based scopes.");
                    logger.LogInformation("");
                    logger.LogInformation("Example: a365 develop get-token --resource powerplatform --scopes .default");
                    Environment.Exit(1);
                    return;
                }
                else
                {
                    // Manifest flow — acquire one token per audience
                    var manifestPath = manifest?.FullName
                        ?? Path.Combine(setupConfig?.DeploymentProjectPath ?? Environment.CurrentDirectory, McpConstants.ToolingManifestFileName);

                    if (!File.Exists(manifestPath))
                    {
                        logger.LogError("ToolingManifest.json not found at: {Path}", manifestPath);
                        logger.LogInformation("");
                        logger.LogInformation("Please ensure ToolingManifest.json exists in your project directory");
                        logger.LogInformation("or specify scopes explicitly with --scopes option.");
                        logger.LogInformation("");
                        logger.LogInformation("Example: a365 develop get-token --scopes McpServers.Mail.All McpServers.Calendar.All");
                        Environment.Exit(1);
                        return;
                    }

                    logger.LogInformation("Reading MCP server configuration from: {Path}", manifestPath);

                    await AcquireAndDisplayManifestTokensAsync(
                        manifestPath, appId, setupConfig,
                        outputFormat, verbose, forceRefresh, authService, logger);
                }
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Failed to retrieve bearer token: {Message}", ex.Message);
                Environment.Exit(1);
            }
        });

        return command;
    }

    /// <summary>
    /// Acquires an access token for a single resource and returns the result.
    /// </summary>
    private static async Task<McpServerTokenResult> AcquireTokenAsync(
        string resourceAppId,
        string resourceDisplayName,
        string? resourceUrl,
        string[] requestedScopes,
        string? appId,
        Agent365Config? setupConfig,
        string? tenantId,
        string? loginHint,
        string clientAppId,
        bool forceRefresh,
        AuthenticationService authService,
        ILogger logger)
    {
        var tokenCachePath = Path.Combine(
            ConfigService.GetGlobalConfigDirectory(),
            AuthenticationConstants.TokenCacheFileName);

        try
        {
            var token = await authService.GetAccessTokenWithScopesAsync(
                resourceAppId,
                requestedScopes,
                tenantId,
                forceRefresh,
                clientAppId,
                useInteractiveBrowser: true,
                userId: loginHint);

            if (string.IsNullOrWhiteSpace(token))
            {
                return new McpServerTokenResult
                {
                    ServerName = resourceDisplayName,
                    Url = resourceUrl,
                    Scope = string.Join(", ", requestedScopes),
                    Audience = resourceAppId,
                    Success = false,
                    Error = "Token acquisition returned empty result",
                    CacheFilePath = tokenCachePath
                };
            }

            logger.LogInformation("[SUCCESS] Token acquired for {DisplayName} with scopes: {Scopes}",
                resourceDisplayName, string.Join(", ", requestedScopes));

            return new McpServerTokenResult
            {
                ServerName = resourceDisplayName,
                Url = resourceUrl,
                Scope = string.Join(", ", requestedScopes),
                Audience = resourceAppId,
                Success = true,
                Token = token,
                ExpiresOn = DateTime.UtcNow.AddHours(1), // Estimate
                CacheFilePath = tokenCachePath
            };
        }
        catch (Exception ex)
        {
            logger.LogError("Failed to acquire token for {DisplayName}: {Message}", resourceDisplayName, ex.Message);
            return new McpServerTokenResult
            {
                ServerName = resourceDisplayName,
                Url = resourceUrl,
                Scope = string.Join(", ", requestedScopes),
                Audience = resourceAppId,
                Success = false,
                Error = ex.Message,
                CacheFilePath = tokenCachePath
            };
        }
    }

    /// <summary>
    /// Resolves the client app ID and tenant, acquires tokens (one per audience for manifest flow),
    /// displays results and saves the first successful token to platform config.
    /// </summary>
    private static async Task AcquireAndDisplayTokenAsync(
        string resourceAppId,
        string resourceDisplayName,
        string? resourceUrl,
        string[] requestedScopes,
        string? appId,
        Agent365Config? setupConfig,
        string outputFormat,
        bool verbose,
        bool forceRefresh,
        AuthenticationService authService,
        ILogger logger)
    {
        logger.LogInformation("Acquiring access token with explicit scopes...");

        string? tenantId = await TenantDetectionHelper.DetectTenantIdAsync(setupConfig, logger);
        string clientAppId = ResolveClientAppId(appId, setupConfig);
        var loginHint = await AzCliHelper.ResolveLoginHintAsync();

        logger.LogInformation("");

        var result = await AcquireTokenAsync(
            resourceAppId, resourceDisplayName, resourceUrl,
            requestedScopes, appId, setupConfig,
            tenantId, loginHint, clientAppId, forceRefresh, authService, logger);

        if (!result.Success)
        {
            Environment.Exit(1);
            return;
        }

        DisplayResults(new List<McpServerTokenResult> { result }, outputFormat, verbose, logger);

        await SaveAndReportTokenAsync(result.Token!, setupConfig, logger);
        logger.LogInformation("Token acquired successfully!");
    }

    /// <summary>
    /// Acquires one token per audience from the manifest and displays all results.
    /// </summary>
    private static async Task AcquireAndDisplayManifestTokensAsync(
        string manifestPath,
        string? appId,
        Agent365Config? setupConfig,
        string outputFormat,
        bool verbose,
        bool forceRefresh,
        AuthenticationService authService,
        ILogger logger)
    {
        logger.LogInformation("Acquiring access token with explicit scopes...");

        string? tenantId = await TenantDetectionHelper.DetectTenantIdAsync(setupConfig, logger);
        string clientAppId = ResolveClientAppId(appId, setupConfig);
        var loginHint = await AzCliHelper.ResolveLoginHintAsync();

        logger.LogInformation("");

        var tokenAtgAppId = ConfigConstants.GetAgent365ToolsResourceAppId(setupConfig?.Environment ?? "prod");
        var scopesByAudience = await ManifestHelper.GetScopesByAudienceAsync(manifestPath, resolvedAtgAppId: tokenAtgAppId);
        var serverNamesByAudience = await ManifestHelper.GetServerNamesByAudienceAsync(manifestPath, resolvedAtgAppId: tokenAtgAppId);

        var tokenResults = new List<McpServerTokenResult>();
        foreach (var kvp in scopesByAudience)
        {
            var audience = kvp.Key;
            var scopes = kvp.Value;
            logger.LogInformation("Resource App ID: {AppId}", audience);
            logger.LogInformation("Requesting scopes: {Scopes}", string.Join(", ", scopes));
            logger.LogInformation("");

            var result = await AcquireTokenAsync(
                audience, $"MCP Resource ({audience})", null,
                scopes, appId, setupConfig,
                tenantId, loginHint, clientAppId, forceRefresh, authService, logger);

            tokenResults.Add(result);
        }

        DisplayResults(tokenResults, outputFormat, verbose, logger);

        // Save tokens: first V1/shared token as BEARER_TOKEN (backward compat),
        // each per-server audience token as BEARER_TOKEN_<SERVER_NAME>
        bool anySaved = false;
        bool firstTokenSaved = false;
        foreach (var result in tokenResults.Where(r => r.Success))
        {
            serverNamesByAudience.TryGetValue(result.Audience!, out var serverNames);

            if (serverNames is { Count: > 0 })
            {
                // V2 per-server audience — write one entry per server name
                foreach (var serverName in serverNames)
                    await SaveAndReportTokenAsync(result.Token!, setupConfig, logger, serverUniqueName: serverName);
            }
            else if (!firstTokenSaved)
            {
                // V1 shared audience or ATG seed entry — write as BEARER_TOKEN (backward compat)
                await SaveAndReportTokenAsync(result.Token!, setupConfig, logger, serverUniqueName: null);
                firstTokenSaved = true;
            }
            anySaved = true;
        }

        if (anySaved)
            logger.LogInformation("Token acquisition complete!");
        else
            Environment.Exit(1);
    }

    private static string ResolveClientAppId(string? appId, Agent365Config? setupConfig)
    {
        if (!string.IsNullOrWhiteSpace(appId))
            return appId;
        if (setupConfig != null && !string.IsNullOrWhiteSpace(setupConfig.ClientAppId))
            return setupConfig.ClientAppId;
        throw new InvalidOperationException("No client application ID specified. Use --app-id or ensure ClientAppId is set in config.");
    }

    private static async Task SaveAndReportTokenAsync(
        string token,
        Agent365Config? setupConfig,
        ILogger logger,
        string? serverUniqueName = null)
    {
        if (setupConfig != null)
        {
            await ProjectSettingsSyncHelper.SaveBearerTokenToPlatformConfigAsync(token, setupConfig, logger, serverUniqueName);
        }
        else
        {
            var envVarKey = !string.IsNullOrWhiteSpace(serverUniqueName)
                ? AuthenticationConstants.GetPerServerBearerTokenEnvVar(serverUniqueName)
                : AuthenticationConstants.BearerTokenEnvironmentVariable;
            logger.LogInformation("");
            logger.LogInformation("Note: To use this token in your samples, manually add it to:");
            logger.LogInformation("  - .NET projects: Properties/launchSettings.json > profiles > environmentVariables > {Key}", envVarKey);
            logger.LogInformation("  - Python/Node.js projects: .env file as {Key}={Token}", envVarKey, token);
            logger.LogInformation("");
        }
    }

    /// <summary>
    /// Resolves a resource keyword to its corresponding resource app info.
    /// </summary>
    /// <param name="keyword">The resource keyword (e.g., "mcp", "powerplatform").</param>
    /// <param name="environment">The environment to use for MCP resource resolution.</param>
    /// <returns>A tuple containing the resource app ID, display name, and URL, or null if the keyword is unknown.</returns>
    private static (string resourceAppId, string displayName, string? url)? ResolveResourceApp(string? keyword, string environment)
    {
        if (string.IsNullOrWhiteSpace(keyword))
        {
            keyword = "mcp"; // Default to MCP if no keyword provided
        }

        return keyword.ToLowerInvariant() switch
        {
            "mcp" => (ConfigConstants.GetAgent365ToolsResourceAppId(environment), "Agent 365 Tools (MCP)", ConfigConstants.GetDiscoverEndpointUrl(environment)),
            "powerplatform" => (PowerPlatformConstants.PowerPlatformApiResourceAppId, "Power Platform API", null),
            _ => null
        };
    }

    private static void DisplayResults(
        List<McpServerTokenResult> results,
        string outputFormat,
        bool verbose,
        ILogger logger)
    {
        switch (outputFormat.ToLowerInvariant())
        {
            case "json":
                DisplayJsonResults(results, verbose);
                break;
            case "raw":
                DisplayRawResults(results, verbose);
                break;
            case "table":
            default:
                DisplayTableResults(results, verbose, logger);
                break;
        }
    }

    private static void DisplayTableResults(
        List<McpServerTokenResult> results,
        bool verbose,
        ILogger logger)
    {
        logger.LogInformation("=== MCP Server Bearer Tokens ===");
        logger.LogInformation("");

        foreach (var result in results)
        {
            logger.LogInformation("Server: {Name}", result.ServerName);
            logger.LogInformation("  URL: {Url}", result.Url ?? "(not specified)");
            logger.LogInformation("  Scope: {Scope}", result.Scope ?? "(not specified)");
            logger.LogInformation("  Audience: {Audience}", result.Audience ?? "(not specified)");

            if (result.Success)
            {
                logger.LogInformation("  Status: [SUCCESS]");
                logger.LogInformation("  Expires: ~{Expiry}", result.ExpiresOn?.ToLocalTime().ToString("yyyy-MM-dd HH:mm:ss") ?? "Unknown");

                if (verbose && !string.IsNullOrWhiteSpace(result.Token))
                {
                    logger.LogInformation("  Token: {Token}", result.Token);
                }
                else if (!verbose)
                {
                    logger.LogInformation("  Token: <use --verbose to display>");
                }

                if (!string.IsNullOrWhiteSpace(result.CacheFilePath))
                {
                    logger.LogInformation("  Cached at: {CacheFilePath}", result.CacheFilePath);
                }
            }
            else
            {
                logger.LogInformation("  Status: [FAILED]");
                logger.LogInformation("  Error: {Error}", result.Error ?? "Unknown error");
            }

            logger.LogInformation("");
        }
    }

    private static void DisplayJsonResults(List<McpServerTokenResult> results, bool verbose)
    {
        var output = results.Select(r => new
        {
            serverName = r.ServerName,
            url = r.Url,
            scope = r.Scope,
            audience = r.Audience,
            success = r.Success,
            token = verbose ? r.Token : "<use --verbose to display>",
            expiresOn = r.ExpiresOn?.ToString("o"),
            error = r.Error,
            cacheFilePath = r.CacheFilePath
        });

        var json = JsonSerializer.Serialize(output, new JsonSerializerOptions
        {
            WriteIndented = true,
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase
        });

        Console.WriteLine(json);
    }

    private static void DisplayRawResults(List<McpServerTokenResult> results, bool verbose)
    {
        foreach (var result in results)
        {
            if (result.Success && !string.IsNullOrWhiteSpace(result.Token))
            {
                // Write metadata to stderr so it doesn't interfere with token parsing on stdout
                // but remains available for troubleshooting when multiple tokens are returned
                if (verbose)
                {
                    Console.Error.WriteLine($"# {result.ServerName}");
                    Console.Error.WriteLine($"# Scope: {result.Scope}");
                    Console.Error.WriteLine($"# Audience: {result.Audience}");
                }

                // Write token to stdout for piping to other tools
                Console.WriteLine(result.Token);

                if (verbose)
                {
                    Console.Error.WriteLine();
                }
            }
        }
    }

    private class McpServerTokenResult
    {
        public string ServerName { get; set; } = string.Empty;
        public string? Url { get; set; }
        public string? Scope { get; set; }
        public string? Audience { get; set; }
        public bool Success { get; set; }
        public string? Token { get; set; }
        public DateTime? ExpiresOn { get; set; }
        public string? Error { get; set; }
        public string? CacheFilePath { get; set; }
    }
}
