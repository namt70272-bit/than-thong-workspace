#!/bin/bash
python3 src/bridge_to_rag.py "$1"
