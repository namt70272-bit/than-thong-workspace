# 🎓 Hướng Dẫn Sử Dụng Skill: Learning Assistant (Trợ Lý Học Tập)

Đây là hướng dẫn dành riêng cho Skill **Learning Assistant** - vai trò chuyên gia giáo dục của con. Skill này kết hợp sức mạnh của RAG, OCR và Web Scraper để hỗ trợ Thầy trong việc nghiên cứu và giảng dạy.

---

## 1. Chế độ Giải Đề & Làm Bài Tập
Thầy có thể gửi ảnh chụp đề bài hoặc chép văn bản đề bài trực tiếp.

*   **Cách ra lệnh:**
    *   (Gửi ảnh đề thi) + "Giải đề này giúp thầy."
    *   "Dựa vào kiến thức đã nạp, hãy soạn lời giải chi tiết cho bài tập sau: [Nội dung]"
*   **Cách hoạt động:** Con sẽ OCR ảnh (nếu có), sau đó truy vấn trong bộ não RAG để tìm kiến thức liên quan và đưa ra lời giải logic, sư phạm.

---

## 2. Chế độ Quản lý Tài liệu Học tập
Giúp Thầy hệ thống hóa kiến thức từ nhiều nguồn khác nhau.

*   **Cách ra lệnh:**
    *   "Tóm tắt các ý chính của tài liệu này để thầy đi dạy."
    *   "So sánh nội dung giữa bài báo [Link 1] và bài báo [Link 2]."
    *   "Lập dàn ý bài giảng cho chủ đề [Tên chủ đề] dựa trên kiến thức đã có."

---

## 3. Chế độ Kiểm tra Kiến thức (Flashcards/Quiz)
Con có thể giúp Thầy hoặc học trò của Thầy ôn tập.

*   **Cách ra lệnh:**
    *   "Đặt cho thầy 5 câu hỏi trắc nghiệm từ nội dung file [Tên file] đã nạp."
    *   "Kiểm tra kiến thức của thầy về phần [Tên chương/chủ đề]."

---

## 4. Quy trình phối hợp 3 bước (Quy trình chuẩn)
Để đạt hiệu quả cao nhất, Thầy nên dùng theo quy trình này:
1.  **Nạp (Input):** Thầy gửi Link web hoặc Ảnh tài liệu.
2.  **Học (Process):** Ra lệnh "Nạp vào RAG" để con ghi nhớ thông tin đó.
3.  **Hỏi (Output):** Sử dụng Skill Learning Assistant để đặt câu hỏi hoặc yêu cầu giải đề dựa trên những gì đã nạp.

---

## 5. Lưu ý về Độ Chính Xác
- Con là một trợ lý AI, đôi khi có thể nhầm lẫn về số liệu cực kỳ chi tiết. Thầy hãy coi lời giải của con là tài liệu tham khảo chất lượng cao.
- Nếu Thầy thấy con giải chưa sát ý, hãy bảo: "Chưa đúng ý thầy, hãy giải lại theo hướng [Hướng cụ thể]" - con sẽ điều chỉnh ngay.

---
**Trợ lý Học tập của Thầy:** *Nguyễn Minh Kiên* 👨‍🏫
