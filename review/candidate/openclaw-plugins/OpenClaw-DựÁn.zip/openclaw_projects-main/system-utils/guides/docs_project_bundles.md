# Hướng dẫn Kỹ thuật: Hệ thống Project Bundles (OpenClaw Workspace)

Tài liệu này dùng để khôi phục hoặc thiết lập lại hệ thống quản lý dự án cho Nguyễn Minh Kiên tại workspace `/home/hgahc/.openclaw/workspace`.

## 1. Cấu trúc Thư mục (Hierarchy)
Hệ thống được tổ chức theo mô hình "Project Bundles" để đảm bảo tính độc lập và module hóa:

```text
/workspace
├── projects/
│   ├── rag-system/           # Não bộ tri thức (ChromaDB)
│   │   ├── .venv/            # Môi trường ảo (Python 3.12)
│   │   ├── knowledge/        # Dữ liệu nguồn (.md, .pdf, .txt)
│   │   └── src/              # Code RAG Core
│   ├── web-tools/            # Nhóm công cụ Web
│   │   └── scraper/          # Tool cào dữ liệu (httpx, trafilatura, playwright)
│   │       ├── .venv/        # Môi trường ảo riêng cho Scraper
│   │       ├── src/          # Engine và Bridge (kết nối RAG)
│   │       └── output/       # Dữ liệu web đã cào (Markdown)
│   └── system-utils/         # Tiện ích hệ thống (Backup, OCR...)
```

## 2. Khôi phục Hệ thống RAG (`projects/rag-system`)
Nếu cần cài đặt lại môi trường RAG:
1. `cd /home/hgahc/.openclaw/workspace/projects/rag-system`
2. `python3 -m venv .venv`
3. `.venv/bin/pip install chromadb sentence-transformers langchain-community pypdf pytesseract Pillow`
4. Đảm bảo thư mục `chroma_db/` tồn tại để giữ lại các vector đã lưu.

## 3. Khôi phục Web Scraper (`projects/web-tools/scraper`)
Nếu cần cài đặt lại môi trường Scraper:
1. `cd /home/hgahc/.openclaw/workspace/projects/web-tools/scraper`
2. `python3 -m venv .venv`
3. `.venv/bin/pip install httpx beautifulsoup4 playwright trafilatura markdownify`
4. `.venv/bin/python -m playwright install chromium`

## 4. Các lệnh vận hành quan trọng (Operational Commands)

### Cào dữ liệu web:
Chạy script tại `projects/web-tools/scraper/run_scraper.sh [URL]`
Nội dung sẽ được lưu dạng `.md` trong thư mục `output/`.

### Nạp dữ liệu từ Scraper vào RAG:
Chạy script tại `projects/web-tools/scraper/nạp_vào_rag.sh [tên_file.md]`
- Nếu không điền tên file, hệ thống sẽ đồng bộ toàn bộ thư mục `output/` sang `knowledge/` của RAG.

### Quy trình nạp kiến thức mới:
1. Sử dụng Scraper để lấy dữ liệu.
2. Kiểm tra nội dung tại `projects/web-tools/scraper/output/`.
3. Chạy lệnh nạp vào RAG để hệ thống trí tuệ nhân tạo có thêm kiến thức mới.

## 5. Lưu ý quan trọng
- **Quyền hạn:** Một số lệnh cài đặt có thể yêu cầu quyền `sudo` (như cài Tesseract OCR cho hệ thống).
- **Bộ nhớ:** Luôn kiểm tra file `MEMORY.md` ở thư mục gốc để biết trạng thái cập nhật cuối cùng của hệ thống.

---
**Phiên bản:** 1.0 (2026-02-26)
**Người lập:** Nguyễn Minh Kiên
