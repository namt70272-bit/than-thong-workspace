import type { Transport, PageResult } from '@23blocks/contracts';
import { decodePageResult } from '@23blocks/jsonapi-codec';
import type { Activity, ListActivitiesParams } from '../types/activity.js';
import type { Comment, ListCommentsParams } from '../types/comment.js';
import { activityMapper } from '../mappers/activity.mapper.js';
import { commentMapper } from '../mappers/comment.mapper.js';

/**
 * Activity Service Interface - User activity feed operations
 */
export interface ActivityService {
  /**
   * Get activities for an identity (user)
   * @param identityUniqueId - Unique ID of the identity to retrieve activities for
   * @param params - Optional filtering and pagination parameters
   * @returns Paginated list of Activity records with pagination metadata
   */
  getActivities(identityUniqueId: string, params?: ListActivitiesParams): Promise<PageResult<Activity>>;

  /**
   * Get comments by an identity (user)
   * @param identityUniqueId - Unique ID of the identity to retrieve comments for
   * @param params - Optional filtering and pagination parameters
   * @returns Paginated list of Comment records with pagination metadata
   */
  getComments(identityUniqueId: string, params?: ListCommentsParams): Promise<PageResult<Comment>>;

  /**
   * Get the user's activity feed (activities from followed users)
   * @param params - Optional filtering and pagination parameters
   * @returns Paginated list of Activity records from followed users with pagination metadata
   * @note Returns activities from users the current user follows, not the user's own activities
   */
  getFeed(params?: ListActivitiesParams): Promise<PageResult<Activity>>;
}

/**
 * Create the Activity service
 */
export function createActivityService(
  transport: Transport,
  _config: { apiKey: string }
): ActivityService {
  return {
    async getActivities(
      identityUniqueId: string,
      params?: ListActivitiesParams
    ): Promise<PageResult<Activity>> {
      const queryParams: Record<string, string> = {};
      if (params?.page) queryParams['page'] = String(params.page);
      if (params?.perPage) queryParams['records'] = String(params.perPage);
      if (params?.activityType) queryParams['activity_type'] = params.activityType;
      if (params?.targetType) queryParams['target_type'] = params.targetType;
      if (params?.dateFrom) queryParams['date_from'] = params.dateFrom;
      if (params?.dateTo) queryParams['date_to'] = params.dateTo;
      if (params?.sortBy) queryParams['sort_by'] = params.sortBy;
      if (params?.sortOrder) queryParams['sort_order'] = params.sortOrder;

      const response = await transport.get<unknown>(`/identities/${identityUniqueId}/activities`, {
        params: queryParams,
      });
      return decodePageResult(response, activityMapper);
    },

    async getComments(
      identityUniqueId: string,
      params?: ListCommentsParams
    ): Promise<PageResult<Comment>> {
      const queryParams: Record<string, string> = {};
      if (params?.page) queryParams['page'] = String(params.page);
      if (params?.perPage) queryParams['records'] = String(params.perPage);
      if (params?.postUniqueId) queryParams['post_unique_id'] = params.postUniqueId;
      if (params?.status) queryParams['status'] = params.status;

      const response = await transport.get<unknown>(`/identities/${identityUniqueId}/comments`, {
        params: queryParams,
      });
      return decodePageResult(response, commentMapper);
    },

    async getFeed(params?: ListActivitiesParams): Promise<PageResult<Activity>> {
      const queryParams: Record<string, string> = {};
      if (params?.page) queryParams['page'] = String(params.page);
      if (params?.perPage) queryParams['records'] = String(params.perPage);
      if (params?.activityType) queryParams['activity_type'] = params.activityType;
      if (params?.targetType) queryParams['target_type'] = params.targetType;
      if (params?.dateFrom) queryParams['date_from'] = params.dateFrom;
      if (params?.dateTo) queryParams['date_to'] = params.dateTo;
      if (params?.sortBy) queryParams['sort_by'] = params.sortBy;
      if (params?.sortOrder) queryParams['sort_order'] = params.sortOrder;

      const response = await transport.get<unknown>('/activities/feed', { params: queryParams });
      return decodePageResult(response, activityMapper);
    },
  };
}
