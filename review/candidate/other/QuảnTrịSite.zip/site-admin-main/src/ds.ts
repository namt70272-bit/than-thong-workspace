import { List, LoadingDialog } from "dattatable";
import {
    Components, ContextInfo, DirectorySession, GroupSiteManager, Helper,
    Search, SensitivityLabels, Site, SPTypes, Types, Web, v2
} from "gd-sprest-bs";
import { M365Groups } from "./m365Groups";
import { Security } from "./security";
import Strings from "./strings";

/**
 * List Item
 * Add your custom fields here
 */
export interface IListItem extends Types.SP.ListItem {
    AuthorId: number;
    Author: { Id: number; Title: string; }
    ProcessFlag: boolean;
    RequestType: string;
    RequestValue: string;
    Status: string;
}

/**
 * Request for creating an item
 */
export interface IRequest {
    key: string;
    message: string;
    value: boolean | string;
}

/**
 * Response from creating an item
 */
export interface IResponse {
    errorFl: boolean;
    key: string;
    message: string;
    value: any;
}

/**
 * Sensitivity Label
 */
export interface ISensitivityLabel {
    desc: string;
    id: string;
    name: string;
    tooltip: string;
}

/**
 * User Information
 */
export interface IUserInfo {
    email: string;
    name: string;
    type: string;
}

/**
 * Request Types
 */
export enum RequestTypes {
    AppCatalog = "App Catalog",
    ClientSideAssets = "Client Side Assets",
    CreateSite = "Create Site",
    CustomScript = "Custom Script",
    DisableCompanyWideSharingLinks = "Company Wide Sharing Links",
    IncreaseStorage = "Increase Storage",
    LockState = "Lock State",
    NoCrawl = "No Crawl",
    RestrictContentDiscovery = "Restrict Content Discovery",
    SearchProperty = "Custom Search Property",
    SiteAttestation = "Site Attestation",
    TeamsConnected = "Teams Connected"
}

/**
 * Data Source
 */
export class DataSource {
    // Method to process requests to add to the list
    static addRequest(url: string, requests: IRequest[]): PromiseLike<IResponse[]> {
        let responses: IResponse[] = [];

        // See if any requests exist
        if (requests.length == 0) {
            // Resolve the request
            return Promise.resolve(responses);
        }

        // Return a promise
        return new Promise(resolve => {
            // Parse the requests
            Helper.Executor(requests, request => {
                // Return a promise
                return new Promise(resolve => {
                    // Create the item
                    this.List.createItem({
                        ProcessFlag: true,
                        RequestType: request.key,
                        RequestValue: request.value + "",
                        Title: url
                    }).then(
                        // Success
                        (item) => {
                            // Add the response
                            responses.push({
                                errorFl: false,
                                key: request.key,
                                message: request.message,
                                value: item.RequestType
                            });

                            // Try the next request
                            resolve(null);
                        },

                        // Error
                        ex => {
                            // Add the response
                            responses.push({
                                errorFl: true,
                                key: request.key,
                                message: "There was an error creating the request. Please refresh and try again.",
                                value: request
                            });

                            // Try the next request
                            resolve(null);
                        }
                    );
                });
            }).then(() => {
                // Resolve the request
                resolve(responses);
            });
        });
    }

    // Checks to see if a site is set to read-only and determines if the user is a site admin
    private static checkOwner(siteUrl: string): PromiseLike<boolean> {
        // Return a promise
        return new Promise(resolve => {
            // See if the user is part of the owner's group
            Web(siteUrl).AssociatedOwnerGroup().query({
                Expand: ["Users"]
            }).execute(ownersGroup => {
                let groupIds = [];
                let groupIdMapper = {};

                // Parse the group users
                for (let i = 0; i < ownersGroup.Users.results.length; i++) {
                    let item = ownersGroup.Users.results[i];

                    // See if this is a user
                    if (item.PrincipalType == SPTypes.PrincipalTypes.User) {
                        // See if this is the user
                        if (item.Email == ContextInfo.userEmail) {
                            // Resolve the request
                            resolve(true);
                            return;
                        }
                    }
                    // Else, see if this is a M365 group
                    else if (item.PrincipalType == SPTypes.PrincipalTypes.SecurityGroup) {
                        // Add the group id
                        let groupId = M365Groups.getGroupId(item.LoginName);
                        if (groupId) {
                            groupIds.push(groupId);
                            groupIdMapper[groupId] = item.LoginName;
                        }
                    }
                }

                // Load the group information
                let isSiteAdmin = false;
                M365Groups.getGroupInfo(groupIds, (group, groupId) => {
                    // Return if we already set the flag
                    if (isSiteAdmin) { return; }

                    // See if this is targeting the owner's group
                    if (groupIdMapper[groupId].endsWith("_o")) {
                        // Parse the owners
                        let owners = group?.owners.results || [];
                        for (let i = 0; i < owners.length; i++) {
                            let owner = owners[i];

                            // See if this is the user
                            if (owner.mail == ContextInfo.userEmail) {
                                // Set the flag
                                isSiteAdmin = true;
                                return;
                            }
                        }
                    } else {
                        // Parse the members
                        let members = group?.members.results || [];
                        for (let i = 0; i < members.length; i++) {
                            let member = members[i];

                            // See if this is the user
                            if (member.mail == ContextInfo.userEmail) {
                                // Set the flag
                                isSiteAdmin = true;
                                return;
                            }
                        }
                    }
                }).then(groups => {
                    // See if the user is an admin
                    if (isSiteAdmin) {
                        // Resolve the request
                        resolve(isSiteAdmin);
                        return;
                    }

                    // Get the user permissions
                    Web(siteUrl).query({ Select: ["EffectiveBasePermissions"] }).execute(web => {
                        // See if the user is an owner
                        resolve(Helper.hasPermissions(web.EffectiveBasePermissions, [
                            SPTypes.BasePermissionTypes.ManageLists,
                            SPTypes.BasePermissionTypes.ManagePermissions,
                            SPTypes.BasePermissionTypes.ManageWeb
                        ]));
                    }, () => {
                        // Resolve the request
                        resolve(false);
                    });
                });
            }, () => {
                // Resolve the request
                resolve(false);
            });
        });
    }

    // Checks to see if a site is set to read-only and determines if the user is a site admin
    private static checkReadOnlySite(siteUrl: string): PromiseLike<boolean> {
        // Return a promise
        return new Promise(resolve => {
            // Get the site
            Site(siteUrl).query({ Select: ["ReadOnly"] }).execute(site => {
                // See if it's not read only
                if (!site.ReadOnly) {
                    // Resolve the request
                    resolve(false);
                    return;
                }

                // Get the site admins for this site
                Web(siteUrl).SiteUsers().query({
                    Filter: "IsSiteAdmin eq true",
                    OrderBy: ["PrincipalType desc"]
                }).execute(items => {
                    let groupIds = [];

                    // Parse the items
                    for (let i = 0; i < items.results.length; i++) {
                        let item = items.results[i];

                        // See if this is a user
                        if (item.PrincipalType == SPTypes.PrincipalTypes.User) {
                            // See if this is the user
                            if (item.Email == ContextInfo.userEmail) {
                                // Resolve the request
                                resolve(true);
                                return;
                            }
                        }
                        // Else, see if this is a M365 group
                        else if (item.PrincipalType == SPTypes.PrincipalTypes.SecurityGroup) {
                            // Add the group id
                            groupIds.push(M365Groups.getGroupId(item.LoginName));
                        }
                    }

                    // See if no groups exist
                    if (groupIds.length == 0) {
                        // Resolve the request
                        resolve(false);
                        return;
                    }

                    // Get the group information
                    let isSiteAdmin = false;
                    M365Groups.getGroupInfo(groupIds, (group, groupId) => {
                        // See if we already set the flag
                        if (isSiteAdmin) { return; }

                        // Return if the group didn't load
                        if (group == null) { return; }

                        // See if we are targeting the owner's group
                        if (groupId.split('_').length > 0) {
                            let owners = group.owners?.results || [];
                            for (let i = 0; i < owners.length; i++) {
                                if (owners[i].mail == ContextInfo.userEmail) {
                                    // Set the flag
                                    isSiteAdmin = true;
                                    break;
                                }
                            }
                        } else {
                            let members = group.members?.results || [];
                            for (let i = 0; i < members.length; i++) {
                                if (members[i].mail == ContextInfo.userEmail) {
                                    // Set the flag
                                    isSiteAdmin = true;
                                    break;
                                }
                            }
                        }
                    }).then(() => {
                        // Resolve the request
                        resolve(isSiteAdmin);
                    });
                }, () => {
                    // Resolve the request
                    resolve(false);
                });
            }, () => {
                // Resolve the request
                resolve(false);
            });
        });
    }

    // Formats a value to bytes
    static formatBytes(bytes, decimals = 2) {
        if (bytes === 0) return '0 Bytes';
        const k = 1024;
        const dm = decimals < 0 ? 0 : decimals;
        const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB', 'PB', 'EB', 'ZB', 'YB'];
        const i = Math.floor(Math.log(bytes) / Math.log(k));
        return parseFloat((bytes / Math.pow(k, i)).toFixed(dm)) + ' ' + sizes[i];
    }

    // Gets all web urls for a site collection
    static getAllWebs(url: string): PromiseLike<void> {
        // Return a promise
        return new Promise((resolve) => {
            // Get all the sub sites
            Web(url, { requestDigest: this.SiteContext.FormDigestValue }).query({
                Expand: ["Webs"],
                Select: ["Webs/HasUniqueRoleAssignments", "Webs/Id", "Webs/ServerRelativeUrl", "Webs/Title"]
            }).execute(resp => {
                // Parse the webs
                Helper.Executor(resp.Webs.results, web => {
                    // Append the item
                    this._siteItems.push({
                        data: web,
                        text: web.ServerRelativeUrl,
                        value: web.Id
                    });

                    // Return a promise
                    return new Promise(resolve => {
                        // Get the sub sites
                        this.getAllWebs(web.ServerRelativeUrl).then(resolve, resolve);
                    });
                }).then(resolve);
            }, () => {
                // Try to get the webs using search
                Search.postQuery<{ Path: string; IdentityWebId: string; }>({
                    query: {
                        Querytext: "path: " + url + " contentclass=sts_site contentclass=sts_web",
                        SelectProperties: {
                            results: [
                                "Path", "IdentityWebId"
                            ]
                        }
                    }
                }).then(resp => {
                    // Clear the sites
                    this._siteItems = [];

                    // Parse the results
                    resp.results.forEach(result => {
                        // Add the item
                        this._siteItems.push({
                            text: result.Path.substring(location.origin.length),
                            value: result.IdentityWebId
                        });
                    });

                    // Sort the webs
                    this._siteItems = this._siteItems.sort((a, b) => {
                        if (a.text < b.text) { return -1; }
                        if (a.text > b.text) { return 1; }
                        return 0;
                    });

                    // Resolve the request
                    resolve();
                });
            });
        });
    }

    // Loads the drive for a list name
    static getDriveIdForList(webId: string, listName: string): PromiseLike<string> {
        // Return a promise
        return new Promise((resolve, reject) => {
            // Get the libraries for this site
            v2.sites({ siteId: DataSource.Site.Id, webId }).drives().execute(resp => {
                // Find the target drive
                let drive = resp.results.find(a => { return a.name == listName; });

                // Resolve the request
                resolve(drive?.id);
            }, reject);
        });
    }

    // List
    private static _list: List<IListItem> = null;
    static get List(): List<IListItem> { return this._list; }
    private static loadList(): PromiseLike<void> {
        // Return a promise
        return new Promise((resolve, reject) => {
            // Initialize the list and don't load any items
            this._list = new List<IListItem>({
                listName: Strings.Lists.Main,
                itemQuery: {
                    Filter: "Id eq 0"
                },
                onInitError: reject,
                onInitialized: resolve
            });
        });
    }

    // Loads the admins/owners of the site
    static loadAdminsOwners(siteUrl: string): PromiseLike<{ admins: IUserInfo[], owners: IUserInfo[] }> {
        // Return a promise
        return new Promise((resolve, reject) => {
            let errorFl = false;
            let web = Web(siteUrl);

            // Get the admins
            let admins: IUserInfo[] = [];
            web.SiteUserInfoList().Items().query({
                Filter: "IsSiteAdmin eq 1"
            }).execute(users => {
                // Add the admins
                users.results.forEach(user => {
                    admins.push({
                        email: user["EMail"] || user["UserName"],
                        name: user.Title,
                        type: "Site Admin"
                    });
                });
            }, () => {
                // Set the flag
                errorFl = true;
            });

            // Get the owners
            let owners: IUserInfo[] = [];
            web.AssociatedOwnerGroup().Users().execute(users => {
                // Add the owners
                users.results.forEach(user => {
                    owners.push({
                        email: user.Email || user.LoginName,
                        name: user.Title,
                        type: "Site Owner"
                    });
                });
            }, () => {
                // Set the flag
                errorFl = true;
            }, true);

            // Wait for the requests to complete
            web.done(() => {
                // Complete the request
                errorFl ? reject() : resolve({ admins, owners })
            });
        });
    }

    // Loads the files for a drive
    static loadFiles(webId: string, driveId: string, folderId: string, onFile?: (file: Types.Microsoft.Graph.driveItem) => boolean | void): PromiseLike<Types.Microsoft.Graph.driveItem[]> {
        let files = [];
        let isOneDrive = webId == DataSource.OneDriveWeb?.Id;
        let stopFl = false;

        // Loads the files for a drive
        let getFiles = (driveId: string, folderId: string) => {
            let driveFolder = v2.sites({
                siteId: isOneDrive ? this.OneDriveSite.Id : this.Site.Id,
                webId, targetInfo: {
                    disableProcessing: true,
                    keepalive: true
                }
            }).drives(driveId).items(folderId);

            // Return a promise
            return new Promise(resolve => {
                // Get the files for the folder
                let folders = driveFolder.children();
                folders.query({
                    GetAllItems: true,
                    Select: ["createdBy", "driveId", "file", "folder", "id", "name", "parentReference", "sensitivityLabel", "webUrl"],
                    Top: 5000
                }).execute(resp => {
                    // Parse the items
                    Helper.Executor(resp["d"].value, (driveItem: Types.Microsoft.Graph.driveItem) => {
                        if (stopFl) { return; }

                        // See if this is a file
                        if (driveItem.file) {
                            // Process the file
                            let returnVal = onFile ? onFile(driveItem) : null;
                            if (returnVal) {
                                // Set the flag
                                stopFl = true;

                                // Stop the requests
                                folders.stop();
                            }

                            // Append the file
                            files.push(driveItem);
                        }
                        // Else, it's a folder
                        else if (driveItem.folder) {
                            // Get the items for this folder
                            return getFiles(driveId, driveItem.id);
                        }
                    }).then(() => {
                        // Resolve the request
                        resolve(files);
                    });
                });
            });
        }

        // Return a promise
        return new Promise((resolve, reject) => {
            // Get the library
            let drive = v2.sites({ siteId: isOneDrive ? this.OneDriveSite.Id : this.Site.Id, webId, targetInfo: { keepalive: true } }).drives(driveId);
            // See if we are getting a specific folder
            if (folderId) {
                // Get the files
                getFiles(driveId, folderId).then(() => { resolve(files); });
            } else {
                // Get the root folder
                drive.root().execute(rootFolder => {
                    // Get the files
                    getFiles(driveId, rootFolder.id).then(() => { resolve(files); });
                }, reject);
            }
        });
    }

    // Loads the folders for a library
    static loadFolders(webId: string, driveId: string, folderId?: string): PromiseLike<Components.IDropdownItem[]> {
        let folders: Components.IDropdownItem[] = [];
        let isOneDrive = webId == DataSource.OneDriveWeb?.Id;

        // Gets the items for a folder
        let getFolders = (driveId: string, folderId: string) => {
            // Return a promise
            return new Promise(resolve => {
                // Get the files for the folder
                v2.sites({
                    siteId: isOneDrive ? this.OneDriveSite.Id : this.Site.Id,
                    webId, targetInfo: {
                        disableProcessing: true,
                        keepalive: true
                    }
                }).drives(driveId).items(folderId).children().query({
                    Filter: "folder ne null",
                    GetAllItems: true,
                    Select: ["driveId", "folder", "id", "name"],
                    Top: 5000
                }).execute(resp => {
                    // Parse the items
                    Helper.Executor(resp["d"].value, (driveItem: Types.Microsoft.Graph.driveItem) => {
                        // Add the folder item
                        folders.push({
                            data: driveItem,
                            text: driveItem.name,
                            value: driveItem.id
                        });
                    }).then(() => {
                        // Resolve the request
                        resolve(folders);
                    });
                }, () => {
                    // No folders exist
                    resolve(folders);
                });
            });
        }

        // Return a promise
        return new Promise((resolve, reject) => {
            // See if the folder exists
            if (folderId) {
                // Load the items for this folder
                getFolders(driveId, folderId).then(() => {
                    // Resolve the request
                    resolve(folders);
                });
            } else {
                // Get the root folder
                v2.drive({
                    driveId,
                    webId,
                    siteId: isOneDrive ? this.OneDriveSite.Id : this.Site.Id,
                }).root().execute(root => {
                    // Load the items for this folder
                    getFolders(driveId, root.id).then(() => {
                        // Resolve the request
                        resolve(folders);
                    });
                }, reject);
            }
        });
    }

    // Loads the items for a list
    static loadItems(props: {
        isOnedrive?: boolean
        listId?: string;
        listName?: string,
        query: Types.IODataQuery,
        onItem?: (items: Types.SP.ListItemOData) => boolean | void,
        webUrl: string
    }): PromiseLike<Types.SP.ListItemOData[]> {
        // Return a promise
        return new Promise((resolve, reject) => {
            // Default the settings
            props.query = props.query || {};
            props.query.GetAllItems = true;
            props.query.GetAllItemsWaitTime = Strings.ThrottleWaitTime;
            props.query.Top = props.query.Top || 5000;

            // Get the list
            let web = props.isOnedrive ? Web.getOneDrive({
                disableProcessing: true,
                keepalive: true,
                callbackQuery: props.onItem ? items => {
                    // Call the event
                    items.forEach(item => {
                        if (props.onItem(item)) {
                            // Stop the requests
                            web.stop();
                        }
                    });
                } : null
            }) : Web(props.webUrl, {
                disableProcessing: true,
                keepalive: true,
                requestDigest: DataSource.SiteContext.FormDigestValue,
                callbackQuery: props.onItem ? items => {
                    // Call the event
                    items.forEach(item => {
                        if (props.onItem(item)) {
                            // Stop the requests
                            web.stop();
                        }
                    });
                } : null
            });

            // Get the items
            let list = props.listName ? web.Lists(props.listName) : web.Lists().getById(props.listId);
            list.Items().query(props.query).execute(
                items => {
                    // Resolve the request
                    resolve(items.results);
                },
                reject
            )
        });
    }

    // Loads the sensitivity labels for the current user
    private static _sensitivityLabels: ISensitivityLabel[] = null;
    static get HasSensitivityLabels(): boolean { return this._sensitivityLabels?.length > 0; }
    static get SensitivityLabels(): ISensitivityLabel[] { return this._sensitivityLabels; }
    private static _sensitivityLabelItems: Components.IDropdownItem[] = null;
    static get SensitivityLabelItems(): Components.IDropdownItem[] { return this._sensitivityLabelItems; }
    private static _siteSensitivityLabels: ISensitivityLabel[] = null;
    static get SiteSensitivityLabels(): ISensitivityLabel[] { return this._siteSensitivityLabels; }
    private static _siteSensitivityLabelItems: Components.IDropdownItem[] = null;
    static get SiteSensitivityLabelItems(): Components.IDropdownItem[] { return this._siteSensitivityLabelItems; }
    static getSensitivityLabel(labelId: string): string {
        // Find the item
        let item = this.SensitivityLabels.filter(a => { return a.id == labelId; })[0];

        // Return the value
        return item ? item.name : labelId;
    }
    private static loadSensitivityLabels(): PromiseLike<void> {
        // Return a promise
        return new Promise(resolve => {
            // Clear the labels
            this._sensitivityLabels = [];
            this._sensitivityLabelItems = [
                {
                    text: "",
                    value: null
                }
            ];

            // Get the sensitivity labels for the user
            SensitivityLabels.getLabelsForUser().execute(labels => {
                // Parse the labels
                for (let i = 0; i < labels.results.length; i++) {
                    let label = labels.results[i];

                    // See if there are sub-labels
                    if (label.sublabels?.length > 0) {
                        // Parse the sub-labels
                        for (let j = 0; j < label.sublabels.length; j++) {
                            let subLabel = label.sublabels[j];
                            let labelName = `${label.displayName} \\ ${subLabel.displayName}`;

                            // Append the label and item
                            this._sensitivityLabels.push({
                                desc: subLabel.description,
                                id: subLabel.id,
                                name: labelName,
                                tooltip: subLabel.tooltip
                            });
                            this._sensitivityLabelItems.push({
                                data: subLabel,
                                text: labelName,
                                value: subLabel.id
                            });
                        }
                    } else {
                        // Append the label and item
                        this._sensitivityLabels.push({
                            desc: label.description,
                            id: label.id,
                            name: label.displayName,
                            tooltip: label.tooltip
                        });
                        this._sensitivityLabelItems.push({
                            data: label,
                            text: label.displayName,
                            value: label.id
                        });
                    }
                }

                resolve();
            }, () => {
                // Load the group context
                GroupSiteManager().getGroupCreationContext().execute(resp => {
                    // Parse the sensitivity labels
                    for (let i = 0; i < resp.DataClassificationOptionsNew.results.length; i++) {
                        let result = resp.DataClassificationOptionsNew.results[i];
                        let desc = resp.ClassificationDescriptionsNew.results.filter(i => { return i.Key == result.Value; })[0];

                        // Append the label and item
                        this._sensitivityLabels.push({
                            desc: desc ? desc.Value : "",
                            id: result.Key,
                            name: result.Value,
                            tooltip: ""
                        });
                        this._sensitivityLabelItems.push({
                            text: result.Value,
                            value: result.Key
                        });
                    }

                    // Resolve the request
                    resolve();
                }, () => { resolve(); });
            });
        });
    }
    private static loadSiteSensitivityLabels(): PromiseLike<void> {
        // Return a promise
        return new Promise((resolve) => {
            // Clear the site labels
            this._siteSensitivityLabels = [];
            this._siteSensitivityLabelItems = [
                {
                    text: "",
                    value: null
                }
            ];

            // Get the sensitivity labels for the site
            GroupSiteManager().getGroupCreationContext().execute(
                info => {
                    // Parse the sensitivity labels
                    info.DataClassificationOptionsNew.results.forEach(classification => {
                        // Get the label
                        let label = this.SensitivityLabels.filter(a => { return a.id == classification.Key; })[0];
                        if (label) {
                            // Add the label information
                            this._siteSensitivityLabels.push(label);
                            this._siteSensitivityLabelItems.push({
                                data: label,
                                text: label.name,
                                value: label.id
                            });
                        } else {
                            // Add the label information
                            this._siteSensitivityLabels.push({
                                desc: "",
                                id: classification.Key,
                                name: classification.Value,
                                tooltip: ""
                            });
                            this._siteSensitivityLabelItems.push({
                                data: classification,
                                text: classification.Value,
                                value: classification.Key
                            });
                        }
                    });

                    // Resolve the request
                    resolve();
                },
                () => {
                    // Error getting the info
                    // Do nothing
                    resolve();
                }
            )
        });
    }

    // Site Context
    private static _siteContext: Types.SP.ContextWebInformation = null;
    static get SiteContext(): Types.SP.ContextWebInformation { return this._siteContext; }
    static refreshContext() {
        // Attach to the refresh token event in the library
        ContextInfo.enableRefreshToken(() => {
            // Get the web context of the current web
            ContextInfo.getWeb(this._siteContext.WebFullUrl).execute(context => {
                // Set the site context
                this._siteContext = context.GetContextWebInformation;
            });
        });
    }

    // Loads the onedrive site
    private static _oneDriveSite: Types.SP.Site = null;
    private static _oneDriveWeb: Types.SP.Web = null;
    static get OneDriveSite(): Types.SP.Site { return this._oneDriveSite; }
    static get OneDriveWeb(): Types.SP.Web { return this._oneDriveWeb; }
    static loadOneDrive(): PromiseLike<void> {
        // Return a promise
        return new Promise((resolve, reject) => {
            // Load the site
            Site.getOneDrive().execute(site => {
                // Set the site
                this._oneDriveSite = site;

                // Load the web
                Web.getOneDrive().execute(web => {
                    // Save the reference and resolve the request
                    this._oneDriveWeb = web;
                    resolve();
                }, reject);
            }, reject);
        });
    }

    // Loads the site collection information
    private static _site: Types.SP.SiteOData = null;
    static get Site(): Types.SP.SiteOData { return this._site; }
    static get SiteCustomScriptsEnabled(): boolean { return Helper.hasPermissions(DataSource.Site.RootWeb.EffectiveBasePermissions, SPTypes.BasePermissionTypes.AddAndCustomizePages); }
    private static _siteItems: Components.IDropdownItem[] = null;
    static get SiteItems(): Components.IDropdownItem[] { return this._siteItems; }
    private static loadSiteInfo(): PromiseLike<void> {
        // Return a promise
        return new Promise((resolve, reject) => {
            // Load the web
            Site(this.SiteContext.SiteFullUrl, { requestDigest: this.SiteContext.FormDigestValue }).query({
                Expand: ["Features", "RootWeb/AllProperties", "RootWeb/EffectiveBasePermissions", "Usage"],
                Select: [
                    "CommentsOnSitePagesDisabled",
                    "DisableCompanyWideSharingLinks",
                    "HubSiteId",
                    "Id",
                    "IsHubSite",
                    "IsRestrictContentOrgWideSearchPolicyEnforcedOnSite",
                    "MediaTranscriptionDisabled",
                    "Owner",
                    "ReadOnly",
                    "RootWeb/Created",
                    "RootWeb/Id",
                    "RootWeb/Title",
                    "RootWeb/WebTemplate",
                    "SandboxedCodeActivationCapability",
                    "SecondaryContact",
                    "SensitivityLabelId",
                    "ServerRelativeUrl",
                    "ShareByEmailEnabled",
                    "ShowPeoplePickerSuggestionsForGuestUsers",
                    "SocialBarOnSitePagesDisabled",
                    "StatusBarLink",
                    "StatusBarText",
                    "Url",
                    "WriteLocked"
                ]
            }).execute(site => {
                // Save the reference and resolve the request
                this._site = site;

                // Clear the items
                this._siteItems = [{
                    text: this._site.ServerRelativeUrl,
                    value: this._site.RootWeb.Id
                }];

                // Load the client side assets
                this.loadClientSideAssets().then(() => {
                    // Sort the items
                    this._siteItems = this._siteItems.sort((a, b) => {
                        if (a.text < b.text) { return -1; }
                        if (a.text > b.text) { return 1; }
                        return 0;
                    });

                    // Resolve the request
                    resolve();
                }, reject);
            }, reject);
        });
    }

    // Loads the web information
    private static _web: Types.SP.WebOData = null;
    static get Web(): Types.SP.WebOData { return this._web; }
    static loadWebInfo(url: string): PromiseLike<void> {
        // Return a promise
        return new Promise((resolve, reject) => {
            // Load the web
            Web(url, { requestDigest: this.SiteContext.FormDigestValue }).query({
                Expand: ["AllProperties"],
                Select: [
                    "Configuration",
                    "CommentsOnSitePagesDisabled",
                    "Created",
                    "ExcludeFromOfflineClient",
                    "HasUniqueRoleAssignments",
                    "Id",
                    "NoCrawl",
                    "SearchScope",
                    "SensitivityLabelId",
                    "Title",
                    "Url",
                    "WebTemplate"
                ]
            }).execute(web => {
                // Save the reference and resolve the request
                this._web = web;
                resolve();
            }, reject);
        });
    }

    // Loads the web template
    private static _webTemplates: { [key: string]: string } = {};
    static getWebTemplate(key: string): PromiseLike<string> {
        // Return a promise
        return new Promise(resolve => {
            // See if we already have the web template info
            if (this._webTemplates[key]) { resolve(this._webTemplates[key]); return; }

            // Get the web template
            this.Web.getAvailableWebTemplates(1033).getByName(key).execute(template => {
                // Set the value
                this._webTemplates[key] = template.Title;

                // Resolve the request
                resolve(template.Title);
            }, () => {
                // Resolve the request
                resolve(key);
            });
        });
    }

    // Gets the url from the query string
    static getUrlFromQS() {
        // Get the id from the querystring
        let qs = document.location.search.split('?');
        qs = qs.length > 1 ? qs[1].split('&') : [];
        for (let i = 0; i < qs.length; i++) {
            let qsItem = qs[i].split('=');
            let key = qsItem[0].toLowerCase();
            let value = qsItem[1];

            // See if this is the "site" key
            if (key == "site") {
                // Return the url
                return value;
            }
        }
    }

    // Determines if the app catalog has bypassed the block download policy
    private static _hasBypassBlockDownloadPolicy: boolean;
    static get HasBypassBlockDownloadPolicy(): boolean { return this._hasBypassBlockDownloadPolicy; }
    private static loadClientSideAssets(): PromiseLike<any> {
        // Clear the flag
        this._hasBypassBlockDownloadPolicy = false;

        // Return a promise
        return new Promise((resolve) => {
            // Get the client side assets library
            Web(this.SiteContext.SiteFullUrl).Lists("Client Side Assets").query({ Select: ["ExemptFromBlockDownloadOfNonViewableFiles"] }).execute(list => {
                // Set the flag
                this._hasBypassBlockDownloadPolicy = list.ExemptFromBlockDownloadOfNonViewableFiles;

                // Resolve the request
                resolve(null);
            }, resolve);
        });
    }

    // Determines if the site collection has an app catalog
    static hasAppCatalog(): boolean {
        // Parse the site features
        for (let i = 0; i < this.Site.Features.results.length; i++) {
            let feature = this.Site.Features.results[i];

            // See if the site collection app catalog feature is enabled
            if (feature.DefinitionId == "88dc6e04-3256-401b-9851-8e07674bb0d6") { return true; }
        }

        // Not found
        return false;
    }

    // Initializes the application
    static init(): PromiseLike<void> {
        // Return a promise
        return new Promise((resolve, reject) => {
            // Init the security
            Security.init().then(() => {
                Promise.all([
                    // Load the list
                    this.loadList(),
                    // Load the sensitivity labels
                    this.loadSensitivityLabels()
                ]).then(() => {
                    // Load the site sensitivity labels
                    // This requires the load sensitivity labels method to be completed first
                    this.loadSiteSensitivityLabels().then(() => {
                        // See if a url exists in the query string
                        let url = this.getUrlFromQS();
                        if (url) {
                            // Update the loading dialog
                            LoadingDialog.setHeader("Loading Site");
                            LoadingDialog.setBody("Validating the site '" + url + "'");

                            // Validate the url and resolve the request
                            this.validate(decodeURIComponent(url)).then(resolve, resolve);
                        } else {
                            // Resolve the request
                            resolve();
                        }
                    });
                }, reject);
            }, reject);
        });
    }

    // Refreshes the list data
    static refresh(itemId?: number): PromiseLike<IListItem | IListItem[]> {
        // Return a promise
        return new Promise((resolve, reject) => {
            // See if an item id exists
            if (itemId > 0) {
                // Refresh the item
                DataSource.List.refreshItem(itemId).then(resolve, reject);
            } else {
                // Refresh the data
                DataSource.List.refresh().then(resolve, reject);
            }
        });
    }

    // Search Property
    private static _searchPropItems: Components.IDropdownItem[] = null;
    static get SearchPropItems(): Components.IDropdownItem[] { return this._searchPropItems; }
    static set SearchPropItems(strCSV: string) {
        // Clear the items
        this._searchPropItems = [{ text: "", value: null }];

        // Parse the values
        let values = strCSV.split(',');
        for (let i = 0; i < values.length; i++) {
            let value = values[i].trim();
            if (value) {
                // add the item
                this._searchPropItems.push({
                    text: value,
                    value
                });
            }
        }
    }

    // Updates the search property
    static updateSearchProp(key: string, value: string): PromiseLike<void> {
        // Return a promise
        return new Promise(resolve => {
            // Ensure the key and value exist
            if (key && value != null) {
                // Update the property
                Helper.setWebProperty(key, value, true, DataSource.Web.Url).then(() => {
                    // Resolve the request
                    resolve();
                }, resolve);
            } else {
                // Resolve the request
                resolve();
            }
        });
    }

    // Validates that the user is an SCA of the site
    private static _isAdmin: boolean = false;
    static get IsAdmin(): boolean { return this._isAdmin; }
    static validate(webUrl: string): PromiseLike<void> {
        // Return a promise
        return new Promise((resolve, reject) => {
            // Set the flag
            this._isAdmin = false;

            // Get the web context
            ContextInfo.getWeb(webUrl).execute(
                context => {
                    // Set the site context
                    this._siteContext = context.GetContextWebInformation;

                    // Get the sharing settings for the web
                    Web.getSharingSettings({
                        objectUrl: this.SiteContext.SiteFullUrl
                    }).execute(settings => {
                        // See if this is the site admin
                        if (settings.IsUserSiteAdmin) {
                            // Set the flag
                            this._isAdmin = true;

                            // Load the web information
                            this.loadWebInfo(this.SiteContext.WebFullUrl).then(() => {
                                // Load the site information
                                this.loadSiteInfo().then(resolve, reject);
                            }, reject);
                        } else {
                            // Check to see if this is a read-only site and determine if the user is an admin
                            this.checkReadOnlySite(this.SiteContext.SiteFullUrl).then(isAdmin => {
                                // See if this is an admin
                                this._isAdmin = isAdmin;
                                if (isAdmin) {
                                    // Load the web information
                                    this.loadWebInfo(this.SiteContext.WebFullUrl).then(() => {
                                        // Load the site information
                                        this.loadSiteInfo().then(resolve, reject);
                                    }, reject);
                                } else {
                                    // Check to see if this is an owner
                                    this.checkOwner(this.SiteContext.SiteFullUrl).then(isOwner => {
                                        // See if they are an owner
                                        if (isOwner) {
                                            // Load the web information
                                            this.loadWebInfo(this.SiteContext.WebFullUrl).then(() => {
                                                // Load the site information
                                                this.loadSiteInfo().then(resolve, reject);
                                            }, reject);
                                        } else {
                                            // Reject the request
                                            reject("Site exists, but you are not the administrator. Please have the site administrator submit the request.");
                                        }
                                    });
                                }
                            });
                        }
                    });
                },

                (ex: any) => {
                    // See if it's a permission issue
                    if (ex.status == 403) {
                        // User doesn't have access to site
                        reject("Error the site exists, but you do not have permissions to it.");
                    }
                    // Else, the site doesn't exist
                    else {
                        // Site doesn't exist
                        reject("Error the site doesn't exist. Please check the url and try again.");
                    }
                }
            );
        });
    }

    // Validates the site creation information
    static validateSiteCreationInfo(title: string, groupAlias: string, url: string): PromiseLike<void> {
        // Return a promise
        return new Promise((resolve, reject) => {
            // Get the web
            Web(url).execute(() => {
                // Site already exists
                reject("A site already exists at this url. Please choose a different url.");
            }, (err) => {
                // Ensure it's not a permission issue
                if (err.status == 403) {
                    // User doesn't have access to site, but it exists
                    reject("A site already exists at this url. Please choose a different url.");
                    return;
                }

                // See if the group alias is defined
                if (groupAlias) {
                    // Validate the group name
                    DirectorySession().validateGroupName(title, groupAlias).execute(result => {
                        // See if it's valid
                        if (result.IsValidName) {
                            // Resolve the request
                            resolve();
                        } else {
                            // Reject the request
                            reject(result.AliasErrorDetails?.ValidationErrorMessage || result.ErrorMessage);
                        }
                    });
                } else {
                    // Resolve the request
                    resolve();
                }
            });
        });
    }
}