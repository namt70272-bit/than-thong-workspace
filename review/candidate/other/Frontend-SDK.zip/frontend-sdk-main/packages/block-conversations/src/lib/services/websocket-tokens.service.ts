import type { Transport } from '@23blocks/contracts';
import type {
  CreateWebSocketTokenRequest,
  CreateWebSocketTokenResponse,
} from '../types/websocket-token.js';

export interface WebSocketTokensService {
  /**
   * Create a WebSocket authentication token
   * @param data - Optional request with channel and user ID
   * @returns CreateWebSocketTokenResponse with token, channel, URL, and optional expiration
   */
  create(data?: CreateWebSocketTokenRequest): Promise<CreateWebSocketTokenResponse>;
}

export function createWebSocketTokensService(transport: Transport, _config: { apiKey: string }): WebSocketTokensService {
  return {
    async create(data?: CreateWebSocketTokenRequest): Promise<CreateWebSocketTokenResponse> {
      const response = await transport.post<{ data: CreateWebSocketTokenResponse }>('/api/websocket_tokens', {
        websocket_token: {
          channel: data?.channel,
          user_id: data?.userId,
        },
      });

      const result = response.data;
      return {
        token: result.token,
        expiresAt: result.expiresAt ? new Date(result.expiresAt as unknown as string) : undefined,
        channel: result.channel,
        url: result.url,
      };
    },
  };
}
