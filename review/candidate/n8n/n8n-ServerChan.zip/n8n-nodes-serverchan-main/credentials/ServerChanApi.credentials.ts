import type {
	IAuthenticateGeneric,
	ICredentialTestRequest,
	ICredentialType,
	INodeProperties,
} from 'n8n-workflow';

export class ServerChanApi implements ICredentialType {
	name = 'serverChanApi';
	displayName = 'ServerChan API';
	documentationUrl = 'https://sct.ftqq.com/';
	icon = 'file:serverchan.svg' as const;
	properties: INodeProperties[] = [
		{
			displayName: 'Recipients Configuration (JSON)',
			name: 'recipients',
			type: 'json',
			typeOptions: {
				rows: 10,
			},
			default: '[\n  {\n    "name": "Recipient 1",\n    "sendKey": "sctpXXXXtYYYYYY..."\n  },\n  {\n    "name": "Recipient 2",\n    "sendKey": "sctpZZZZtWWWWWW..."\n  }\n]',
			description: 'Configure recipients list in JSON array format. Each object contains "name" and "sendKey" fields. Get your SendKey from <a href="https://sct.ftqq.com/sendkey" target="_blank">https://sct.ftqq.com/sendkey</a>.',
		},
	];

	// Credential test: verify if the first SendKey is valid
	test: ICredentialTestRequest = {
		request: {
			method: 'POST',
			url: '=https://sctapi.ftqq.com/{{JSON.parse($credentials.recipients)[0].sendKey}}.send',
			body: {
				title: 'n8n Credential Test',
				desp: 'This is a test message to verify if the SendKey is valid.',
			},
		},
	};
}
