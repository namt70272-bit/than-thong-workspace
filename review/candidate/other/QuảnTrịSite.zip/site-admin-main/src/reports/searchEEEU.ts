import { Dashboard, Documents, LoadingDialog, Modal } from "dattatable";
import { Components, ContextInfo, Helper, SPTypes, Types, Web } from "gd-sprest-bs";
import { DataSource } from "../ds";
import Strings from "../strings";
import { ExportCSV } from "./exportCSV";

interface ISearchItem {
    Email?: string;
    FileName?: string;
    FileUrl?: string;
    Group?: string;
    GroupId?: number;
    GroupInfo?: string;
    Id?: number;
    ItemId?: number;
    ListId?: string;
    ListName?: string;
    ListUrl?: string;
    LoginName: string;
    Name: string;
    Role?: string;
    RoleInfo?: string;
    WebTitle: string;
    WebUrl: string;
}

interface IUserInfo {
    EMail: string;
    Id: number;
    Name: string;
    Title: string;
    UserName: string;
}

const CSVFields = [
    "Name", "UserName", "Email", "Group", "GroupInfo", "FileName", "FileUrl",
    "ItemId", "ListName", "ListUrl", "Role", "RoleInfo", "WebTitle", "WebUrl"
]

export class SearchEEEU {
    private static _dashboard: Dashboard = null;
    private static _elSubNav: HTMLElement = null;
    private static _items: ISearchItem[] = null;
    private static _loadOneDrive: boolean = null;
    private static _stopFl: boolean = false;

    // Analyzes a lists
    private static analyzeList(web: Types.SP.WebOData, list: Types.SP.ListOData): PromiseLike<void> {
        // Return a promise
        return new Promise(resolve => {
            // Set the fields to query
            let Select = ["Id", "HasUniqueRoleAssignments"];
            if (list.BaseTemplate == SPTypes.ListTemplateType.DocumentLibrary ||
                list.BaseTemplate == SPTypes.ListTemplateType.MySiteDocumentLibrary ||
                list.BaseTemplate == SPTypes.ListTemplateType.PageLibrary) {
                // Get the file information
                Select.push("FileLeafRef");
                Select.push("FileRef");
            }

            // Create a batch job
            let completed = 0;
            let ctrBatchJobs = 0;
            let batchWeb = this._loadOneDrive ? Web.getOneDrive() : Web(web.Url, { requestDigest: DataSource.SiteContext.FormDigestValue });
            let batch = batchWeb.Lists().getById(list.Id);

            // Update the dialog
            this._elSubNav.children[1].innerHTML = `Loading the items...`;

            // Get the items for the list
            let itemCounter = 0;
            DataSource.loadItems({
                isOnedrive: this._loadOneDrive,
                listId: list.Id,
                webUrl: web.Url,
                query: { Select },
                onItem: item => {
                    // Update the dialog
                    this._elSubNav.children[1].innerHTML = `Creating Batch Requests - Processed ${++itemCounter} items...`;

                    // See if this item doesn't have unique permissions
                    if (!item.HasUniqueRoleAssignments) { return; }

                    // Get the permissions
                    batch.Items(item.Id).RoleAssignments().query({
                        Filter: `Member/Title eq 'Everyone' or substringof('spo-grid-all-users', Member/LoginName)`,
                        Expand: [
                            "Member", "RoleDefinitionBindings"
                        ]
                    }).batch(roles => {
                        // Parse the role assignments
                        Helper.Executor(roles.results, roleAssignment => {
                            let roleDef = roleAssignment.RoleDefinitionBindings.results[0];
                            let user: Types.SP.User = roleAssignment.Member as any;

                            // Add a row for this entry
                            let roleItem = {
                                Email: user.Email,
                                FileName: item["FileLeafRef"],
                                FileUrl: item["FileRef"],
                                Group: "",
                                GroupId: 0,
                                GroupInfo: "",
                                Id: user.Id,
                                ItemId: item.Id,
                                ListId: list.Id,
                                ListName: list.Title,
                                LoginName: user.LoginName,
                                ListUrl: list.RootFolder.ServerRelativeUrl,
                                Name: user.Title || user.LoginName,
                                Role: roleDef?.Name || "",
                                RoleInfo: roleDef?.Description || "",
                                WebUrl: web.Url,
                                WebTitle: web.Title
                            };
                            this._items.push(roleItem);
                            this._dashboard.Datatable.addRow(roleItem);

                            // Increment the counter and update the dialog
                            this._elSubNav.children[1].innerHTML = `Batch Requests Processed ${++completed} of ${ctrBatchJobs % Strings.MaxBatchSize}...`;
                        });
                    }, ctrBatchJobs++ % Strings.MaxBatchSize == 0);

                    // Return the stop flag
                    return this._stopFl;
                }
            }).then(() => {
                // Update the dialog
                this._elSubNav.children[1].innerHTML = `Executing Batch Request for ${ctrBatchJobs} items...`;

                // Execute the batch jobs
                batch.execute(() => {
                    // Resolve the request
                    resolve();
                });
            });
        });
    }

    // Analyzes the site
    private static analyzeSite(web: Types.SP.WebOData, searchLists: boolean): PromiseLike<void> {
        // Return a promise
        return new Promise(resolve => {
            // Search the users
            this.analyzeUsers(web).then(() => {
                // See if we are searching lists
                if (searchLists) {
                    // Show a dialog
                    this._elSubNav.children[1].innerHTML = `Analyzing lists...`;

                    // Get the lists
                    let site = this._loadOneDrive ? Web.getOneDrive() : Web(web.Url, { requestDigest: DataSource.SiteContext.FormDigestValue });
                    site.Lists().query({
                        Filter: "Hidden eq false",
                        Expand: ["RootFolder"],
                        Select: ["Id", "Title", "BaseTemplate", "HasUniqueRoleAssignments", "RootFolder/ServerRelativeUrl"]
                    }).execute(resp => {
                        let ctrList = 0;
                        let siteText = this._elSubNav.children[0].innerHTML;

                        // Parse the lists
                        let lists = this._loadOneDrive ? resp["value"] : resp.results;
                        Helper.Executor(lists, list => {
                            // See if we are stopping this process
                            if (this._stopFl) { return; }

                            // Show a dialog
                            this._elSubNav.children[0].innerHTML = `${siteText} - [Analyzing List ${++ctrList} of ${lists.length}]: ${list.Title}`;

                            // Analyze the list
                            return this.analyzeList(web, list);
                        }).then(() => {
                            // Resolve the request
                            resolve(null);
                        });
                    });
                } else {
                    // Resolve the request
                    resolve();
                }
            })
        });
    }

    // Analyze the site users
    private static analyzeUsers(web: Types.SP.WebOData) {
        return new Promise(resolve => {
            // Get the users
            this.getUsers().then(users => {
                let counter = 0;

                // Parse the users
                Helper.Executor(users, user => {
                    // Update the dialog
                    this._elSubNav.children[1].innerHTML = `Analyzing User ${++counter} of ${users.length}`;

                    // Get the user information
                    return this.getUserInfo(web, user);
                }).then(() => {
                    // Resolve the request
                    resolve(null);
                });
            }, resolve);
        })
    }

    // Gets the form fields to display
    static getFormFields(): Components.IFormControlProps[] {
        return [
            {
                name: "SearchLists",
                label: "In Depth Search?",
                description: "Selecting this option will include a search for unique item permissions in lists/libraries.",
                type: Components.FormControlTypes.Switch,
                value: false
            }
        ];
    }

    // Get the user information
    private static getUserInfo(web: Types.SP.WebOData, userInfo: IUserInfo) {
        // Return a promise
        return new Promise((resolve) => {
            // Parse the roles
            for (let i = 0; i < web.RoleAssignments.results.length; i++) {
                let role: Types.SP.RoleAssignmentOData = web.RoleAssignments.results[i] as any;
                let roleDef = role.RoleDefinitionBindings.results[0];

                // See if this role is the user
                if (role.Member.LoginName == userInfo.Name) {
                    // Add the user information
                    let roleItem = {
                        WebUrl: web.Url,
                        WebTitle: web.Title,
                        Id: userInfo.Id,
                        LoginName: userInfo.Name,
                        Name: userInfo.Title || userInfo.Name,
                        Email: userInfo.EMail,
                        Group: "",
                        GroupId: 0,
                        GroupInfo: "",
                        Role: roleDef?.Name || "",
                        RoleInfo: roleDef?.Description || ""
                    };
                    this._items.push(roleItem);
                    this._dashboard.Datatable.addRow(roleItem);

                    // Check the next role
                    continue;
                }
            }

            // Get the groups the user is associated with
            let dstWeb = this._loadOneDrive ? Web.getOneDrive() : Web(DataSource.SiteContext.SiteFullUrl, { requestDigest: DataSource.SiteContext.FormDigestValue });
            dstWeb.SiteUsers(userInfo.Id).Groups().execute(groups => {
                // Parse the groups the member belongs to
                Helper.Executor(groups.results, group => {
                    // Parse the roles
                    for (let i = 0; i < web.RoleAssignments.results.length; i++) {
                        let role: Types.SP.RoleAssignmentOData = web.RoleAssignments.results[i] as any;

                        // See if the user belongs to this role
                        if (role.Member.LoginName == group.LoginName) {
                            let roleDef = role.RoleDefinitionBindings.results[0];

                            // Add the user information
                            let roleItem = {
                                WebUrl: web.Url,
                                WebTitle: web.Title,
                                Id: userInfo.Id,
                                LoginName: userInfo.Name,
                                Name: userInfo.Title || userInfo.Name,
                                Email: userInfo.EMail,
                                Group: group.Title,
                                GroupId: group.Id,
                                GroupInfo: group.Description || "",
                                Role: roleDef?.Name || "",
                                RoleInfo: roleDef?.Description || ""
                            };
                            this._items.push(roleItem);
                            this._dashboard.Datatable.addRow(roleItem);
                        }
                    }
                }).then(resolve);
            }, resolve);
        });
    }

    // Gets the external users
    private static getUsers(): PromiseLike<IUserInfo[]> {
        // Return a promise
        return new Promise((resolve, reject) => {
            let users: IUserInfo[] = [];

            // Get the user information list
            let web = this._loadOneDrive ? Web.getOneDrive() : Web(DataSource.SiteContext.SiteFullUrl, { requestDigest: DataSource.SiteContext.FormDigestValue });
            web.Lists("User Information List").Items().query({
                Filter: `Title eq 'Everyone' or substringof('spo-grid-all-users', Name)`,
                Select: ["Id", "Name", "EMail", "Title", "UserName"],
                GetAllItems: true,
                Top: 5000
            }).execute(items => {
                // Parse the items
                for (let i = 0; i < items.results.length; i++) {
                    let item = items.results[i];

                    // Add the user
                    users.push({
                        EMail: item["EMail"],
                        Id: item.Id,
                        Name: item["Name"],
                        Title: item.Title,
                        UserName: item["UserName"]
                    });
                }

                // Resolve the request
                resolve(users);
            }, reject);
        });
    }

    // Removes a user from a group
    private static removeUser(user: string, userId: number) {
        // Display a loading dialog
        LoadingDialog.setHeader("Removing User");
        LoadingDialog.setBody(`Removing the site user '${user}' from all groups. This will close after the request completes.`);
        LoadingDialog.show();

        // Remove the user from the site
        Web(DataSource.SiteContext.SiteFullUrl, { requestDigest: DataSource.SiteContext.FormDigestValue }).SiteUsers().removeById(userId).execute(
            // Success
            () => {
                // Close the dialog
                LoadingDialog.hide();
            },

            // Error
            () => {
                // Close the dialog
                LoadingDialog.hide();

                // TODO
            }
        )
    }

    // Removes a user from a group
    private static removeUserFromGroup(user: string, userId: number, groupId: number) {
        // Display a loading dialog
        LoadingDialog.setHeader("Removing User");
        LoadingDialog.setBody(`Removing the site user '${user}' from the group. This will close after the request completes.`);
        LoadingDialog.show();

        // Remove the user from the site
        Web(DataSource.SiteContext.SiteFullUrl, { requestDigest: DataSource.SiteContext.FormDigestValue }).SiteGroups().getById(groupId).Users().removeById(userId).execute(
            // Success
            () => {
                // Close the dialog
                LoadingDialog.hide();
            },

            // Error
            () => {
                // Close the dialog
                LoadingDialog.hide();

                // TODO
            }
        )
    }

    // Reverts the item permissions
    private static revertPermissions(item: ISearchItem) {
        // Show a loading dialog
        LoadingDialog.setHeader("Restoring Permissions");
        LoadingDialog.setBody("This window will close after the item permissions are restored...");
        LoadingDialog.show();

        // Restore the permissions
        Web(item.WebUrl, { requestDigest: DataSource.SiteContext.FormDigestValue })
            .Lists().getById(item.ListId).Items(item.ItemId).resetRoleInheritance().execute(() => {
                // Close the loading dialog
                LoadingDialog.hide();
            });
    }

    // Renders the search summary
    private static renderSummary(el: HTMLElement, auditOnly: boolean, items: ISearchItem[], onClose?: () => void) {
        // Render the summary
        this._dashboard = new Dashboard({
            el,
            navigation: {
                title: "Search EEEU",
                showFilter: false,
                items: onClose ? [{
                    text: "New Search",
                    className: "btn-outline-light",
                    isButton: true,
                    onClick: () => {
                        // Set the stop flag
                        this._stopFl = true;

                        // Call the close event
                        onClose();
                    }
                }] : null,
                itemsEnd: [{
                    text: "Export to CSV",
                    className: "btn-outline-light me-2",
                    isButton: true,
                    onClick: () => {
                        // Export the CSV
                        new ExportCSV("searchEEEU.csv", CSVFields, items);
                    }
                }]
            },
            table: {
                rows: items,
                onRendering: dtProps => {
                    dtProps.columnDefs = [
                        {
                            "targets": 5,
                            "orderable": false,
                            "searchable": false
                        }
                    ];

                    // Order by the 1st column
                    dtProps.order = [[0, "asc"]];

                    // Return the properties
                    return dtProps;
                },
                columns: [
                    {
                        name: "Name",
                        title: "Object Type",
                        onRenderCell: (el, col, item: ISearchItem) => {
                            // Set the object type
                            let objType = "Site";
                            if (item.GroupId > 0) { objType = "Group"; }
                            if (item.ItemId > 0) { objType = "Item"; }
                            if (item.FileUrl) { objType = "File" }

                            // Render the info
                            el.innerHTML = `
                                <b>Name: </b>${item.Name}
                                <br/>
                                <b>Type: </b>${objType}
                            `;
                        }
                    },
                    {
                        name: "Group",
                        title: "Group Name"
                    },
                    {
                        name: "GroupInfo",
                        title: "Group Detail",
                        onRenderCell: (el) => {
                            // Declare a span element
                            let span = document.createElement("span");
                            span.className = "notes";

                            // Return the plain text if less than 50 chars
                            if (el.innerHTML.length < 50) {
                                span.innerHTML = el.innerHTML;
                            } else {
                                // Truncate to the last white space character in the text after 50 chars and add an ellipsis
                                span.innerHTML = el.innerHTML.substring(0, 50).replace(/\s([^\s]*)$/, '') + '&#8230';

                                // Add a tooltip containing the text
                                Components.Tooltip({
                                    content: "<small>" + el.innerHTML + "</small>",
                                    target: span
                                });
                            }

                            // Clear the element
                            el.innerHTML = "";

                            // Append the span
                            el.appendChild(span);
                        }
                    },
                    {
                        name: "Role",
                        title: "Permission"
                    },
                    {
                        name: "RoleInfo",
                        title: "Permission Detail",
                        onRenderCell: (el) => {
                            // Declare a span element
                            let span = document.createElement("span");
                            span.className = "notes";

                            // Return the plain text if less than 50 chars
                            if (el.innerHTML.length < 50) {
                                span.innerHTML = el.innerHTML;
                            } else {
                                // Truncate to the last white space character in the text after 50 chars and add an ellipsis
                                span.innerHTML = el.innerHTML.substring(0, 50).replace(/\s([^\s]*)$/, '') + '&#8230';

                                // Add a tooltip containing the text
                                Components.Tooltip({
                                    content: "<small>" + el.innerHTML + "</small>",
                                    target: span
                                });
                            }

                            // Clear the element
                            el.innerHTML = "";
                            // Append the span
                            el.appendChild(span);
                        }
                    },
                    {
                        className: "text-end",
                        name: "",
                        title: "",
                        onRenderCell: (el, col, row: ISearchItem) => {
                            let btnDelete: Components.IButton = null;

                            // Render the tooltips
                            let tooltips = Components.TooltipGroup({ el });

                            // See if this is a file
                            if (row.FileUrl) {
                                // Add a button to the file
                                tooltips.add({
                                    content: "Click to view the file.",
                                    btnProps: {
                                        className: "pe-2 py-1",
                                        text: "View File",
                                        type: Components.ButtonTypes.OutlinePrimary,
                                        onClick: () => {
                                            // View the file
                                            window.open(Documents.isWopi(row.FileName) ? row.WebUrl + "/_layouts/15/WopiFrame.aspx?sourcedoc=" + row.FileUrl + "&action=view" : row.FileUrl, "_blank");
                                        }
                                    }
                                });
                            }

                            // See if this is a list item
                            if (row.ListId) {
                                // Add the view button
                                tooltips.add({
                                    content: "Click to view the item unique permissions.",
                                    btnProps: {
                                        className: "pe-2 py-1",
                                        //iconType: GetIcon(24, 24, "PeopleTeam", "mx-1"),
                                        text: "View Group",
                                        type: Components.ButtonTypes.OutlinePrimary,
                                        onClick: () => {
                                            // View the group
                                            window.open(`${row.WebUrl}/${ContextInfo.layoutsUrl}/user.aspx?List=${row.ListId}&obj=${row.ListId},${row.FileUrl ? "1" : "2"},LISTITEM`);
                                        }
                                    }
                                });
                            }

                            // Ensure this is a group
                            if (row.GroupId > 0) {
                                // Add the view button
                                tooltips.add({
                                    content: "Click to view the site group.",
                                    btnProps: {
                                        className: "pe-2 py-1",
                                        //iconType: GetIcon(24, 24, "PeopleTeam", "mx-1"),
                                        text: "View Group",
                                        type: Components.ButtonTypes.OutlinePrimary,
                                        onClick: () => {
                                            // View the group
                                            window.open(`${row.WebUrl}/${ContextInfo.layoutsUrl}/people.aspx?MembershipGroupId=${row.GroupId}`);
                                        }
                                    }
                                });

                                // Ensure we can remove
                                if (!auditOnly) {
                                    // Add the remove button
                                    tooltips.add({
                                        content: "Click to remove the account from the group",
                                        btnProps: {
                                            assignTo: btn => { btnDelete = btn; },
                                            className: "pe-2 py-1",
                                            //iconType: GetIcon(24, 24, "PersonDelete", "mx-1"),
                                            text: "Remove From Group",
                                            type: Components.ButtonTypes.OutlineDanger,
                                            onClick: () => {
                                                // Confirm the removal of the user
                                                if (confirm("Are you sure you want to remove the account from this group?")) {
                                                    // Disable this button
                                                    btnDelete.disable();

                                                    // Remove the user
                                                    this.removeUserFromGroup(row.Name, row.Id, row.GroupId);
                                                }
                                            }
                                        }
                                    });
                                }
                            } else if (!auditOnly) {
                                // See if this is an item
                                if (row.ItemId > 0) {
                                    // Add the remove button
                                    tooltips.add({
                                        content: "Click to restore permissions to inherit from the parent",
                                        btnProps: {
                                            assignTo: btn => { btnDelete = btn; },
                                            className: "pe-2 py-1",
                                            //iconType: GetIcon(24, 24, "PeopleTeamDelete", "mx-1"),
                                            text: "Restore",
                                            type: Components.ButtonTypes.OutlineDanger,
                                            onClick: () => {
                                                // Confirm the deletion of the group
                                                if (confirm("Are you sure you restore the permissions to inherit?")) {
                                                    // Revert the permissions
                                                    this.revertPermissions(row);
                                                }
                                            }
                                        }
                                    });
                                } else {
                                    // Add the remove button
                                    tooltips.add({
                                        content: "Click to remove the account from all site groups and the site",
                                        btnProps: {
                                            assignTo: btn => { btnDelete = btn; },
                                            className: "pe-2 py-1",
                                            //iconType: GetIcon(24, 24, "PersonDelete", "mx-1"),
                                            text: "Remove From Site",
                                            type: Components.ButtonTypes.OutlineDanger,
                                            onClick: () => {
                                                // Confirm the removal of the user
                                                if (confirm("Are you sure you want to remove the account from this site?")) {
                                                    // Disable this button
                                                    btnDelete.disable();

                                                    // Remove the user
                                                    this.removeUser(row.Name, row.Id);
                                                }
                                            }
                                        }
                                    });
                                }
                            }
                        }
                    }
                ]
            }
        });

        // Set the sub-nav element
        this._elSubNav = el.querySelector("#sub-navigation");
        this._elSubNav.classList.remove("d-none");
        this._elSubNav.classList.add("my-2");
        this._elSubNav.innerHTML = `<div class="h6"></div><div></div>`;
    }

    // Runs the report
    static run(el: HTMLElement, auditOnly: boolean, values: { [key: string]: any }, onClose: () => void) {
        this._loadOneDrive = values["LoadOneDrive"] == "true";
        this._stopFl = false;

        // Show a loading dialog
        LoadingDialog.setHeader("Searching Site");
        LoadingDialog.setBody("Searching the current permissions of the site...");
        LoadingDialog.show();

        // Clear the items
        this._items = [];

        // See if we are showing hidden lists
        let searchLists = values["SearchLists"];

        // Clear the element
        while (el.firstChild) { el.removeChild(el.firstChild); }

        // Render the summary
        this.renderSummary(el, auditOnly, this._items, onClose);

        // Hide the loading dialog
        LoadingDialog.hide();

        // Determine the webs to target
        let siteItems: Components.IDropdownItem[] = null;
        if (this._loadOneDrive) {
            siteItems = [{ text: DataSource.OneDriveWeb.Url, value: DataSource.OneDriveWeb.Id }] as any;
        } else {
            siteItems = values["TargetWeb"] && values["TargetWeb"]["value"] ? [values["TargetWeb"]] as any : DataSource.SiteItems;
        }

        // Parse all webs
        let counter = 0;
        Helper.Executor(siteItems, siteItem => {
            // See if we are stopping this process
            if (this._stopFl) { return; }

            // Update the status
            this._elSubNav.children[0].innerHTML = `Searching Site ${++counter} of ${siteItems.length}`;
            this._elSubNav.children[1].innerHTML = "Getting the info for the web...";

            // Return a promise
            return new Promise(resolve => {
                // Get the permissions
                let web = this._loadOneDrive ? Web.getOneDrive() : Web(siteItem.text, { requestDigest: DataSource.SiteContext.FormDigestValue });
                web.query({
                    Expand: [
                        "RoleAssignments", "RoleAssignments/Groups", "RoleAssignments/Member",
                        "RoleAssignments/RoleDefinitionBindings", "SiteGroups"
                    ]
                }).execute(web => {
                    // Update the dialog
                    this._elSubNav.children[1].innerHTML = `Analyzing web ${counter} of ${siteItems.length}...`;

                    // Analyze the site
                    this.analyzeSite(web, searchLists).then(resolve);
                });
            });
        }).then(() => {
            // Hide the sub-nav
            this._elSubNav.classList.add("d-none");
        });
    }

    // Searches a list for EEEU
    static searchList(webUrl: string, listName: string, auditOnly: boolean) {
        this._loadOneDrive = false;
        this._stopFl = false;

        // Clear the items
        this._items = [];

        // Clear the modal
        Modal.clear();
        Modal.setType(Components.ModalTypes.Full);
        Modal.setHeader("Data Loss Prevention Report");
        Modal.setCloseEvent(() => {
            // Set the flag
            this.stop();
        });

        // Render the footer
        Components.ButtonGroup({
            el: Modal.FooterElement,
            buttons: [
                {
                    text: "Close",
                    type: Components.ButtonTypes.OutlinePrimary,
                    onClick: () => {
                        // Set the flag
                        this.stop();
                        Modal.hide();
                    }
                }
            ]
        });

        // Render the summary
        this.renderSummary(Modal.BodyElement, auditOnly, this._items);

        // Show the modal
        Modal.show();

        // Update the status
        this._elSubNav.children[0].innerHTML = `Searching List: ${listName}`;
        this._elSubNav.children[1].innerHTML = "Getting the info for the web...";

        // Get the permissions
        let web = Web(webUrl, { requestDigest: DataSource.SiteContext.FormDigestValue });
        web.query({
            Expand: [
                "RoleAssignments", "RoleAssignments/Groups", "RoleAssignments/Member",
                "RoleAssignments/RoleDefinitionBindings", "SiteGroups"
            ]
        }).execute(webInfo => {
            // Update the dialog
            this._elSubNav.children[1].innerHTML = `Analyzing the list...`;

            // Get the list information
            web.Lists(listName).query({
                Expand: ["RootFolder"],
                Select: ["Id", "Title", "BaseTemplate", "HasUniqueRoleAssignments", "RootFolder/ServerRelativeUrl"]
            }).execute(list => {
                // Analyze the list
                this.analyzeList(webInfo, list).then(() => {
                    // Hide the sub-nav
                    this._elSubNav.classList.add("d-none");
                });
            });
        });
    }

    // Stops the report
    static stop() { this._stopFl = true; }
}