# This artifact captures everything needed to insert into VS (NuGet packages, insertion metadata, etc.)

[CmdletBinding()]
Param (
)

if ($IsMacOS -or $IsLinux) {
    # We only package up for insertions on Windows agents since they are where optprof can happen.
    Write-Verbose "Skipping VSInsertion artifact since we're not on Windows."
    return @{}
}

$RepoRoot = [System.IO.Path]::GetFullPath("$PSScriptRoot\..\..")
$BuildConfiguration = $env:BUILDCONFIGURATION
if (!$BuildConfiguration) {
    $BuildConfiguration = 'Debug'
}

$PackagesRoot = "$RepoRoot/bin/Packages/$BuildConfiguration"
$NuGetPackages = "$PackagesRoot/NuGet"
$VsixPackages = "$PackagesRoot/Vsix"
$AzurePipelinesPath = "$RepoRoot/azure-pipelines"
if ($env:BUILD_ARTIFACTSTAGINGDIRECTORY) {
     $InsertionOutputs = Join-Path $env:BUILD_ARTIFACTSTAGINGDIRECTORY 'InsertionOutputs'
}

if (!(Test-Path $NuGetPackages) -and !(Test-Path $VsixPackages)) {
    Write-Warning "Skipping because NuGet and VSIX packages haven't been built yet."
    return @{}
}

$result = @{
    "$AzurePipelinesPath" = (Get-ChildItem "$AzurePipelinesPath/vs-insertion-script.ps1");
    "$NuGetPackages" = (Get-ChildItem $NuGetPackages -Recurse);
}

if (Test-Path $VsixPackages) {
    $result["$PackagesRoot"] += Get-ChildItem $VsixPackages -Recurse
}

if ($InsertionOutputs -and $env:PROFILINGINPUTSPROPSNAME) {
    $InsertionOutputsProfilingInputs = Join-Path $InsertionOutputs $env:PROFILINGINPUTSPROPSNAME
    if (Test-Path -LiteralPath $InsertionOutputsProfilingInputs) {
        $result[$InsertionOutputs] = Get-ChildItem -LiteralPath $InsertionOutputsProfilingInputs # OptProf ProfilingInputs
    }
}

$result
