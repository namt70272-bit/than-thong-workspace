# AI News to X Automation - Claude Code Skill

> 自动化抓取 AI 新闻、生成 Obsidian 笔记、创建 X (Twitter) 发布素材的完整工作流

[![GitHub](https://img.shields.io/badge/GitHub-scan--ai--to--x--for--claude--code--skill-blue)](https://github.com/coderhzy/scan-ai-to-x-for-claude-code-skill)

## 📖 项目简介

这是一个使用 Claude Code 构建的自动化工作流项目，用于：
- 🔍 从权威来源抓取最新 AI 行业新闻
- 📝 生成结构化的 Obsidian 笔记
- ✍️ 创建适合 X 平台发布的文案和配图
- 🎨 自动生成极简风格的数据可视化图表

## ✨ 特性

- **全自动化**: 零人工干预，从抓取到生成一键完成
- **多源聚合**: 整合 TechCrunch、Reuters、MIT Tech Review 等 10+ 权威来源
- **极简风格**: 200 字精华提炼，信息密度高
- **即用素材**: 直接输出可发布的文案和配图
- **Obsidian 集成**: 自动保存到 Daily 笔记
- **视觉优化**: 黑底荧光绿配色，适合技术极客审美

## 📦 项目结构

```
scan-ai/
├── ai_news_2026-01-24.md          # AI 新闻原始内容
├── ai_trends_2026.svg             # 趋势图 SVG 源文件
├── ai_trends_2026_x.png           # X 平台配图 (1200×675)
├── x_post_draft.md                # X 文案草稿（3个版本）
├── X_content_analysis.md          # 内容分析报告
├── task_summary.md                # 任务总结
├── 任务执行报告.md                 # 执行详情报告
└── 发布指南.md                     # 使用指南
```

## 🚀 使用示例

### 输入
```
抓取今日 AI 新闻 → 保存到 Obsidian → 生成 X 发布素材
```

### 输出

#### 1. Obsidian 笔记
结构化的 AI 新闻分析，包含：
- 核心趋势分类
- 重要动态列表
- 关键洞察总结
- 标签：#ai #tech #news

#### 2. X 发布素材
**文案示例**:
```
2026 AI进入务实期：

• 小型模型替代大模型炒作
• 推理能力成新标准
• 物理AI从实验室走向现实
• DeepSeek V4下月发布，对标OpenAI

从规模竞赛到实际应用，技术炒作降温。

#AI #TechTrends #2026
```

**配图**: 1200×675 黑底荧光绿风格数据可视化

## 🛠️ 技术栈

- **搜索引擎**: Brave Search API
- **内容抓取**: WebFetch
- **图形生成**: SVG + macOS qlmanage
- **笔记系统**: Obsidian
- **自动化引擎**: Claude Code

## 📊 工作流程

```
1. 抓取 AI 新闻
   ↓
2. 多源信息整合
   ↓
3. 生成 Obsidian 笔记
   ↓
4. 分析并提炼文案
   ↓
5. 生成配图（SVG → PNG）
   ↓
6. 输出发布素材
```

## 🎯 核心功能

### 新闻抓取
- 支持多个权威 AI 新闻源
- 自动过滤和去重
- 提取关键趋势和数据点

### 内容生成
- 极简风格文案（< 100 字）
- 提供 3 个版本供选择
- 自动添加话题标签

### 视觉设计
- 16:9 比例，适配 X 平台
- 黑底荧光绿配色方案
- 左右对比布局设计
- 包含关键数据点

## 📝 示例输出

查看本项目中的示例文件：
- [AI 新闻内容](ai_news_2026-01-24.md)
- [X 文案草稿](x_post_draft.md)
- [配图示例](ai_trends_2026_x.png)
- [发布指南](发布指南.md)

## ⚡ 性能指标

- **执行时间**: < 2 分钟
- **信息源**: 10+ 权威网站
- **输出质量**: 生产级可用
- **人工干预**: 0 次

## 🔧 优化空间

- [ ] 集成 X API 实现自动发布
- [ ] 建立可靠的 RSS 信息源清单
- [ ] 使用 Python 绘图库优化图像生成
- [ ] 添加多语言支持
- [ ] 实现定时自动执行

## 📄 License

MIT License

## 🤝 贡献

欢迎提交 Issue 和 Pull Request！

## 💬 反馈

如有问题或建议，请通过 GitHub Issues 反馈。

---

**Created with [Claude Code](https://claude.ai/code) via [Happy](https://happy.engineering)**

Co-Authored-By: Claude <noreply@anthropic.com>
Co-Authored-By: Happy <yesreply@happy.engineering>
