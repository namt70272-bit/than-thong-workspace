#!/usr/bin/env python3
"""
A/B Tester - 基于 cosine similarity 的 prompt 变体打分
"""

import argparse
import json
import math
import re
from dataclasses import dataclass
from typing import List, Dict, Tuple
from collections import Counter

def simple_tokenize(text: str) -> List[str]:
    """简单分词"""
    text = text.lower()
    text = re.sub(r'[^\w\s]', '', text)
    return text.split()

def cosine_similarity(vec1: Dict[str, int], vec2: Dict[str, int]) -> float:
    """计算 cosine similarity"""
    intersection = set(vec1.keys()) & set(vec2.keys())
    numerator = sum([vec1[x] * vec2[x] for x in intersection])
    
    sum1 = sum([vec1[x] ** 2 for x in vec1.keys()])
    sum2 = sum([vec2[x] ** 2 for x in vec2.keys()])
    denominator = math.sqrt(sum1) * math.sqrt(sum2)
    
    if not denominator:
        return 0.0
    return float(numerator) / denominator

def text_to_vector(text: str) -> Dict[str, int]:
    """文本转向量"""
    words = simple_tokenize(text)
    return Counter(words)

@dataclass
class PromptVariant:
    name: str
    prompt: str
    token_count: int
    expected_output: str

def generate_variants(base_prompt: str, expected_output: str) -> List[PromptVariant]:
    """生成 prompt 变体"""
    base_tokens = len(simple_tokenize(base_prompt))
    
    variants = []
    
    # Variant 1: Repeat x2 (exact)
    variants.append(PromptVariant(
        name="repeat-x2-exact",
        prompt=f"{base_prompt}\n\n{base_prompt}",
        token_count=base_tokens * 2,
        expected_output=expected_output
    ))
    
    # Variant 2: Repeat x2 (paraphrase)
    paraphrased = f"{base_prompt}\n\n请执行上述任务。"
    variants.append(PromptVariant(
        name="repeat-x2-paraphrase",
        prompt=paraphrased,
        token_count=len(simple_tokenize(paraphrased)),
        expected_output=expected_output
    ))
    
    # Variant 3: Repeat x3 (exact)
    variants.append(PromptVariant(
        name="repeat-x3-exact",
        prompt=f"{base_prompt}\n\n{base_prompt}\n\n{base_prompt}",
        token_count=base_tokens * 3,
        expected_output=expected_output
    ))
    
    # Variant 4: Structured repeat
    structured = f"""任务: {base_prompt}

请重复执行上述任务。

再次执行上述任务。"""
    variants.append(PromptVariant(
        name="repeat-structured",
        prompt=structured,
        token_count=len(simple_tokenize(structured)),
        expected_output=expected_output
    ))
    
    return variants

def mock_llm_response(prompt: str, expected: str) -> Tuple[str, float]:
    """模拟 LLM 响应（实际使用时替换为真实 API）"""
    # 简单规则模拟：
    # - repeat-x2-exact: 0.85-0.95 similarity
    # - repeat-x2-paraphrase: 0.80-0.92 similarity
    # - repeat-x3-exact: 0.82-0.93 similarity
    # - repeat-structured: 0.88-0.96 similarity
    # - baseline: 0.60-0.75 similarity
    
    import random
    
    if "repeat-x2-exact" in prompt[:30]:
        similarity = 0.85 + random.random() * 0.10
    elif "repeat-x2-paraphrase" in prompt[:30]:
        similarity = 0.80 + random.random() * 0.12
    elif "repeat-x3-exact" in prompt[:30]:
        similarity = 0.82 + random.random() * 0.11
    elif "repeat-structured" in prompt[:30]:
        similarity = 0.88 + random.random() * 0.08
    else:
        similarity = 0.60 + random.random() * 0.15
    
    # 模拟延迟
    import time
    time.sleep(0.05 + random.random() * 0.15)
    
    # 模拟响应（包含 expected 的部分）
    response = f"这里是响应：{expected[:len(expected)//2]}...{expected[len(expected)//2:]}"
    return response, similarity

def run_ab_test(base_prompt: str, expected_output: str, iterations: int = 5) -> Dict:
    """运行 A/B 测试"""
    print(f"\n🔍 Running A/B Test for prompt...")
    print(f"📝 Base prompt: {base_prompt[:100]}...")
    print(f"🎯 Expected: {expected_output}")
    
    variants = generate_variants(base_prompt, expected_output)
    
    results = {
        "variants": {},
        "baseline": {}
    }
    
    # Baseline
    print(f"\n📊 Testing baseline...")
    baseline_scores = []
    baseline_tokens = len(simple_tokenize(base_prompt))
    for i in range(iterations):
        response, similarity = mock_llm_response(base_prompt, expected_output)
        baseline_scores.append(similarity)
        print(f"  Iteration {i+1}: similarity={similarity:.3f}")
    
    results["baseline"] = {
        "avg_similarity": sum(baseline_scores) / len(baseline_scores),
        "token_count": baseline_tokens
    }
    
    # Variants
    for variant in variants:
        print(f"\n📊 Testing {variant.name}...")
        scores = []
        for i in range(iterations):
            response, similarity = mock_llm_response(variant.prompt, expected_output)
            scores.append(similarity)
            print(f"  Iteration {i+1}: similarity={similarity:.3f}")
        
        results["variants"][variant.name] = {
            "avg_similarity": sum(scores) / len(scores),
            "token_count": variant.token_count,
            "token_ratio": variant.token_count / baseline_tokens
        }
    
    return results

def print_ab_results(results: Dict):
    """打印 A/B 测试结果"""
    print("\n" + "="*60)
    print("📊 A/B Test Results")
    print("="*60)
    
    baseline_sim = results["baseline"]["avg_similarity"]
    baseline_tokens = results["baseline"]["token_count"]
    
    print(f"\n📊 Baseline")
    print(f"  Cosine Similarity: {baseline_sim:.3f}")
    print(f"  Token Count: {baseline_tokens}")
    
    best_variant = None
    best_score = 0
    
    for variant_name, data in results["variants"].items():
        sim = data["avg_similarity"]
        token_ratio = data["token_ratio"]
        improvement = (sim - baseline_sim) / baseline_sim * 100
        
        print(f"\n🎯 {variant_name}")
        print(f"  Cosine Similarity: {sim:.3f}")
        print(f"  Improvement: +{improvement:.1f}%")
        print(f"  Token Ratio: {token_ratio:.2f}x")
        
        if sim > best_score:
            best_score = sim
            best_variant = variant_name
    
    print("\n" + "="*60)
    print(f"🏆 Winner: {best_variant} (similarity={best_score:.3f})")
    print("="*60)
    
    # 生成 BEST_PROMPT.md
    if best_variant:
        print(f"\n📄 Generating BEST_PROMPT.md...")
        with open("BEST_PROMPT.md", "w", encoding="utf-8") as f:
            f.write(f"""# Best Prompt

## 变体
{best_variant}

## Cosine Similarity
{best_score:.3f}

## 提升
+{((best_score - baseline_sim) / baseline_sim * 100):.1f}%

## Token Ratio
{results["variants"][best_variant]["token_ratio"]:.2f}x
""")
        print("✅ BEST_PROMPT.md generated")

def main():
    parser = argparse.ArgumentParser(description="Prompt A/B Tester")
    parser.add_argument("--prompt", required=True, help="Base prompt to test")
    parser.add_argument("--expected", required=True, help="Expected output")
    parser.add_argument("--iterations", type=int, default=5, help="Number of iterations per variant")
    
    args = parser.parse_args()
    
    results = run_ab_test(args.prompt, args.expected, args.iterations)
    print_ab_results(results)
    
    # 保存结果
    with open("ab_test_results.json", "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    print("\n💾 Results saved to ab_test_results.json")

if __name__ == "__main__":
    main()
