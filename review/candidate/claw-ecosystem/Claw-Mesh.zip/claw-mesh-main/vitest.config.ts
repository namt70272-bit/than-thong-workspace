import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    globals: true,
    testTimeout: 30_000,
    hookTimeout: 30_000,
    fileParallelism: false,
    include: ['governance/tests/**/*.test.ts', 'packages/core/src/**/__tests__/**/*.test.ts'],
  },
});
