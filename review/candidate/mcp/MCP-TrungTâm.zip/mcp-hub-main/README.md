# mcp-hub
MCP Skill Multiplexer + Toolbox Runtime — lazy-load MCP tools via skills, single-file script tools (Amp-style)
