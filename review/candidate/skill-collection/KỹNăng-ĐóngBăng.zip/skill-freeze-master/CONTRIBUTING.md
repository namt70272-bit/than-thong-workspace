# Contributing to skill-freeze

Thanks for your interest! Here's how to help.

## Quick Wins

- **Report which AI agents you've tested with** — we want to verify compatibility across Claude Code, Codex, Gemini CLI, OpenCode, Kiro, Cursor, etc.
- **Share your token savings** — run `npx skill-freeze status` and share the before/after numbers
- **Suggest better category rules** — the auto-categorization uses regex matching; better heuristics welcome

## Development

```bash
git clone https://github.com/2233admin/skill-freeze.git
cd skill-freeze
node bin/cli.mjs help
```

Zero dependencies. Just Node.js ≥ 18.

## Guidelines

- Keep it zero-dependency — don't add npm packages
- Cross-platform: test on Windows (junctions) and Unix (symlinks)
- CLI output should be clear and actionable

## Testing

```bash
# Dry run — see what would happen without changing anything
node bin/cli.mjs status

# Test freeze/thaw cycle
node bin/cli.mjs freeze    # pick skills to keep
node bin/cli.mjs status    # verify
node bin/cli.mjs thaw      # restore
node bin/cli.mjs status    # verify restored
```

## Ideas Welcome

- [ ] Config file for persistent hot-list (skip interactive prompt)
- [ ] `--profile` flag for different hot-lists per project
- [ ] Better auto-categorization (maybe LLM-assisted?)
- [ ] Integration with `skills-cli` for install-and-freeze workflow
- [ ] Token counting from actual SKILL.md content (not just estimates)
