import { Dashboard, LoadingDialog } from "dattatable";
import { Components, ContextInfo, Helper, SPTypes, Types, Web } from "gd-sprest-bs";
import { DataSource } from "../ds";
import { M365Groups } from "../m365Groups";
import { ExportCSV } from "./exportCSV";

interface ISearchItem {
    Role?: string;
    RoleInfo?: string;
    LoginName: string;
    Name: string;
    Email?: string;
    Group?: string;
    GroupId?: number;
    GroupInfo?: string;
    Id?: number;
    IsM365Group?: boolean;
    M365GroupUrl?: string;
    WebTitle: string;
    WebUrl: string;
}

interface IUserInfo {
    EMail: string;
    Id: number;
    Name: string;
    Title: string;
    UserName: string;
}

const CSVFields = [
    "Name", "UserName", "Email", "Group", "GroupInfo",
    "Role", "RoleInfo", "WebTitle", "WebUrl"
]

export class SearchUsers {
    private static _dashboard: Dashboard = null;
    private static _elSubNav: HTMLElement = null;
    private static _items: ISearchItem[] = null;
    private static _loadOneDrive: boolean = false;

    // Get the group user information
    private static analyzeRoleAssignments(web: Types.SP.WebOData, search: string | Types.SP.User, userInfo: IUserInfo): PromiseLike<void> {
        // Return a promise
        return new Promise(resolve => {
            let groups: { [key: string]: Types.SP.RoleAssignmentOData } = {};

            // Parse the roles
            let ctrRoles = 0;
            Helper.Executor((web.RoleAssignments.results as any as Types.SP.RoleAssignmentOData[]), role => {
                // Update the dialog
                this._elSubNav.children[1].innerHTML = `Analyzing role assignment ${++ctrRoles} of ${web.RoleAssignments.results.length}...`;

                // Return a promise
                return new Promise(resolve => {
                    // See if this role is the user
                    if (role.Member.LoginName == userInfo.Name) {
                        // Add the user information
                        let userItem: ISearchItem = {
                            WebUrl: web.Url,
                            WebTitle: web.Title,
                            Id: userInfo.Id,
                            LoginName: userInfo.Name,
                            Name: userInfo.Title || userInfo.Name,
                            Email: userInfo.EMail,
                            Group: "",
                            GroupId: 0,
                            GroupInfo: "",
                            Role: role.RoleDefinitionBindings.results[0].Name,
                            RoleInfo: role.RoleDefinitionBindings.results[0].Description || ""
                        }
                        this._items.push(userItem);
                        this._dashboard.Datatable.addRow(userItem);

                        // Check the next role
                        resolve(null);
                    } else if (role.Member.PrincipalType == SPTypes.PrincipalTypes.SharePointGroup) {
                        // Get the members for this group
                        let dstWeb = this._loadOneDrive ? Web.getOneDrive() : Web(DataSource.SiteContext.SiteFullUrl, { requestDigest: DataSource.SiteContext.FormDigestValue });
                        dstWeb.SiteGroups().getById(role.Member.Id).Users().execute(users => {
                            // Parse the users
                            Helper.Executor(users.results, user => {
                                // Get the group id
                                let groupId = M365Groups.getGroupId(user.LoginName);
                                if (groupId) {
                                    // See if this is an owners group
                                    if (user.LoginName.endsWith("_o")) {
                                        groupId += "_o";
                                    }

                                    // Set the group
                                    groups[groupId] = role;
                                }
                            }).then(resolve);
                        });
                    } else {
                        // Get the group id
                        let groupId = M365Groups.getGroupId(role.Member.LoginName);
                        if (groupId) {
                            // See if this is an owners group
                            if (role.Member.LoginName.endsWith("_o")) {
                                groupId += "_o";
                            }

                            // Set the group
                            groups[groupId] = role;
                        }

                        // Check the next role
                        resolve(null);
                    }
                });
            }).then(() => {
                // Get the group ids
                let counter = 0;
                let groupIds = [];
                for (let groupId in groups) { groupIds.push(groupId); }

                // Get the group information
                M365Groups.getGroupInfo(groupIds, (group, groupId) => {
                    // Update the dialog
                    this._elSubNav.children[1].innerHTML = `Getting M365 group info: ${++counter} of ${groupIds.length}...`;

                    // Do nothing if the group didn't load
                    if (group == null) { return; }

                    // Get the group information
                    let groupInfo = groupId.split('_');
                    let isOwner = groupInfo.length > 1;
                    let role = groups[groupId];
                    let users = groupInfo.length > 1 ? group.owners : group.members;

                    // Parse the users
                    for (let i = 0; i < users?.results.length; i++) {
                        let user = users.results[i];

                        // See if we are searching by string
                        if (typeof (search) === "string") {
                            // See this is the user
                            if (user.displayName.toLowerCase().indexOf(search.toString()) >= 0) {
                                // Add the user information
                                let userItem = {
                                    WebUrl: web.Url,
                                    WebTitle: web.Title,
                                    Id: user.id,
                                    LoginName: user.mail,
                                    Name: user.displayName,
                                    Email: user.mail,
                                    Group: role.Member.Title,
                                    GroupId: role.Member.Id,
                                    GroupInfo: `${group.displayName} M365 Group ${isOwner ? "owner" : "member"}`,
                                    IsM365Group: true,
                                    M365GroupUrl: M365Groups.getGroupUrl(group),
                                    Role: role.RoleDefinitionBindings.results[0].Name,
                                    RoleInfo: role.RoleDefinitionBindings.results[0].Description || ""
                                };
                                this._items.push(userItem);
                                this._dashboard.Datatable.addRow(userItem);
                            }
                        }
                        // Else, compare the email
                        else if (user.mail == userInfo.EMail) {
                            // Add the user information
                            let userItem = {
                                WebUrl: web.Url,
                                WebTitle: web.Title,
                                Id: user.id,
                                LoginName: user.mail,
                                Name: user.displayName,
                                Email: user.mail,
                                Group: role.Member.Title,
                                GroupId: role.Member.Id,
                                GroupInfo: `${group.displayName} M365 Group ${isOwner ? "owner" : "member"}`,
                                IsM365Group: true,
                                M365GroupUrl: M365Groups.getGroupUrl(group),
                                Role: role.RoleDefinitionBindings.results[0].Name,
                                RoleInfo: role.RoleDefinitionBindings.results[0].Description || ""
                            };
                            this._items.push(userItem);
                            this._dashboard.Datatable.addRow(userItem);
                        }
                    }
                }).then(() => { resolve(); });
            });
        });
    }

    // Analyzes the site
    private static analyzeSite(web: Types.SP.WebOData, search: string | Types.SP.User) {
        // Return a promise
        return new Promise(resolve => {
            // Get the users
            this.getUsers(search).then(users => {
                let counter = 0;

                // Parse the users
                Helper.Executor(users, user => {
                    // Update the dialog
                    this._elSubNav.children[1].innerHTML = `Analyzing User ${++counter} of ${users.length}`;

                    // Add the user information
                    let userItem = {
                        WebUrl: web.Url,
                        WebTitle: web.Title,
                        Id: user.Id,
                        LoginName: user.UserName,
                        Name: user.Title || user.Name,
                        Email: user.EMail
                    };
                    this._items.push(userItem);
                    this._dashboard.Datatable.addRow(userItem);

                    // Return a promise
                    return new Promise(resolve => {
                        // Analyze the user groups
                        this.analyzeUserGroups(web, search, user).then(() => {
                            // Analyze the role assignments
                            this.analyzeRoleAssignments(web, search, user).then(resolve);
                        });
                    });
                }).then(() => {
                    // Resolve the request
                    resolve(null);
                });
            }, resolve);
        });
    }

    // Get the groups the user is a part of
    private static analyzeUserGroups(web: Types.SP.WebOData, search: string | Types.SP.User, userInfo: IUserInfo): PromiseLike<void> {
        // Return a promise
        return new Promise((resolve) => {
            // Update the dialog
            this._elSubNav.children[1].innerHTML = `Analyzing the user groups...`;

            // Get the groups the user is associated with
            let dstWeb = this._loadOneDrive ? Web.getOneDrive() : Web(DataSource.SiteContext.SiteFullUrl, { requestDigest: DataSource.SiteContext.FormDigestValue });
            dstWeb.SiteUsers(userInfo.Id).Groups().execute(groups => {
                // Parse the groups the member belongs to
                Helper.Executor(groups.results, group => {
                    // Parse the roles
                    for (let i = 0; i < web.RoleAssignments.results.length; i++) {
                        let role: Types.SP.RoleAssignmentOData = web.RoleAssignments.results[i] as any;

                        // See if the user belongs to this role
                        if (role.Member.LoginName == group.LoginName) {
                            // Add the user information
                            let userItem = {
                                WebUrl: web.Url,
                                WebTitle: web.Title,
                                Id: userInfo.Id,
                                LoginName: userInfo.Name,
                                Name: userInfo.Title || userInfo.Name,
                                Email: userInfo.EMail,
                                Group: group.Title,
                                GroupId: group.Id,
                                GroupInfo: group.Description || "",
                                Role: role.RoleDefinitionBindings.results[0].Name,
                                RoleInfo: role.RoleDefinitionBindings.results[0].Description || ""
                            };
                            this._items.push(userItem);
                            this._dashboard.Datatable.addRow(userItem);
                        }
                    }
                }).then(resolve);
            }, resolve);
        });
    }

    // Gets the form fields to display
    static getFormFields(): Components.IFormControlProps[] {
        return [
            {
                label: "User or Group Search by Text",
                name: "UserName",
                className: "mb-3",
                description: "Type a user or group display or login name for the search",
                errorMessage: "Please enter the user or group information",
                type: Components.FormControlTypes.TextField
            },
            {
                label: "People Search by Lookup",
                name: "PeoplePicker",
                className: "mb-3",
                description: "Enter a minimum of 3 characters to search for a user",
                errorMessage: "No user was selected...",
                allowGroups: true,
                searchUrl: DataSource.Site.Url,
                type: Components.FormControlTypes.PeoplePicker
            } as Components.IFormControlPropsPeoplePicker
        ];
    }

    // Gets the external users
    private static getUsers(user: string | Types.SP.User): PromiseLike<IUserInfo[]> {
        // Update the dialog
        this._elSubNav.children[1].innerHTML = `Getting the users...`;

        // Return a promise
        return new Promise((resolve, reject) => {
            let users: IUserInfo[] = [];

            // See if we are searching by a string
            if (typeof (user) === "string") {
                // Get the user information list
                let web = this._loadOneDrive ? Web.getOneDrive() : Web(DataSource.SiteContext.SiteFullUrl, { requestDigest: DataSource.SiteContext.FormDigestValue });
                web.Lists("User Information List").Items().query({
                    Filter: `substringof('${user}', Name) or substringof('${user}', Title) or substringof('${user}', UserName)`,
                    Select: ["Id", "Name", "EMail", "Title", "UserName"],
                    GetAllItems: true,
                    Top: 5000
                }).execute(items => {
                    // Parse the items
                    for (let i = 0; i < items.results.length; i++) {
                        let item = items.results[i];

                        // Add the user
                        users.push({
                            EMail: item["EMail"],
                            Id: item.Id,
                            Name: item["Name"],
                            Title: item.Title,
                            UserName: item["UserName"]
                        });
                    }

                    // Resolve the request
                    resolve(users);
                }, reject);
            } else {
                // Get the user
                let web = this._loadOneDrive ? Web.getOneDrive() : Web(DataSource.SiteContext.SiteFullUrl, { requestDigest: DataSource.SiteContext.FormDigestValue });
                web.Lists("User Information List").Items().query({
                    Filter: "Id eq " + user.Id,
                    Select: ["Id", "Name", "EMail", "Title", "UserName"]
                }).execute(items => {
                    let item = items.results[0];
                    if (item) {
                        // Add the user
                        users.push({
                            EMail: item["EMail"],
                            Id: item.Id,
                            Name: item["Name"],
                            Title: item.Title,
                            UserName: item["UserName"]
                        });
                    }

                    // Resolve the request
                    resolve(users);
                }, reject);
            }
        });
    }

    // Removes a user from a group
    private static removeUser(user: string, userId: number) {
        // Display a loading dialog
        LoadingDialog.setHeader("Removing User");
        LoadingDialog.setBody(`Removing the site user '${user}' from all groups. This will close after the request completes.`);
        LoadingDialog.show();

        // Remove the user from the site
        Web(DataSource.SiteContext.SiteFullUrl, { requestDigest: DataSource.SiteContext.FormDigestValue }).SiteUsers().removeById(userId).execute(
            // Success
            () => {
                // Close the dialog
                LoadingDialog.hide();
            },

            // Error
            () => {
                // Close the dialog
                LoadingDialog.hide();
            }
        )
    }

    // Removes a user from a group
    private static removeUserFromGroup(user: string, userId: number, groupId: number) {
        // Display a loading dialog
        LoadingDialog.setHeader("Removing User");
        LoadingDialog.setBody(`Removing the site user '${user}' from the group. This will close after the request completes.`);
        LoadingDialog.show();

        // Remove the user from the site
        Web(DataSource.SiteContext.SiteFullUrl, { requestDigest: DataSource.SiteContext.FormDigestValue }).SiteGroups().getById(groupId).Users().removeById(userId).execute(
            // Success
            () => {
                // Close the dialog
                LoadingDialog.hide();
            },

            // Error
            () => {
                // Close the dialog
                LoadingDialog.hide();

                // TODO
            }
        )
    }
    // Renders the search summary
    private static renderSummary(el: HTMLElement, auditOnly: boolean, items: ISearchItem[], onClose: () => void) {
        // Render the summary
        this._dashboard = new Dashboard({
            el,
            navigation: {
                title: "Search Users",
                showFilter: false,
                items: [{
                    text: "New Search",
                    className: "btn-outline-light",
                    isButton: true,
                    onClick: () => {
                        // Call the close event
                        onClose();
                    }
                }],
                itemsEnd: [{
                    text: "Export to CSV",
                    className: "btn-outline-light me-2",
                    isButton: true,
                    onClick: () => {
                        // Export the CSV
                        new ExportCSV("searchUsers.csv", CSVFields, items);
                    }
                }]
            },
            table: {
                rows: items,
                onRendering: dtProps => {
                    dtProps.columnDefs = [
                        {
                            "targets": 6,
                            "orderable": false,
                            "searchable": false
                        }
                    ];

                    // Order by the 1st column
                    dtProps.order = [[0, "asc"]];

                    // Return the properties
                    return dtProps;
                },
                columns: [
                    {
                        name: "Name",
                        title: "User Name"
                    },
                    {
                        name: "Email",
                        title: "Login/Email",
                        onRenderCell: (el, col, item: ISearchItem) => {
                            // Render the login and email information
                            el.innerHTML = `
                                <b>EMail: </b><span>${item.Email || ""}</span>
                                <br/>
                                <b>Login: </b><span>${item.LoginName || ""}</span>
                            `;
                        }
                    },
                    {
                        name: "Group",
                        title: "Group Name"
                    },
                    {
                        name: "GroupInfo",
                        title: "Group Detail",
                        onRenderCell: (el) => {
                            // Declare a span element
                            let span = document.createElement("span");
                            span.className = "notes";

                            // Return the plain text if less than 50 chars
                            if (el.innerHTML.length < 50) {
                                span.innerHTML = el.innerHTML;
                            } else {
                                // Truncate to the last white space character in the text after 50 chars and add an ellipsis
                                span.innerHTML = el.innerHTML.substring(0, 50).replace(/\s([^\s]*)$/, '') + '&#8230';

                                // Add a tooltip containing the text
                                Components.Tooltip({
                                    content: "<small>" + el.innerHTML + "</small>",
                                    target: span
                                });
                            }

                            // Clear the element
                            el.innerHTML = "";

                            // Append the span
                            el.appendChild(span);
                        }
                    },
                    {
                        name: "Role",
                        title: "Permission"
                    },
                    {
                        name: "RoleInfo",
                        title: "Permission Detail",
                        onRenderCell: (el) => {
                            // Declare a span element
                            let span = document.createElement("span");
                            span.className = "notes";

                            // Return the plain text if less than 50 chars
                            if (el.innerHTML.length < 50) {
                                span.innerHTML = el.innerHTML;
                            } else {
                                // Truncate to the last white space character in the text after 50 chars and add an ellipsis
                                span.innerHTML = el.innerHTML.substring(0, 50).replace(/\s([^\s]*)$/, '') + '&#8230';

                                // Add a tooltip containing the text
                                Components.Tooltip({
                                    content: "<small>" + el.innerHTML + "</small>",
                                    target: span
                                });
                            }

                            // Clear the element
                            el.innerHTML = "";

                            // Append the span
                            el.appendChild(span);
                        }
                    },
                    {
                        className: "text-end",
                        name: "",
                        title: "",
                        onRenderCell: (el, col, row: ISearchItem) => {
                            let btnDelete: Components.IButton = null;

                            // Render the tooltips
                            let tooltips = Components.TooltipGroup({ el });

                            // Ensure this is a group
                            if (row.GroupId > 0) {
                                // Add the view button
                                tooltips.add({
                                    content: "View Group",
                                    btnProps: {
                                        className: "pe-2 py-1",
                                        //iconType: GetIcon(24, 24, "PeopleTeam", "mx-1"),
                                        text: "View",
                                        type: Components.ButtonTypes.OutlinePrimary,
                                        isDisabled: !(row.GroupId > 0),
                                        onClick: () => {
                                            // View the group
                                            window.open(`${row.WebUrl}/${ContextInfo.layoutsUrl}/people.aspx?MembershipGroupId=${row.GroupId}`);
                                        }
                                    }
                                });

                                // Ensure we can remove
                                if (!auditOnly && row.IsM365Group != true) {
                                    // Add the remove button
                                    tooltips.add({
                                        content: "Removes the user from the group",
                                        btnProps: {
                                            assignTo: btn => { btnDelete = btn; },
                                            className: "pe-2 py-1",
                                            //iconType: GetIcon(24, 24, "PersonDelete", "mx-1"),
                                            text: "Remove From Group",
                                            type: Components.ButtonTypes.OutlineDanger,
                                            onClick: () => {
                                                // Confirm the removal of the user
                                                if (confirm("Are you sure you want to remove the user from this group?")) {
                                                    // Disable this button
                                                    btnDelete.disable();

                                                    // Remove the user
                                                    this.removeUserFromGroup(row.Name, row.Id, row.GroupId);
                                                }
                                            }
                                        }
                                    });
                                }
                            } else if (!auditOnly && row.IsM365Group != true) {
                                // Add the remove button
                                tooltips.add({
                                    content: "Removes the user from the site",
                                    btnProps: {
                                        assignTo: btn => { btnDelete = btn; },
                                        className: "pe-2 py-1",
                                        //iconType: GetIcon(24, 24, "PersonDelete", "mx-1"),
                                        text: "Remove From Site",
                                        type: Components.ButtonTypes.OutlineDanger,
                                        onClick: () => {
                                            // Confirm the removal of the user
                                            if (confirm("Are you sure you want to remove the user from this site?")) {
                                                // Disable this button
                                                btnDelete.disable();

                                                // Remove the user
                                                this.removeUser(row.Name, row.Id);
                                            }
                                        }
                                    }
                                });
                            }
                        }
                    }
                ]
            }
        });

        // Set the sub-nav element
        this._elSubNav = el.querySelector("#sub-navigation");
        this._elSubNav.classList.remove("d-none");
        this._elSubNav.classList.add("my-2");
        this._elSubNav.innerHTML = `<div class="h6"></div><div></div>`;
    }

    // Runs the report
    static run(el: HTMLElement, auditOnly: boolean, values: { [key: string]: any }, onClose: () => void) {
        this._loadOneDrive = values["LoadOneDrive"] == "true";

        // Show a loading dialog
        LoadingDialog.setHeader("Searching Site");
        LoadingDialog.setBody("Searching the current permissions of the site...");
        LoadingDialog.show();

        // Clear the items
        this._items = [];

        // Get the form values
        let userName: string = values["UserName"].trim();
        let user: Types.SP.User = values["PeoplePicker"][0];

        // Clear the element
        while (el.firstChild) { el.removeChild(el.firstChild); }

        // Render the summary
        this.renderSummary(el, auditOnly, this._items, onClose);

        // Hide the loading dialog
        LoadingDialog.hide();

        // Determine the webs to target
        let siteItems: Components.IDropdownItem[] = null;
        if (this._loadOneDrive) {
            siteItems = [{ text: DataSource.OneDriveWeb.Url, value: DataSource.OneDriveWeb.Id }] as any;
        } else {
            siteItems = values["TargetWeb"] && values["TargetWeb"]["value"] ? [values["TargetWeb"]] as any : DataSource.SiteItems;
        }

        // Parse all webs
        let counter = 0;
        Helper.Executor(siteItems, siteItem => {
            // Update the status
            this._elSubNav.children[0].innerHTML = `Searching Site ${++counter} of ${siteItems.length}`;
            this._elSubNav.children[1].innerHTML = "Getting the info for the web...";

            // Return a promise
            return new Promise(resolve => {
                // Get the permissions
                let web = this._loadOneDrive ? Web.getOneDrive() : Web(siteItem.text, { requestDigest: DataSource.SiteContext.FormDigestValue });
                web.query({
                    Expand: [
                        "RoleAssignments", "RoleAssignments/Groups", "RoleAssignments/Member",
                        "RoleAssignments/RoleDefinitionBindings", "SiteGroups"
                    ]
                }).execute(web => {
                    // Update the dialog
                    this._elSubNav.children[1].innerHTML = `Analyzing web ${counter} of ${siteItems.length}...`;

                    // Analyze the site
                    this.analyzeSite(web, userName || user).then(resolve);
                });
            });
        }).then(() => {
            // Hide the sub-nav
            this._elSubNav.classList.add("d-none");
        });
    }
}