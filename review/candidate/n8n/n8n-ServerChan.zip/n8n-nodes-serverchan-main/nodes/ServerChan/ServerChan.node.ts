import type {
	IExecuteFunctions,
	ILoadOptionsFunctions,
	INodeExecutionData,
	INodePropertyOptions,
	INodeType,
	INodeTypeDescription,
} from 'n8n-workflow';
import { NodeConnectionTypes } from 'n8n-workflow';

import { sendToServerChan } from './GenericFunctions';

export class ServerChan implements INodeType {
	description: INodeTypeDescription = {
		displayName: 'ServerChan',
		name: 'serverChan',
		icon: 'file:serverchan.svg',
		group: ['output'],
		version: 1,
		subtitle: '={{$parameter["title"]}}',
		description: 'Send WeChat notifications via ServerChan Turbo',
		defaults: {
			name: 'ServerChan',
		},
		inputs: [NodeConnectionTypes.Main],
		outputs: [NodeConnectionTypes.Main],
		credentials: [
			{
				name: 'serverChanApi',
				required: false,
			},
		],
		properties: [
			{
				displayName: 'Select from Credentials',
				name: 'selectedRecipients',
				type: 'multiOptions',
				typeOptions: {
					loadOptionsMethod: 'getRecipients',
				},
				default: [],
				description: 'Select recipients configured in credentials (multi-select)',
			},
			{
				displayName: 'Additional SendKeys',
				name: 'manualSendKeys',
				type: 'string',
				typeOptions: {
					rows: 3,
				},
				default: '',
				placeholder: 'sctpXXXXtYYYYYY...\nsctpZZZZtWWWWWW...\nsctpAAAAtBBBBBB...',
				description: 'Additional SendKeys, one per line. Will be merged with selected recipients. Get yours from <a href="https://sct.ftqq.com/sendkey" target="_blank">https://sct.ftqq.com/sendkey</a>.',
			},
			{
				displayName: 'Title',
				name: 'title',
				type: 'string',
				required: true,
				default: '',
				placeholder: 'Message title',
				description: 'Message title (required, max 32 characters)',
			},
			{
				displayName: 'Short',
				name: 'short',
				type: 'string',
				default: '',
				placeholder: 'Short description for message card',
				description: 'Short description displayed on message card',
			},
			{
				displayName: 'Content',
				name: 'desp',
				type: 'string',
				typeOptions: {
					rows: 5,
				},
				default: '',
				placeholder: 'Supports Markdown format...',
				description: 'Message content, Markdown supported (optional, max 32KB)',
			},
			{
				displayName: 'Tags',
				name: 'tags',
				type: 'string',
				default: '',
				placeholder: 'tag1|tag2',
				description: 'Message tags, separated by |',
			},
		],
	};

	methods = {
		loadOptions: {
			async getRecipients(this: ILoadOptionsFunctions): Promise<INodePropertyOptions[]> {
				try {
					const credentials = await this.getCredentials('serverChanApi');
					const recipientsJson = credentials.recipients as string;
					const recipients = JSON.parse(recipientsJson);

					if (!Array.isArray(recipients)) {
						return [];
					}

					return recipients.map((recipient: any) => {
						const sendKey = recipient.sendKey || '';
						const maskedKey = sendKey.length > 12
							? `${sendKey.slice(0, 8)}...${sendKey.slice(-4)}`
							: '****';
						return {
							name: `${recipient.name || 'Unnamed'} (${maskedKey})`,
							value: sendKey,
						};
					});
				} catch (error) {
					return [];
				}
			},
		},
	};

	async execute(this: IExecuteFunctions): Promise<INodeExecutionData[][]> {
		const items = this.getInputData();
		const returnData: INodeExecutionData[] = [];

		for (let i = 0; i < items.length; i++) {
			try {
				// Get parameters
				const title = this.getNodeParameter('title', i) as string;
				const short = this.getNodeParameter('short', i, '') as string;
				const desp = this.getNodeParameter('desp', i, '') as string;
				const tags = this.getNodeParameter('tags', i, '') as string;

				// Collect all SendKeys
				const sendKeys: string[] = [];

				// 1. Get selected recipients from credentials
				const selectedRecipients = this.getNodeParameter('selectedRecipients', i, []) as string[];
				sendKeys.push(...selectedRecipients);

				// 2. Get manual input SendKeys
				const manualSendKeys = this.getNodeParameter('manualSendKeys', i, '') as string;
				if (manualSendKeys) {
					const parsedKeys = manualSendKeys
						.split('\n')
						.map((k) => k.trim())
						.filter((k) => k.length > 0);
					sendKeys.push(...parsedKeys);
				}

				// 3. Deduplicate
				const uniqueSendKeys = [...new Set(sendKeys)];

				if (uniqueSendKeys.length === 0) {
					throw new Error('At least one recipient is required (select from credentials or enter SendKey manually)');
				}

				// Build options
				const options: any = {};
				if (tags) {
					options.tags = tags;
				}
				if (short) {
					options.short = short;
				}

				// Send message (using deduplicated SendKey list)
				const responseData = await sendToServerChan.call(this, uniqueSendKeys, title, desp, options);

				const executionData = this.helpers.constructExecutionMetaData(
					this.helpers.returnJsonArray(responseData),
					{ itemData: { item: i } },
				);
				returnData.push(...executionData);
			} catch (error: any) {
				if (this.continueOnFail()) {
					const executionData = this.helpers.constructExecutionMetaData(
						this.helpers.returnJsonArray({ error: error?.message || String(error) }),
						{ itemData: { item: i } },
					);
					returnData.push(...executionData);
					continue;
				}
				throw error;
			}
		}

		return [returnData];
	}
}
