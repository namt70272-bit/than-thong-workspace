'Visual Studio - VS Core'
