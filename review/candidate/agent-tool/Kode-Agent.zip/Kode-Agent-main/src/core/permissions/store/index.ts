export { savePermission } from './savePermission'

