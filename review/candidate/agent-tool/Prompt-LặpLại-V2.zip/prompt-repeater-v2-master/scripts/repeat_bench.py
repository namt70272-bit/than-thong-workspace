#!/usr/bin/env python3
"""
NameIndex Benchmark - 基于 arXiv:2512.14982
测试 prompt repetition 对定位任务的提升
"""

import random
import time
import json
from dataclasses import dataclass
from typing import List, Tuple

@dataclass
class TestCase:
    names: List[str]
    target_index: int
    target_name: str

def generate_name_list(count: int = 50) -> TestCase:
    """生成测试用的名单"""
    first_names = ["张", "李", "王", "刘", "陈", "杨", "赵", "黄", "周", "吴"]
    last_names = ["伟", "芳", "娜", "敏", "静", "丽", "强", "磊", "军", "洋"]
    
    names = []
    for i in range(count):
        first = random.choice(first_names)
        last = random.choice(last_names)
        names.append(f"{first}{last}{i+1}")
    
    target_index = 24  # 第 25 个（0-index）
    return TestCase(names=names, target_index=target_index, target_name=names[target_index])

def build_prompt_variants(test_case: TestCase) -> List[Tuple[str, str]]:
    """构建 prompt 变体"""
    names_list = "\n".join([f"{i+1}. {name}" for i, name in enumerate(test_case.names)])
    base_prompt = f"名单:\n{names_list}\n\n请找到第 25 个名字。"
    
    variants = [
        ("baseline", base_prompt),
        ("repeat-x2", f"{base_prompt}\n\n{base_prompt}"),
        ("repeat-x2-paraphrase", f"{base_prompt}\n\n请在上面的名单中定位第 25 个条目。"),
        ("repeat-x3", f"{base_prompt}\n\n{base_prompt}\n\n{base_prompt}"),
    ]
    
    return variants

def mock_llm_call(prompt: str, model: str) -> str:
    """模拟 LLM 调用（实际使用时替换为真实 API）"""
    # 这里用简单的规则模拟：
    # - baseline: 40-50% 准率
    # - repeat-x2: 75-85% 准率
    # - repeat-x3: 70-80% 准率
    
    if "repeat-x2" in prompt[:20]:
        accuracy = 0.75 + random.random() * 0.10
    elif "repeat-x3" in prompt[:20]:
        accuracy = 0.70 + random.random() * 0.10
    else:
        accuracy = 0.40 + random.random() * 0.10
    
    # 模拟延迟
    time.sleep(0.1 + random.random() * 0.2)
    
    # 模拟 token 增加
    token_multiplier = 1.0
    if "repeat-x2" in prompt[:20]:
        token_multiplier = 1.15
    elif "repeat-x3" in prompt[:20]:
        token_multiplier = 1.25
    
    return json.dumps({
        "accuracy": accuracy,
        "token_multiplier": token_multiplier,
        "response_time": 0.1 + random.random() * 0.2
    })

def run_benchmark(model: str = "Claude", iterations: int = 10) -> dict:
    """运行基准测试"""
    print(f"\n🚀 Running NameIndex Benchmark for {model}...")
    
    results = {
        "model": model,
        "variants": {}
    }
    
    for i in range(iterations):
        print(f"\n📊 Iteration {i+1}/{iterations}")
        test_case = generate_name_list()
        variants = build_prompt_variants(test_case)
        
        for variant_name, prompt in variants:
            if variant_name not in results["variants"]:
                results["variants"][variant_name] = {
                    "accuracies": [],
                    "token_multipliers": [],
                    "response_times": []
                }
            
            print(f"  🔍 Testing {variant_name}...")
            llm_response = mock_llm_call(prompt, model)
            response_data = json.loads(llm_response)
            
            results["variants"][variant_name]["accuracies"].append(response_data["accuracy"])
            results["variants"][variant_name]["token_multipliers"].append(response_data["token_multiplier"])
            results["variants"][variant_name]["response_times"].append(response_data["response_time"])
    
    # 计算统计
    for variant_name, data in results["variants"].items():
        data["avg_accuracy"] = sum(data["accuracies"]) / len(data["accuracies"])
        data["avg_token_multiplier"] = sum(data["token_multipliers"]) / len(data["token_multipliers"])
        data["avg_response_time"] = sum(data["response_times"]) / len(data["response_times"])
    
    return results

def print_results(results: dict):
    """打印结果"""
    print("\n" + "="*60)
    print("📊 NameIndex Benchmark Results")
    print("="*60)
    print(f"Model: {results['model']}")
    
    best_variant = None
    best_accuracy = 0
    
    for variant_name, data in results["variants"].items():
        accuracy_pct = data["avg_accuracy"] * 100
        token_pct = (data["avg_token_multiplier"] - 1) * 100
        time_pct = (data["avg_response_time"] / results["variants"]["baseline"]["avg_response_time"] - 1) * 100
        
        baseline_acc = results["variants"]["baseline"]["avg_accuracy"]
        improvement = (data["avg_accuracy"] - baseline_acc) / baseline_acc * 100
        
        print(f"\n🎯 {variant_name}")
        print(f"  准率: {accuracy_pct:.1f}%")
        if variant_name != "baseline":
            print(f"  提升: +{improvement:.1f}%")
        print(f"  Token: +{token_pct:.0f}%")
        print(f"  速度: {time_pct:+.0f}%")
        
        if accuracy_pct > best_accuracy:
            best_accuracy = accuracy_pct
            best_variant = variant_name
    
    print("\n" + "="*60)
    print(f"🏆 Best: {best_variant} ({best_accuracy:.1f}%)")
    print("="*60)

def save_results(results: dict, filename: str = "benchmark_results.json"):
    """保存结果"""
    with open(filename, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)
    print(f"\n💾 Results saved to {filename}")

if __name__ == "__main__":
    print("🔁 Prompt Repeater v2 - NameIndex Benchmark")
    print("基于 arXiv:2512.14982 'Prompt Repetition Improves Non-Reasoning LLMs'")
    
    models = ["Gemini", "Claude", "GPT-4", "DeepSeek"]
    
    all_results = {}
    for model in models:
        results = run_benchmark(model, iterations=5)
        all_results[model] = results
        print_results(results)
    
    save_results(all_results, "all_benchmark_results.json")
    print("\n✅ Benchmark complete!")
