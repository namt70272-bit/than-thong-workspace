# Iffy Community License 1.0

https://github.com/anti-work/iffy/LICENSE.md

## Acceptance

In order to get any license under these terms, you must agree
to them as both strict obligations and conditions to all
your licenses.

## Copyright License

The licensor grants you a copyright license for the
software to do everything you might do with the software
that would otherwise infringe the licensor's copyright, but only
as long as you meet all the conditions below.

## Small Business

You may use the software under this license only if your company has
(1) less than 1 million USD (2024) total revenue in the prior
tax year, and (2) less than 10 million USD (2024) GMV (Gross
Merchandise Value). Adjust this revenue threshold for inflation according
to the United States Bureau of Labor Statistics' consumer price
index for all urban consumers, U.S. city average, for all items,
not seasonally adjusted, 1982–1984=100 reference base. If you
exceed either of these limits, your license ends.
You may contact the licensor to discuss an alternative license.

## Notices

You may distribute copies of the software, but you must
ensure that anyone who gets a copy of any part of
the software from you also gets a copy of these terms or the
URL for them above, as well as copies of any plain-text lines
beginning with `Required Notice:` that the licensor provided
with the software. For example:

> Required Notice: Copyright 2024-present Gumroad, Inc.

## Patent License

The licensor grants you a patent license for the software that
covers patent claims the licensor can license, or becomes able
to license, that you would infringe by using the software. This license
is also subject to the Small Business limitation above.

## No Other Rights

These terms do not allow you to sublicense or transfer any of
your licenses to anyone else, or prevent the licensor from
granting licenses to anyone else. These terms do not imply
any other licenses.

## Patent Defense

If you make any written claim that the software infringes or
contributes to infringement of any patent, your patent license
for the software granted under these terms ends immediately. If
your company makes such a claim, your patent license ends
immediately for work on behalf of your company.

## Violations

The first time you are notified in writing that you have
violated any of these terms, or done anything with the software
not covered by your licenses, your licenses can nonetheless
continue if you come into full compliance with these terms,
and take practical steps to correct past violations, within
30 days of receiving notice. Otherwise, all your licenses
end immediately.

## No Liability

**_As far as the law allows, the software comes as is, without
any warranty or condition, and the licensor will not be liable
to you for any damages arising out of these terms or the use
or nature of the software, under any kind of legal claim. If this disclaimer
is unenforceable under your local law, this license is void._**

## Definitions

The **licensor** is Gumroad, Inc.

The **software** is the software the licensor makes
available under these terms.

**You** refers to the individual or entity agreeing to these
terms.

**Your company** is any legal entity, sole proprietorship,
or other kind of organization that you work for, plus all
organizations that have control over, are under the control of,
or are under common control with that organization. **Control**
means ownership of substantially all the assets of an entity,
or the power to direct its management and policies by vote,
contract, or otherwise. Control can be direct or indirect.

**Your licenses** are all the licenses granted to you for the
software under these terms.

**Use** means anything you do with the software requiring one
of your licenses.
