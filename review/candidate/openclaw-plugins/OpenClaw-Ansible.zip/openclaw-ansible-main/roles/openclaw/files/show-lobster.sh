#!/bin/bash
cat << 'LOBSTER'
[0;36m
   +====================================================+
   |                                                    |
   |         [0;33mWelcome to OpenClaw! [0;31m🦞[0;36m                    |
   |                                                    |
   |[0;31m                   ,.---._                         [0;36m|
   |[0;31m               ,,,,     /       `,                 [0;36m|
   |[0;31m                \\\\\\   /    '\_  ;                [0;36m|
   |[0;31m                 |||| /\/``-.__\;'                 [0;36m|
   |[0;31m                 ::::/\/_                          [0;36m|
   |[0;31m {{`-.__.-'(`(^^(^^^(^ 9 `.========='              [0;36m|
   |[0;31m{{{{{{ { ( ( (  (   (-----:=                      [0;36m|
   |[0;31m {{.-'~~'-.(,(,,(,,,(__6_.'=========.              [0;36m|
   |[0;31m                 ::::\/\                           [0;36m|
   |[0;31m                 |||| \/\  ,-'/,                   [0;36m|
   |[0;31m                ////   \ `` _/ ;                   [0;36m|
   |[0;31m               ''''     \  `  .'                   [0;36m|
   |[0;31m                         `---'                     [0;36m|
   |                                                    |
   |           [0;32m✅  Installation Successful![0;36m             |
   |                                                    |
   +====================================================+[0m
LOBSTER

echo ""
echo "🔒 Security Status:"
echo "  - UFW Firewall: ENABLED"
echo "  - Open Ports: SSH (22) + Tailscale (41641/udp)"
echo "  - Docker isolation: ACTIVE"
echo ""
echo "📚 Documentation: https://docs.openclaw.ai"
echo ""
