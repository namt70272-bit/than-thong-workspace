# Kế hoạch xây dựng hệ thống RAG (rag-system-ttdev)

Hệ thống RAG (Retrieval-Augmented Generation) này được thiết kế để cung cấp tri thức bổ sung cho Minh Kiên, giúp trả lời chính xác các yêu cầu của Thầy dựa trên dữ liệu nội bộ trước khi đưa qua mô hình AI để suy luận hoặc thực hiện nhiệm vụ.

## 1. Mục tiêu
- Xây dựng kho tri thức số từ các tài liệu Thầy cung cấp (.txt, .md, .pdf, .docx).
- Cung cấp khả năng truy vấn ngữ nghĩa nhanh chóng và chính xác.
- Tích hợp trực tiếp vào quy trình làm việc của Minh Kiên để nâng cao chất lượng phản hồi.

## 2. Các thành phần chính
- **Data Ingestion (Nạp dữ liệu):** Thu thập và xử lý các tệp tin từ thư mục tri thức.
- **Chunking (Cắt nhỏ):** Chia nhỏ tài liệu thành các đoạn văn bản có ý nghĩa để tối ưu hóa việc tìm kiếm.
- **Embedding (Số hóa):** Sử dụng mô hình chuyên dụng để chuyển văn bản thành vector.
- **Vector Database (Cơ sở dữ liệu vector):** Lưu trữ và quản lý các vector (Sử dụng ChromaDB).
- **Retrieval Engine (Bộ truy vấn):** Tìm kiếm các đoạn văn bản liên quan nhất dựa trên câu hỏi của Thầy.

## 3. Lộ trình thực hiện (Roadmap)
### Giai đoạn 1: Thiết lập môi trường
- Tạo cấu trúc thư mục dự án.
- Thiết lập Python Virtual Environment (.venv).
- Cài đặt các thư viện cần thiết: `chromadb`, `sentence-transformers`, `langchain` (nếu cần).

### Giai đoạn 2: Xây dựng Core RAG
- Viết script `ingest.py` để quét và nạp tài liệu vào ChromaDB.
- Viết script `query.py` để thực hiện tìm kiếm ngữ nghĩa.

### Giai đoạn 3: Tối ưu hóa và Tích hợp
- Thử nghiệm với các tham số chunking khác nhau.
- Tạo một "Skill" hoặc script CLI để con (Kiên) có thể tự gọi mỗi khi cần tra cứu tri thức cho Thầy.

## 4. Cách sử dụng dự kiến
1. Thầy bỏ tài liệu mới vào thư mục `knowledge/`.
2. Chạy lệnh `python ingest.py` để cập nhật bộ não.
3. Khi Thầy hỏi, con sẽ tự động thực hiện `python query.py` để tìm ngữ cảnh trước khi trả lời.

---
*Ghi chú: Đây là kế hoạch sơ bộ, con sẽ điều chỉnh linh hoạt theo yêu cầu thực tế của Thầy.*