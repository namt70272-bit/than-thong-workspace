// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

using Azure.Core;
using Azure.Identity;
using Microsoft.Extensions.Logging;
using Microsoft.Agents.A365.DevTools.Cli.Constants;
using Microsoft.Agents.A365.DevTools.Cli.Exceptions;
using Microsoft.Agents.A365.DevTools.Cli.Models;
using Microsoft.Agents.A365.DevTools.Cli.Services.Helpers;
using System.Text.Json;

namespace Microsoft.Agents.A365.DevTools.Cli.Services;

/// <summary>
/// Abstraction over MSAL token acquisition used by ArmApiService and GraphApiService.
/// Enables test substitution without triggering real interactive authentication.
/// Co-located with AuthenticationService per the related-interfaces convention.
/// </summary>
public interface IAuthenticationService
{
    Task<string> GetAccessTokenAsync(
        string resourceUrl,
        string? tenantId = null,
        bool forceRefresh = false,
        string? clientId = null,
        IEnumerable<string>? scopes = null,
        bool useInteractiveBrowser = true,
        string? userId = null);

    Task<string?> ResolveLoginHintFromCacheAsync();
}

/// <summary>
/// Service for handling authentication to Agent 365 Tools and Microsoft Graph API.
///
/// AUTHENTICATION STRATEGY:
/// - Uses interactive authentication by default (no device code flow)
/// - Implements comprehensive token caching to minimize authentication prompts
/// - Typical user experience: 1-2 authentication prompts for entire CLI workflow
///
/// TOKEN CACHING:
/// - Cache Location: %LocalApplicationData%\Agent365\token-cache.json (Windows)
/// - Cache Key Format: {resourceUrl}:tenant:{tenantId}[:user:{userId}]
/// - Cache Expiration: Validated with 5-minute buffer before token expiry
/// - Reuse Across Commands: All CLI commands share the same token cache
///
/// AUTHENTICATION FLOW:
/// 1. Check cache for valid token (tenant-specific)
/// 2. If cache miss or expired: Prompt for interactive authentication
/// 3. Cache new token for future CLI command invocations
/// 4. Token persists across CLI sessions until expiration
///
/// MULTI-COMMAND WORKFLOW:
/// - First command (e.g., 'setup all'): 1-2 authentication prompts
/// - Subsequent commands: 0 prompts (uses cached tokens)
/// - Token refresh: Automatic when within 5 minutes of expiration
/// </summary>
public class AuthenticationService : IAuthenticationService
{
    private readonly ILogger<AuthenticationService> _logger;
    private readonly string _tokenCachePath;

    public AuthenticationService(ILogger<AuthenticationService> logger)
    {
        _logger = logger;
        var appDataPath = Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData);
        var cacheDir = Path.Combine(appDataPath, AuthenticationConstants.ApplicationName);
        Directory.CreateDirectory(cacheDir);
        _tokenCachePath = Path.Combine(cacheDir, AuthenticationConstants.TokenCacheFileName);
    }

    /// <summary>
    /// Gets an access token for Agent 365, using cached token if valid or prompting for authentication
    /// </summary>
    /// <param name="resourceUrl">The resource URL to request a token for (e.g., https://agent365.svc.cloud.microsoft or environment-specific URL)</param>
    /// <param name="tenantId">Optional tenant ID for single-tenant authentication. If provided and cached token is for different tenant, forces re-authentication</param>
    /// <param name="forceRefresh">Force token refresh even if cached token is valid</param>
    /// <param name="clientId">Optional client ID for authentication. If not provided, uses PowerShell client ID</param>
    /// <param name="scopes">Optional explicit scopes to request. If not provided, uses .default scope pattern</param>
    public async Task<string> GetAccessTokenAsync(
        string resourceUrl,
        string? tenantId = null,
        bool forceRefresh = false,
        string? clientId = null,
        IEnumerable<string>? scopes = null,
        bool useInteractiveBrowser = true,
        string? userId = null)
    {
        // Build cache key based on resource, tenant, and user identity.
        // Including userId ensures that cached tokens are not shared across different users
        // (e.g., a developer's cached token is not reused when an admin runs cleanup).
        // Azure AD returns tokens with all consented scopes regardless of which scopes are requested,
        // so we don't include scopes in the cache key to avoid duplicate cache entries for the same token.
        // The scopes parameter is still passed to Azure AD for incremental consent and validation.
        string cacheKey = string.IsNullOrWhiteSpace(tenantId)
            ? resourceUrl
            : $"{resourceUrl}:tenant:{tenantId}";
        if (!string.IsNullOrWhiteSpace(userId))
            cacheKey = $"{cacheKey}:user:{userId}";
        _logger.LogDebug("ATG cache key: {CacheKey}", cacheKey);

        // Try to load cached token for this cache key
        if (!forceRefresh && File.Exists(_tokenCachePath))
        {
            try
            {
                var cachedToken = await LoadCachedTokenAsync(cacheKey);
                if (cachedToken != null && !IsTokenExpired(cachedToken))
                {
                    // If tenant ID is specified, validate that cached token is for the correct tenant
                    if (!string.IsNullOrWhiteSpace(tenantId))
                    {
                        if (string.IsNullOrWhiteSpace(cachedToken.TenantId))
                        {
                            _logger.LogWarning("Cached token does not have tenant information. Re-authenticating with tenant {TenantId}...", tenantId);
                            // Fall through to re-authenticate
                        }
                        else if (!string.Equals(cachedToken.TenantId, tenantId, StringComparison.OrdinalIgnoreCase))
                        {
                            _logger.LogWarning("Cached token is for tenant {CachedTenant} but requested tenant is {RequestedTenant}. Re-authenticating...",
                                cachedToken.TenantId, tenantId);
                            // Fall through to re-authenticate
                        }
                        else
                        {
                            // Validate UPN: cached token must be for the same user identity as the cache key.
                            // Prevents returning a guest/cross-app token stored under a member UPN key.
                            if (!string.IsNullOrWhiteSpace(userId))
                            {
                                var tokenUpn = TryExtractUpnFromJwt(cachedToken.AccessToken);
                                if (!string.IsNullOrWhiteSpace(tokenUpn) &&
                                    !string.Equals(tokenUpn, userId, StringComparison.OrdinalIgnoreCase))
                                {
                                    _logger.LogDebug(
                                        "Cached token is for user {TokenUser} but requested user is {RequestedUser}. Re-authenticating...",
                                        tokenUpn, userId);
                                    // Fall through to re-authenticate
                                }
                                else
                                {
                                    _logger.LogDebug("Using cached authentication token for {ResourceUrl} (tenant: {TenantId})",
                                        resourceUrl, tenantId);
                                    return cachedToken.AccessToken;
                                }
                            }
                            else
                            {
                                _logger.LogDebug("Using cached authentication token for {ResourceUrl} (tenant: {TenantId})",
                                    resourceUrl, tenantId);
                                return cachedToken.AccessToken;
                            }
                        }
                    }
                    else
                    {
                        _logger.LogDebug("Using cached authentication token for {ResourceUrl}", resourceUrl);
                        return cachedToken.AccessToken;
                    }
                }
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to load cached token, will re-authenticate");
            }
        }

        // Authenticate interactively with specific tenant and scopes
        _logger.LogDebug("Authentication required for Agent 365 Tools");
        var token = await AuthenticateInteractivelyAsync(resourceUrl, tenantId, clientId, scopes, useInteractiveBrowser, loginHint: userId);

        // Validate the token identity before caching: if a userId was requested,
        // ensure the returned token is actually for that user. WAM may return a
        // guest/cross-app token for an account it considers "equivalent" (same Microsoft
        // account in a different tenant). Caching the wrong token would cause silent
        // failures on the next run.
        if (!string.IsNullOrWhiteSpace(userId))
        {
            var returnedUpn = TryExtractUpnFromJwt(token.AccessToken);
            if (!string.IsNullOrWhiteSpace(returnedUpn) &&
                !string.Equals(returnedUpn, userId, StringComparison.OrdinalIgnoreCase))
            {
                _logger.LogDebug(
                    "Authentication returned token for {ReturnedUser} but {RequestedUser} was requested. Not caching.",
                    returnedUpn, userId);
                // Return the token as-is — it may still be valid for this call.
                // Do not write it to cache under the userId key.
                return token.AccessToken;
            }
        }

        // Cache the token with the appropriate cache key
        await CacheTokenAsync(cacheKey, token);

        return token.AccessToken;
    }

    /// <summary>
    /// Authenticates user interactively using browser or device code flow
    /// </summary>
    /// <param name="resourceUrl">The resource URL to request a token for</param>
    /// <param name="tenantId">Optional tenant ID for single-tenant authentication. If null, uses common tenant</param>
    /// <param name="clientId">Optional client ID for authentication. If not provided, uses PowerShell client ID</param>
    /// <param name="explicitScopes">Optional explicit scopes to request. If not provided, uses .default scope pattern</param>
    /// <param name="useInteractiveBrowser">If true, uses browser authentication with redirect URI; if false, uses device code flow. Default is false for backward compatibility.</param>
    private async Task<TokenInfo> AuthenticateInteractivelyAsync(
        string resourceUrl,
        string? tenantId = null,
        string? clientId = null,
        IEnumerable<string>? explicitScopes = null,
        bool useInteractiveBrowser = false,
        string? loginHint = null)
    {
        // Declare variables outside try block so they're available in catch for logging
        string effectiveTenantId = tenantId ?? "unknown";
        string effectiveClientId = clientId ?? "unknown";
        string[] scopes = Array.Empty<string>();
        
        try
        {
            // Use specific tenant ID if provided, otherwise use common tenant for multi-tenant apps
            effectiveTenantId = string.IsNullOrWhiteSpace(tenantId)
                ? AuthenticationConstants.CommonTenantId
                : tenantId;

            // Determine which scope to use based on the resource URL or App ID
            if (explicitScopes != null && explicitScopes.Any())
            {
                // Construct scope strings for the token request by prefixing with the resource App ID
                // This creates the format required by Azure AD for the TokenRequestContext: {resourceAppId}/{scope}
                // Example: "ea9ffc3e-8a23-4a7d-836d-234d7c7565c1/McpServers.Mail.All"
                scopes = explicitScopes.Select(s => $"{resourceUrl}/{s}").ToArray();
                _logger.LogDebug("Using explicit scopes for authentication: {Scopes}", string.Join(", ", explicitScopes));
                _logger.LogDebug("Formatted as: {FormattedScopes}", string.Join(", ", scopes));
            }
            else
            {
                string scope;
                // Check if this is the production App ID
                if (resourceUrl == McpConstants.WorkIQToolsProdAppId)
                {
                    scope = $"{resourceUrl}/.default";
                    _logger.LogInformation("Authenticating to Agent 365 Tools");
                }
                // Check for Agent 365 endpoint URLs (legacy support)
                else if (resourceUrl.Contains("agent365", StringComparison.OrdinalIgnoreCase))
                {
                    // Use production App ID by default
                    // For non-production environments, users should provide the App ID directly via config
                    // or set environment variable A365_MCP_APP_ID (without environment suffix for backward compatibility)
                    var appId = Environment.GetEnvironmentVariable("A365_MCP_APP_ID") ?? McpConstants.WorkIQToolsProdAppId;

                    if (appId != McpConstants.WorkIQToolsProdAppId)
                    {
                        _logger.LogInformation("Using custom Agent 365 Tools App ID from A365_MCP_APP_ID environment variable");
                    }
                    else
                    {
                        _logger.LogInformation("Authenticating to Agent 365 Tools");
                    }

                    scope = $"{appId}/.default";
                }
                else
                {
                    // Default: use the resource as-is with /.default suffix (likely an App ID)
                    // This allows passing custom App IDs directly via config
                    scope = resourceUrl.EndsWith("/.default", StringComparison.OrdinalIgnoreCase)
                        ? resourceUrl
                        : $"{resourceUrl.TrimEnd('/')}/.default";
                    _logger.LogDebug("Using custom resource for authentication: {Resource}", resourceUrl);
                }
                scopes = [scope];
                _logger.LogDebug("Token scope: {Scope}", scope);
            }

            _logger.LogDebug("Authenticating for tenant: {TenantId}", effectiveTenantId);

            // Use provided client ID or default to PowerShell client ID
            effectiveClientId = string.IsNullOrWhiteSpace(clientId) 
                ? AuthenticationConstants.PowershellClientId 
                : clientId;

            TokenCredential credential;

            if (useInteractiveBrowser)
            {
                // Use MsalBrowserCredential which handles WAM on Windows and browser on other platforms
                _logger.LogDebug("Using interactive authentication (browser/WAM)...");

                credential = CreateBrowserCredential(effectiveClientId, effectiveTenantId, loginHint: loginHint);
            }
            else
            {
                // Device code flow - works in all environments including SSH/remote sessions
                _logger.LogInformation("Using device code authentication...");
                _logger.LogInformation("Please sign in with your Microsoft account");
                credential = CreateDeviceCodeCredential(effectiveClientId, effectiveTenantId);
            }

            var tokenRequestContext = new TokenRequestContext(scopes);
            AccessToken tokenResult;
            try
            {
                tokenResult = await credential.GetTokenAsync(tokenRequestContext, default);
            }
            catch (MsalAuthenticationFailedException ex) when (useInteractiveBrowser && ex.InnerException is PlatformNotSupportedException)
            {
                _logger.LogWarning("Browser authentication is not supported on this platform, falling back to device code flow...");
                _logger.LogInformation("Using device code authentication...");
                _logger.LogInformation("Please sign in with your Microsoft account");
                var deviceCodeCredential = CreateDeviceCodeCredential(effectiveClientId, effectiveTenantId);
                tokenResult = await deviceCodeCredential.GetTokenAsync(tokenRequestContext, default);
            }
            _logger.LogInformation("Authentication successful!");

            return new TokenInfo
            {
                AccessToken = tokenResult.Token,
                ExpiresOn = tokenResult.ExpiresOn.UtcDateTime,
                TenantId = effectiveTenantId
            };
        }
        catch (MsalAuthenticationFailedException ex) when (ex.Message.Contains("code_expired") || ex.InnerException?.Message.Contains("code_expired") == true)
        {
            _logger.LogError("Device code expired - authentication not completed in time");
            throw new AzureAuthenticationException("Device code authentication timed out - please complete authentication promptly when retrying");
        }
        catch (MsalAuthenticationFailedException ex)
        {
            _logger.LogError("Interactive authentication failed: {Message}", ex.Message);
            _logger.LogError("Exception type: {Type}", ex.GetType().FullName);
            
            if (ex.InnerException != null)
            {
                _logger.LogError("Inner exception: {InnerMessage}", ex.InnerException.Message);
                _logger.LogError("Inner exception type: {InnerType}", ex.InnerException.GetType().FullName);
            }
            
            // Log more details for debugging
            _logger.LogError("Requested scopes: {Scopes}", string.Join(", ", scopes));
            _logger.LogError("Tenant ID: {TenantId}", effectiveTenantId);
            _logger.LogError("Client ID: {ClientId}", effectiveClientId);
            
            throw new AzureAuthenticationException($"Authentication failed: {ex.Message}");
        }
        catch (Exception ex)
        {
            _logger.LogError("Unexpected authentication error: {Message}", ex.Message);
            _logger.LogError("Exception type: {Type}", ex.GetType().FullName);
            
            if (ex.InnerException != null)
            {
                _logger.LogError("Inner exception: {InnerMessage}", ex.InnerException.Message);
            }
            
            throw new AzureAuthenticationException($"Unexpected authentication error: {ex.Message}");
        }
    }

    /// <summary>
    /// Loads cached token for a specific resourceUrl from disk
    /// </summary>
    private async Task<TokenInfo?> LoadCachedTokenAsync(string resourceUrl)
    {
        if (!File.Exists(_tokenCachePath))
            return null;

        var json = await File.ReadAllTextAsync(_tokenCachePath);
        var cache = JsonSerializer.Deserialize<TokenCache>(json) ?? new TokenCache();
        cache.Tokens.TryGetValue(resourceUrl, out var token);
        return token;
    }

    /// <summary>
    /// Caches token for a specific resourceUrl to disk
    /// </summary>
    private async Task CacheTokenAsync(string resourceUrl, TokenInfo token)
    {
        TokenCache cache;
        if (File.Exists(_tokenCachePath))
        {
            var json = await File.ReadAllTextAsync(_tokenCachePath);
            cache = JsonSerializer.Deserialize<TokenCache>(json) ?? new TokenCache();
        }
        else
        {
            cache = new TokenCache();
        }

        cache.Tokens[resourceUrl] = token;
        var updatedJson = JsonSerializer.Serialize(cache, new JsonSerializerOptions { WriteIndented = true });
        await File.WriteAllTextAsync(_tokenCachePath, updatedJson);
        _logger.LogDebug("Authentication token cached for {ResourceUrl} at: {Path}", resourceUrl, _tokenCachePath);
    }

    /// <summary>
    /// Checks if token is expired (with buffer to prevent using tokens that expire during a request)
    /// </summary>
    private bool IsTokenExpired(TokenInfo token)
    {
        return token.ExpiresOn <= DateTime.UtcNow.AddMinutes(AuthenticationConstants.TokenExpirationBufferMinutes);
    }

    /// <summary>
    /// Gets an access token with explicit scopes for MCP servers or other resources
    /// This is a convenience wrapper around GetAccessTokenAsync with scope validation
    /// </summary>
    /// <param name="resourceAppId">The resource application ID (e.g., Agent 365 Tools App ID)</param>
    /// <param name="scopes">Explicit list of scopes to request (e.g., ["McpServers.Mail.All", "McpServers.Calendar.All"])</param>
    /// <param name="tenantId">Optional tenant ID for single-tenant authentication</param>
    /// <param name="forceRefresh">Force token refresh even if cached token is valid</param>
    /// <param name="clientId">Optional client ID for authentication. If not provided, uses PowerShell client ID</param>
    /// <param name="userId">Optional UPN/email to pre-select the account for WAM and silent acquisition.
    /// When provided, WAM will target this identity instead of the first cached account.</param>
    /// <returns>Access token with the requested scopes</returns>
    public async Task<string> GetAccessTokenWithScopesAsync(
        string resourceAppId,
        IEnumerable<string> scopes,
        string? tenantId = null,
        bool forceRefresh = false,
        string? clientId = null,
        bool useInteractiveBrowser = true,
        string? userId = null)
    {
        if (string.IsNullOrWhiteSpace(resourceAppId))
            throw new ArgumentException("Resource App ID cannot be empty", nameof(resourceAppId));

        if (scopes == null || !scopes.Any())
            throw new ArgumentException("At least one scope must be specified", nameof(scopes));

        _logger.LogInformation("Requesting token for resource {ResourceAppId} with explicit scopes: {Scopes}",
            resourceAppId, string.Join(", ", scopes));

        // Delegate to the consolidated GetAccessTokenAsync method
        return await GetAccessTokenAsync(resourceAppId, tenantId, forceRefresh, clientId, scopes, useInteractiveBrowser, userId);
    }

    /// <summary>
    /// Gets an access token with scope resolution for MCP servers
    /// This method uses the .default scope pattern for backward compatibility
    /// For explicit scope control, use GetAccessTokenWithScopesAsync instead
    /// </summary>
    /// <param name="resourceUrl">The resource URL to request a token for</param>
    /// <param name="manifestPath">Optional path to ToolingManifest.json for MCP scope resolution</param>
    /// <param name="tenantId">Optional tenant ID for single-tenant authentication</param>
    /// <param name="forceRefresh">Force token refresh even if cached token is valid</param>
    public async Task<string> GetAccessTokenForMcpAsync(string resourceUrl, string? manifestPath = null, string? tenantId = null, bool forceRefresh = false)
    {
        var scopes = ResolveScopesForResource(resourceUrl, manifestPath);

        // For now, continue using the same authentication pattern but log the resolved scopes
        _logger.LogInformation("Resolved scopes for resource {ResourceUrl}: {Scopes}", resourceUrl, string.Join(", ", scopes));

        // Use the existing method for backward compatibility
        // For explicit scope control, callers should use GetAccessTokenWithScopesAsync
        var loginHint = await AzCliHelper.ResolveLoginHintAsync();
        return await GetAccessTokenAsync(resourceUrl, tenantId, forceRefresh, userId: loginHint);
    }

    /// <summary>
    /// Resolves the appropriate authentication scopes based on resource URL and MCP manifest
    /// </summary>
    /// <param name="resourceUrl">The resource URL being accessed</param>
    /// <param name="manifestPath">Optional path to ToolingManifest.json</param>
    /// <returns>Array of scope strings to request for authentication</returns>
    public string[] ResolveScopesForResource(string resourceUrl, string? manifestPath = null)
    {
        // Default to Agent 365 Tools resource app ID scope for backward compatibility
        var scope = $"{McpConstants.WorkIQToolsProdAppId}/.default";
        var defaultScopes = new[] { scope };

        // If no manifest path provided, try to find it in current directory
        if (string.IsNullOrWhiteSpace(manifestPath))
        {
            var currentDir = Environment.CurrentDirectory;
            manifestPath = Path.Combine(currentDir, McpConstants.ToolingManifestFileName);

            if (!File.Exists(manifestPath))
            {
                _logger.LogDebug("No ToolingManifest.json found, using default Agent 365 Tools resource app ID scope");
                return defaultScopes;
            }
        }

        // Try to read MCP manifest and find relevant scopes
        try
        {
            if (!File.Exists(manifestPath))
            {
                _logger.LogDebug("ToolingManifest.json not found at {Path}, using default scope", manifestPath);
                return defaultScopes;
            }

            var manifestJson = File.ReadAllText(manifestPath);
            var manifest = JsonSerializer.Deserialize<ToolingManifest>(manifestJson);

            if (manifest?.McpServers == null || manifest.McpServers.Length == 0)
            {
                _logger.LogDebug("No MCP servers found in manifest, using default scope");
                return defaultScopes;
            }

            // Look for MCP servers that match the resource URL
            var relevantScopes = new List<string>();

            foreach (var server in manifest.McpServers)
            {
                // Check if this server's URL matches the resource URL being accessed
                if (!string.IsNullOrWhiteSpace(server.Url))
                {
                    try
                    {
                        var serverUri = new Uri(server.Url);
                        var resourceUri = new Uri(resourceUrl);

                        // Match by host (domain)
                        if (string.Equals(serverUri.Host, resourceUri.Host, StringComparison.OrdinalIgnoreCase))
                        {
                            if (!string.IsNullOrWhiteSpace(server.Scope))
                            {
                                relevantScopes.Add(server.Scope);
                                _logger.LogDebug("Found matching MCP server {ServerName} with scope: {Scope}",
                                    server.McpServerName, server.Scope);
                            }
                        }
                    }
                    catch (UriFormatException ex)
                    {
                        _logger.LogWarning("Invalid URL format for MCP server {ServerName}: {Url} - {Error}",
                            server.McpServerName, server.Url, ex.Message);
                    }
                }
            }

            // If we found relevant scopes, use them; otherwise use default
            if (relevantScopes.Count > 0)
            {
                var uniqueScopes = relevantScopes.Distinct().ToArray();
                _logger.LogInformation("Using MCP-specific scopes for {ResourceUrl}: {Scopes}",
                    resourceUrl, string.Join(", ", uniqueScopes));
                return uniqueScopes;
            }

        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to resolve MCP scopes from manifest, using default scope");
        }

        _logger.LogDebug("No matching MCP servers found, using default Power Platform API scope");
        return defaultScopes;
    }

    /// <summary>
    /// Validates that the current authentication token has the required scopes for an MCP server
    /// </summary>
    /// <param name="resourceUrl">The resource URL being accessed</param>
    /// <param name="manifestPath">Optional path to ToolingManifest.json</param>
    /// <returns>True if authentication should work, false if re-authentication may be needed</returns>
    public bool ValidateScopesForResource(string resourceUrl, string? manifestPath = null)
    {
        try
        {
            var requiredScopes = ResolveScopesForResource(resourceUrl, manifestPath);

            // For now, this is a basic validation - in a full implementation,
            // we would decode the JWT token and check the scopes claim
            _logger.LogInformation("Validation check - Required scopes for {ResourceUrl}: {Scopes}",
                resourceUrl, string.Join(", ", requiredScopes));

            // Return true for now since we're using the Power Platform API scope pattern
            // which provides broad access through the api://appid/.default pattern
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Failed to validate scopes for resource {ResourceUrl}", resourceUrl);
            return false;
        }
    }

    /// <summary>
    /// Creates a browser credential for interactive authentication.
    /// Protected virtual to allow substitution in tests.
    /// </summary>
    protected virtual TokenCredential CreateBrowserCredential(string clientId, string tenantId, string? loginHint = null)
        => new MsalBrowserCredential(clientId, tenantId, redirectUri: null, _logger, loginHint: loginHint);

    /// <summary>
    /// Creates a DeviceCodeCredential configured for interactive device code authentication.
    /// This flow works in all environments including SSH, remote sessions, and platforms where
    /// browser-based authentication is unavailable.
    /// Protected virtual to allow substitution in tests.
    /// </summary>
    protected virtual TokenCredential CreateDeviceCodeCredential(string clientId, string tenantId)
    {
        return new DeviceCodeCredential(new DeviceCodeCredentialOptions
        {
            TenantId = tenantId,
            ClientId = clientId,
            AuthorityHost = AzureAuthorityHosts.AzurePublicCloud,
            TokenCachePersistenceOptions = new TokenCachePersistenceOptions
            {
                Name = AuthenticationConstants.ApplicationName
            },
            DeviceCodeCallback = (code, cancellation) =>
            {
                _logger.LogInformation("");
                _logger.LogInformation("==========================================================================");
                _logger.LogInformation("To sign in, use a web browser to open the page:");
                _logger.LogInformation("    {VerificationUri}", code.VerificationUri);
                _logger.LogInformation("");
                _logger.LogInformation("And enter the code: {UserCode}", code.UserCode);
                _logger.LogInformation("==========================================================================");
                _logger.LogInformation("");
                return Task.CompletedTask;
            }
        });
    }

    /// <summary>
    /// Resolves the login hint (UPN) from the persistent token cache by decoding a cached JWT.
    /// Used to pre-select the correct account for WAM/MSAL when az CLI is not available.
    /// Returns null if no cached token exists or the UPN claim cannot be read.
    /// </summary>
    public async Task<string?> ResolveLoginHintFromCacheAsync()
    {
        if (!File.Exists(_tokenCachePath))
            return null;
        try
        {
            var json = await File.ReadAllTextAsync(_tokenCachePath);
            var cache = JsonSerializer.Deserialize<TokenCache>(json);
            if (cache?.Tokens == null) return null;
            foreach (var entry in cache.Tokens.Values)
            {
                var upn = TryExtractUpnFromJwt(entry.AccessToken);
                if (!string.IsNullOrWhiteSpace(upn))
                    return upn;
            }
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "Failed to resolve login hint from token cache");
        }
        return null;
    }

    private static string? TryExtractUpnFromJwt(string? jwt)
    {
        if (string.IsNullOrWhiteSpace(jwt)) return null;
        try
        {
            var parts = jwt.Split('.');
            if (parts.Length < 2) return null;
            var payload = parts[1];
            // JWT uses Base64Url encoding: replace URL-safe chars before standard Base64 decode.
            payload = payload.Replace('-', '+').Replace('_', '/');
            // Restore Base64 padding stripped by JWT encoding.
            payload = payload.PadRight(payload.Length + (4 - payload.Length % 4) % 4, '=');
            var bytes = Convert.FromBase64String(payload);
            using var doc = JsonDocument.Parse(bytes);
            if (doc.RootElement.TryGetProperty("upn", out var upn) && !string.IsNullOrWhiteSpace(upn.GetString()))
                return upn.GetString();
            if (doc.RootElement.TryGetProperty("preferred_username", out var pref) && !string.IsNullOrWhiteSpace(pref.GetString()))
                return pref.GetString();
            if (doc.RootElement.TryGetProperty("unique_name", out var uniqueName) && !string.IsNullOrWhiteSpace(uniqueName.GetString()))
                return uniqueName.GetString();
        }
        catch { } // Static helper — no logger access. Caller logs via ResolveLoginHintFromCacheAsync.
        return null;
    }

    /// <summary>
    /// Clears cached authentication token(s)
    /// </summary>
    public void ClearCache()
    {
        if (File.Exists(_tokenCachePath))
        {
            File.Delete(_tokenCachePath);
            _logger.LogInformation("Authentication cache cleared");
        }
    }

    private class TokenInfo
    {
        public string AccessToken { get; set; } = string.Empty;
        public DateTime ExpiresOn { get; set; }
        public string? TenantId { get; set; }
    }

    private class TokenCache
    {
        public Dictionary<string, TokenInfo> Tokens { get; set; } = new();
    }
}