import { cli, Strategy } from '../../registry.js';

cli({
  site: 'twitter',
  name: 'article',
  description: 'Fetch a Twitter Article (long-form content) and export as Markdown',
  domain: 'x.com',
  strategy: Strategy.COOKIE,
  browser: true,
  args: [
    { name: 'tweet_id', type: 'string', positional: true, required: true, help: 'Tweet ID or URL containing the article' },
  ],
  columns: ['title', 'author', 'content', 'url'],
  func: async (page, kwargs) => {
    // Extract tweet ID from URL if needed
    let tweetId = kwargs.tweet_id;
    const urlMatch = tweetId.match(/\/(?:status|article)\/(\d+)/);
    if (urlMatch) tweetId = urlMatch[1];

    // Navigate to the tweet page for cookie context
    await page.goto(`https://x.com/i/status/${tweetId}`);
    await page.wait(3);

    const result = await page.evaluate(`
      async () => {
        const tweetId = "${tweetId}";
        const ct0 = document.cookie.split(';').map(c=>c.trim()).find(c=>c.startsWith('ct0='))?.split('=')[1];
        if (!ct0) return {error: 'No ct0 cookie — not logged into x.com'};

        const bearer = 'AAAAAAAAAAAAAAAAAAAAANRILgAAAAAAnNwIzUejRCOuH5E6I8xnZz4puTs%3D1Zv7ttfk8LF81IUq16cHjhLTvJu4FA33AGWWjCpTnA';
        const headers = {
          'Authorization': 'Bearer ' + decodeURIComponent(bearer),
          'X-Csrf-Token': ct0,
          'X-Twitter-Auth-Type': 'OAuth2Session',
          'X-Twitter-Active-User': 'yes'
        };

        const variables = JSON.stringify({
          tweetId: tweetId,
          withCommunity: false,
          includePromotedContent: false,
          withVoice: false,
        });
        const features = JSON.stringify({
          longform_notetweets_consumption_enabled: true,
          responsive_web_twitter_article_tweet_consumption_enabled: true,
          longform_notetweets_rich_text_read_enabled: true,
          longform_notetweets_inline_media_enabled: true,
          articles_preview_enabled: true,
          responsive_web_graphql_exclude_directive_enabled: true,
          verified_phone_label_enabled: false,
        });
        const fieldToggles = JSON.stringify({
          withArticleRichContentState: true,
          withArticlePlainText: true,
        });

        // Dynamically resolve queryId: GitHub community source → JS bundle scan → hardcoded fallback
        async function resolveQueryId(operationName, fallbackId) {
          try {
            const ghResp = await fetch('https://raw.githubusercontent.com/fa0311/twitter-openapi/refs/heads/main/src/config/placeholder.json');
            if (ghResp.ok) {
              const data = await ghResp.json();
              const entry = data[operationName];
              if (entry && entry.queryId) return entry.queryId;
            }
          } catch {}
          try {
            const scripts = performance.getEntriesByType('resource')
              .filter(r => r.name.includes('client-web') && r.name.endsWith('.js'))
              .map(r => r.name);
            for (const scriptUrl of scripts.slice(0, 15)) {
              try {
                const text = await (await fetch(scriptUrl)).text();
                const re = new RegExp('queryId:"([A-Za-z0-9_-]+)"[^}]{0,200}operationName:"' + operationName + '"');
                const m = text.match(re);
                if (m) return m[1];
              } catch {}
            }
          } catch {}
          return fallbackId;
        }

        const queryId = await resolveQueryId('TweetResultByRestId', '7xflPyRiUxGVbJd4uWmbfg');
        const url = '/i/api/graphql/' + queryId + '/TweetResultByRestId?variables='
          + encodeURIComponent(variables)
          + '&features=' + encodeURIComponent(features)
          + '&fieldToggles=' + encodeURIComponent(fieldToggles);

        const resp = await fetch(url, {headers, credentials: 'include'});
        if (!resp.ok) return {error: 'HTTP ' + resp.status, hint: 'Tweet may not exist or queryId expired'};
        const d = await resp.json();

        const result = d.data?.tweetResult?.result;
        if (!result) return {error: 'Article not found'};

        // Unwrap TweetWithVisibilityResults
        const tw = result.tweet || result;
        const legacy = tw.legacy || {};
        const user = tw.core?.user_results?.result;
        const screenName = user?.legacy?.screen_name || user?.core?.screen_name || 'unknown';

        // Extract article content
        const articleResults = tw.article?.article_results?.result;
        if (!articleResults) {
          // Fallback: return note_tweet text if present
          const noteText = tw.note_tweet?.note_tweet_results?.result?.text;
          if (noteText) {
            return [{
              title: '(Note Tweet)',
              author: screenName,
              content: noteText,
              url: 'https://x.com/' + screenName + '/status/' + tweetId,
            }];
          }
          return {error: 'Tweet ' + tweetId + ' has no article content'};
        }

        const title = articleResults.title || '(Untitled)';
        const contentState = articleResults.content_state || {};
        const blocks = contentState.blocks || [];

        // Convert draft.js blocks to Markdown
        const parts = [];
        let orderedCounter = 0;
        for (const block of blocks) {
          const blockType = block.type || 'unstyled';
          if (blockType === 'atomic') continue;
          const text = block.text || '';
          if (!text) continue;
          if (blockType !== 'ordered-list-item') orderedCounter = 0;

          if (blockType === 'header-one')           parts.push('# ' + text);
          else if (blockType === 'header-two')      parts.push('## ' + text);
          else if (blockType === 'header-three')    parts.push('### ' + text);
          else if (blockType === 'blockquote')       parts.push('> ' + text);
          else if (blockType === 'unordered-list-item') parts.push('- ' + text);
          else if (blockType === 'ordered-list-item') {
            orderedCounter++;
            parts.push(orderedCounter + '. ' + text);
          }
          else if (blockType === 'code-block')       parts.push('\`\`\`\\n' + text + '\\n\`\`\`');
          else                                       parts.push(text);
        }

        return [{
          title,
          author: screenName,
          content: parts.join('\\n\\n') || legacy.full_text || '',
          url: 'https://x.com/' + screenName + '/status/' + tweetId,
        }];
      }
    `);

    if (result?.error) {
      throw new Error(result.error + (result.hint ? ` (${result.hint})` : ''));
    }

    return result || [];
  }
});
