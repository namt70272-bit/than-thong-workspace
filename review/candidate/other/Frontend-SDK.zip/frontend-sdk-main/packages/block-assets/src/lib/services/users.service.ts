import type { Transport, PageResult } from '@23blocks/contracts';
import { decodeOne, decodePageResult } from '@23blocks/jsonapi-codec';
import type {
  AssetsUser,
  RegisterAssetsUserRequest,
  UpdateAssetsUserRequest,
  ListAssetsUsersParams,
  UserOwnership,
} from '../types/user.js';
import type { Asset } from '../types/asset.js';
import type { AssetsEntity } from '../types/entity.js';
import { assetsUserMapper } from '../mappers/user.mapper.js';
import { assetMapper } from '../mappers/asset.mapper.js';
import { assetsEntityMapper } from '../mappers/entity.mapper.js';

export interface AssetsUsersService {
  /**
   * List asset users with optional filtering and sorting.
   * @returns Paginated list of AssetsUser records with metadata.
   */
  list(params?: ListAssetsUsersParams): Promise<PageResult<AssetsUser>>;

  /**
   * Get a single asset user by unique ID.
   * @returns The matching AssetsUser record.
   */
  get(uniqueId: string): Promise<AssetsUser>;

  /**
   * Register a user in the assets system.
   * @returns The newly registered AssetsUser record.
   */
  register(uniqueId: string, data: RegisterAssetsUserRequest): Promise<AssetsUser>;

  /**
   * Update an asset user.
   * @returns The updated AssetsUser record.
   */
  update(uniqueId: string, data: UpdateAssetsUserRequest): Promise<AssetsUser>;

  /**
   * List entities associated with a user.
   * @returns Array of AssetsEntity records.
   */
  listEntities(uniqueId: string): Promise<AssetsEntity[]>;

  /**
   * List assets assigned to a user.
   * @returns Array of Asset records.
   */
  listAssets(uniqueId: string): Promise<Asset[]>;

  /**
   * List ownership records for a user.
   * @returns Array of UserOwnership records.
   */
  listOwnership(uniqueId: string): Promise<UserOwnership[]>;
}

export function createAssetsUsersService(transport: Transport, _config: { apiKey: string }): AssetsUsersService {
  return {
    async list(params?: ListAssetsUsersParams): Promise<PageResult<AssetsUser>> {
      const queryParams: Record<string, string> = {};
      if (params?.page) queryParams['page'] = String(params.page);
      if (params?.perPage) queryParams['records'] = String(params.perPage);
      if (params?.status) queryParams['status'] = params.status;
      if (params?.search) queryParams['search'] = params.search;

      const response = await transport.get<unknown>('/users', { params: queryParams });
      return decodePageResult(response, assetsUserMapper);
    },

    async get(uniqueId: string): Promise<AssetsUser> {
      const response = await transport.get<unknown>(`/users/${uniqueId}`);
      return decodeOne(response, assetsUserMapper);
    },

    async register(uniqueId: string, data: RegisterAssetsUserRequest): Promise<AssetsUser> {
      const response = await transport.post<unknown>(`/users/${uniqueId}/register`, {
        user: {
          email: data.email,
          name: data.name,
          phone: data.phone,
          payload: data.payload,
        },
      });
      return decodeOne(response, assetsUserMapper);
    },

    async update(uniqueId: string, data: UpdateAssetsUserRequest): Promise<AssetsUser> {
      const response = await transport.put<unknown>(`/users/${uniqueId}`, {
        user: {
          name: data.name,
          phone: data.phone,
          enabled: data.enabled,
          status: data.status,
          payload: data.payload,
        },
      });
      return decodeOne(response, assetsUserMapper);
    },

    async listEntities(uniqueId: string): Promise<AssetsEntity[]> {
      const response = await transport.get<any>(`/users/${uniqueId}/entities`);
      // Could be JSON:API or plain array
      if (response.data && Array.isArray(response.data)) {
        return response.data.map((e: any) => assetsEntityMapper.map({ id: e.id, type: 'entity', attributes: e }, new Map()));
      }
      return (response.entities || response || []).map((e: any) => ({
        id: e.id,
        uniqueId: e.unique_id,
        name: e.name,
        description: e.description,
        entityType: e.entity_type,
        status: e.status,
        enabled: e.enabled ?? true,
        payload: e.payload,
        createdAt: new Date(e.created_at),
        updatedAt: new Date(e.updated_at),
      }));
    },

    async listAssets(uniqueId: string): Promise<Asset[]> {
      const response = await transport.get<any>(`/users/${uniqueId}/assets`);
      if (response.data && Array.isArray(response.data)) {
        return response.data.map((a: any) => assetMapper.map({ id: a.id, type: 'asset', attributes: a }, new Map()));
      }
      return (response.assets || response || []).map((a: any) => ({
        id: a.id,
        uniqueId: a.unique_id,
        code: a.code,
        name: a.name,
        description: a.description,
        assetType: a.asset_type,
        serialNumber: a.serial_number,
        model: a.model,
        manufacturer: a.manufacturer,
        purchaseDate: a.purchase_date ? new Date(a.purchase_date) : undefined,
        purchasePrice: a.purchase_price,
        currentValue: a.current_value,
        locationUniqueId: a.location_unique_id,
        assignedToUniqueId: a.assigned_to_unique_id,
        status: a.status,
        enabled: a.enabled ?? true,
        payload: a.payload,
        tags: a.tags,
        createdAt: new Date(a.created_at),
        updatedAt: new Date(a.updated_at),
      }));
    },

    async listOwnership(uniqueId: string): Promise<UserOwnership[]> {
      const response = await transport.get<any>(`/users/${uniqueId}/ownership`);
      return (response.ownerships || response || []).map((o: any) => ({
        uniqueId: o.unique_id,
        assetUniqueId: o.asset_unique_id,
        userUniqueId: o.user_unique_id,
        ownershipType: o.ownership_type,
        acquiredAt: new Date(o.acquired_at),
        transferredAt: o.transferred_at ? new Date(o.transferred_at) : undefined,
        payload: o.payload,
      }));
    },
  };
}
