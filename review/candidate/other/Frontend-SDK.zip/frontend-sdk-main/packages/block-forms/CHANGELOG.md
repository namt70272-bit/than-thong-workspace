## 5.0.2 (2026-03-03)

### 🧱 Updated Dependencies

- Updated @23blocks/jsonapi-codec to 3.3.2
- Updated @23blocks/contracts to 2.3.2

## 5.0.1 (2026-02-20)

### 🩹 Fixes

- **@23blocks/block-forms:** remove stale re-exports of FormReference and SubmitFormInstanceRequest ([e26f5dc](https://github.com/23blocks-OS/frontend-sdk/commit/e26f5dc))

### ❤️ Thank You

- Claude Opus 4.6
- Juan Pelaez

# 5.0.0 (2026-02-20)

### 🩹 Fixes

- ⚠️  **@23blocks/block-forms:** align all types, services and mappers with API strong params ([31ead5f](https://github.com/23blocks-OS/frontend-sdk/commit/31ead5f))

### ⚠️  Breaking Changes

- **@23blocks/block-forms:** align all types, services and mappers with API strong params  ([31ead5f](https://github.com/23blocks-OS/frontend-sdk/commit/31ead5f))
  Complete rewrite of forms block to match actual Rails API.
  Root keys fixed: landing_instance→landing, survey_instance→survey,
  mail_template→template, form_submission→responses, report→query_params.
  Field renames: phone→phoneNumber, scheduledAt→startAt, schema→formFields,
  uiSchema→datasource, subject→fromSubject, htmlContent→templateHtml,
  textContent→templateText, providerTemplateId→templateName, fromEmail→fromAddress.
  Removed invented fields: FormReference, SubmitFormInstanceRequest,
  referrerEmail, refereeName, refereePhone, data (on instances), enabled (on Form).
  Added 80+ missing fields across all services including source tracking,
  visitor attribution, assigned-to fields, form configuration options,
  and CRM sync batch parameters.
  Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

### ❤️ Thank You

- Claude Opus 4.6
- Juan Pelaez

# 4.0.0 (2026-02-20)

### 🩹 Fixes

- ⚠️  replace appId with apiKey across all block configs to align with BlockConfig contract ([f81626d](https://github.com/23blocks-OS/frontend-sdk/commit/f81626d))
- resolve typecheck errors across all block packages ([6089324](https://github.com/23blocks-OS/frontend-sdk/commit/6089324))

### ⚠️  Breaking Changes

- replace appId with apiKey across all block configs to align with BlockConfig contract  ([f81626d](https://github.com/23blocks-OS/frontend-sdk/commit/f81626d))
  Block config no longer accepts appId. Use apiKey instead.
  Co-Authored-By: Claude Opus 4.6 <noreply@anthropic.com>

### 🧱 Updated Dependencies

- Updated @23blocks/jsonapi-codec to 3.3.1
- Updated @23blocks/contracts to 2.3.1

### ❤️ Thank You

- Claude Opus 4.6
- Juan Pelaez

## 3.3.0 (2026-02-17)

### 🚀 Features

- add health() method to all 18 blocks for service connectivity checks ([73514a3](https://github.com/23blocks-OS/frontend-sdk/commit/73514a3))

### 🧱 Updated Dependencies

- Updated @23blocks/jsonapi-codec to 3.3.0
- Updated @23blocks/contracts to 2.3.0

### ❤️ Thank You

- Claude Opus 4.6
- Juan Pelaez

## 3.2.0 (2026-02-08)

### 🚀 Features

- add comprehensive JSDoc documentation and llms.txt for AI agent consumption ([fd97df2](https://github.com/23blocks-OS/frontend-sdk/commit/fd97df2))

### 🧱 Updated Dependencies

- Updated @23blocks/jsonapi-codec to 3.2.0
- Updated @23blocks/contracts to 2.2.0

### ❤️ Thank You

- Claude Opus 4.6
- Juan Pelaez

## 3.1.9 (2026-02-07)

### 🧱 Updated Dependencies

- Updated @23blocks/jsonapi-codec to 3.1.3
- Updated @23blocks/contracts to 2.1.3

## 3.1.8 (2026-02-06)

### 🧱 Updated Dependencies

- Updated @23blocks/jsonapi-codec to 3.1.2
- Updated @23blocks/contracts to 2.1.2

## 3.1.7 (2026-01-20)

### 🩹 Fixes

- resolve TypeScript errors and add PostTemplate validation support ([250d284](https://github.com/23blocks-OS/frontend-sdk/commit/250d284))

### 🧱 Updated Dependencies

- Updated @23blocks/jsonapi-codec to 3.1.1
- Updated @23blocks/contracts to 2.1.1

### ❤️ Thank You

- Claude Opus 4.5
- Juan Pelaez

## 3.1.6 (2026-01-16)

### 🩹 Fixes

- **mappers:** remove dangerous uniqueId fallback to resource.id ([e96c555](https://github.com/23blocks-OS/frontend-sdk/commit/e96c555))

### ❤️ Thank You

- Claude Opus 4.5
- Juan Pelaez

## 3.1.5 (2026-01-13)

### 🚀 Features

- **forms,crm:** add OTP verification for public forms and document expiration tracking ([426b87d](https://github.com/23blocks-OS/frontend-sdk/commit/426b87d))

### ❤️ Thank You

- Claude Opus 4.5
- Juan Pelaez

## 3.1.4 (2026-01-05)

### 🩹 Fixes

- **forms:** rename create to submit for landing and subscription forms ([7c7126f](https://github.com/23blocks-OS/frontend-sdk/commit/7c7126f))

### ❤️ Thank You

- Claude Opus 4.5
- Juan Pelaez

## 3.1.3 (2026-01-05)

### 🚀 Features

- ⚠️  **forms:** rename publicForms to applicationForms ([0c5cad6](https://github.com/23blocks-OS/frontend-sdk/commit/0c5cad6))

### ⚠️  Breaking Changes

- **forms:** rename publicForms to applicationForms  ([0c5cad6](https://github.com/23blocks-OS/frontend-sdk/commit/0c5cad6))
  publicForms renamed to applicationForms
  🤖 Generated with [Claude Code](https://claude.com/claude-code)
  Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>

### ❤️ Thank You

- Claude Opus 4.5
- Juan Pelaez

## 3.1.2 (2026-01-04)

### 🩹 Fixes

- **block-forms:** export all types, services, and mappers ([d43b143](https://github.com/23blocks-OS/frontend-sdk/commit/d43b143))

### ❤️ Thank You

- Claude Opus 4.5
- Juan Pelaez

## 3.1.1 (2026-01-04)

### 🚀 Features

- ⚠️  **block-forms:** complete Forms API with all missing endpoints ([93bd809](https://github.com/23blocks-OS/frontend-sdk/commit/93bd809))

### ⚠️  Breaking Changes

- **block-forms:** complete Forms API with all missing endpoints  ([93bd809](https://github.com/23blocks-OS/frontend-sdk/commit/93bd809))
  FormInstancesService and FormSchemasService now use
  nested routes requiring formUniqueId as first parameter
  New services:
  - FormSchemaVersionsService: full CRUD + publish for schema versions
  - CrmSyncService: CRM sync operations (sync, batch, retry, status)
  Updated services:
  - FormInstancesService: nested routes /forms/:id/instances/*
    - Added: start(), submit(), cancel(), resendMagicLink()
  - FormSchemasService: nested routes /forms/:id/schemas/*
  - FormSetsService: Added match() and autoAssign()
  All services now align with the backend API routes:
  - Forms: /forms/*
  - Schemas: /forms/:id/schemas/*
  - Schema Versions: /forms/:id/schemas/:id/versions/*
  - Instances: /forms/:id/instances/*
  - Form Sets: /form_sets/* (with match/auto_assign)
  - CRM Sync: /crm/*
  🤖 Generated with [Claude Code](https://claude.com/claude-code)
  Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>

### ❤️ Thank You

- Claude Opus 4.5
- Juan Pelaez

## 3.1.0 (2026-01-01)

### 🧱 Updated Dependencies

- Updated @23blocks/jsonapi-codec to 3.1.0
- Updated @23blocks/contracts to 2.1.0

## 3.0.2 (2025-12-31)

### 🩹 Fixes

- replace PATCH with PUT across all services ([6339334](https://github.com/23blocks-OS/frontend-sdk/commit/6339334))

### ❤️ Thank You

- Claude Opus 4.5
- Juan Pelaez

## 3.0.1 (2025-12-17)

### 🧱 Updated Dependencies

- Updated @23blocks/jsonapi-codec to 3.0.1
- Updated @23blocks/contracts to 2.0.1

# 3.0.0 (2025-12-17)

### 🧱 Updated Dependencies

- Updated @23blocks/jsonapi-codec to 3.0.0
- Updated @23blocks/contracts to 2.0.0

## 2.1.0 (2025-12-15)

### 🚀 Features

- expand SDK API coverage for Content, Files, Forms, Geolocation blocks ([8e5c709](https://github.com/23blocks-OS/frontend-sdk/commit/8e5c709))

### ❤️ Thank You

- Claude Opus 4.5
- Juan Pelaez

# 2.0.0 (2025-12-15)

### 🩹 Fixes

- ⚠️  wrap all API request parameters with correct Rails object keys ([192ad70](https://github.com/23blocks-OS/frontend-sdk/commit/192ad70))

### ⚠️  Breaking Changes

- wrap all API request parameters with correct Rails object keys  ([192ad70](https://github.com/23blocks-OS/frontend-sdk/commit/192ad70))
  All service methods now correctly wrap request bodies
  with Rails-expected parameter keys (e.g., `user:`, `contact:`, `order:`).
  This fixes the critical issue where API requests were failing validation
  because parameters were sent flat instead of wrapped.
  Affected blocks:
  - block-authentication: auth, users, guests, apps, subscriptions, api-keys, roles
  - block-crm: contacts, accounts, leads, opportunities, meetings, quotes
  - block-company: companies, departments, teams, team-members, quarters
  - block-content: posts, comments, categories, tags
  - block-products: products, cart, catalog
  - block-sales: orders, order-details, payments, subscriptions
  - block-conversations: messages, groups, draft-messages, notifications
  - block-wallet: wallets, authorization-codes
  - block-files: storage-files, entity-files, file-schemas
  - block-forms: forms, form-schemas, form-sets, form-instances
  - block-assets: assets, asset-events, asset-audits
  - block-campaigns: campaigns, campaign-media, audiences, landing-pages
  - block-geolocation: locations, addresses, areas, regions, routes, bookings, premises
  - block-rewards: rewards, coupons, loyalty, badges
  - block-onboarding: onboardings, flows, user-journeys, user-identities
  - block-university: courses, lessons, enrollments, assignments, submissions
  - block-jarvis: agents, prompts, workflows, conversations
  Consumer API remains unchanged - this is an internal fix.
  🤖 Generated with [Claude Code](https://claude.com/claude-code)
  Co-Authored-By: Claude Opus 4.5 <noreply@anthropic.com>

### 🧱 Updated Dependencies

- Updated @23blocks/jsonapi-codec to 2.0.0

### ❤️ Thank You

- Claude Opus 4.5
- Juan Pelaez

## 1.0.4 (2025-12-14)

### 🧱 Updated Dependencies

- Updated @23blocks/jsonapi-codec to 1.0.4
- Updated @23blocks/contracts to 1.0.4

## 1.0.3 (2025-12-14)

### 🧱 Updated Dependencies

- Updated @23blocks/jsonapi-codec to 1.0.3
- Updated @23blocks/contracts to 1.0.3

## 1.0.2 (2025-12-14)

### 🧱 Updated Dependencies

- Updated @23blocks/jsonapi-codec to 1.0.2
- Updated @23blocks/contracts to 1.0.2

## 1.0.1 (2025-12-14)

### 🧱 Updated Dependencies

- Updated @23blocks/jsonapi-codec to 1.0.1
- Updated @23blocks/contracts to 1.0.1

# 1.0.0 (2025-12-13)

### 🧱 Updated Dependencies

- Updated @23blocks/jsonapi-codec to 1.0.0
- Updated @23blocks/contracts to 1.0.0

## 0.2.1 (2025-12-13)

### 🧱 Updated Dependencies

- Updated @23blocks/jsonapi-codec to 0.1.2
- Updated @23blocks/contracts to 0.1.2

## 0.2.0 (2025-12-13)

### 🚀 Features

- add all block packages with React and Angular bindings ([bbeecf7](https://github.com/23blocks-OS/frontend-sdk/commit/bbeecf7))

### 🧱 Updated Dependencies

- Updated @23blocks/jsonapi-codec to 0.1.1
- Updated @23blocks/contracts to 0.1.1

### ❤️ Thank You

- Claude Opus 4.5
- Juan Pelaez