import { scSend } from 'serverchan-sdk';
import type { IExecuteFunctions } from 'n8n-workflow';

/**
 * 隐藏 SendKey 中间部分，保护隐私
 * @param sendKey - 完整的 SendKey
 * @returns 脱敏后的 SendKey
 */
function maskSendKey(sendKey: string): string {
	if (sendKey.length <= 10) {
		return '****';
	}
	return sendKey.slice(0, 8) + '****' + sendKey.slice(-4);
}

/**
 * 发送消息到 Server酱
 * @param sendKeys - SendKey 数组
 * @param title - 消息标题
 * @param desp - 消息内容
 * @param options - 可选参数 (tags, short 等)
 * @returns 发送结果
 */
export async function sendToServerChan(
	this: IExecuteFunctions,
	sendKeys: string[],
	title: string,
	desp: string = '',
	options: any = {},
): Promise<any> {
	// 并行发送到所有 SendKey
	const promises = sendKeys.map(async (sendKey) => {
		try {
			const result = await scSend(sendKey, title, desp, options);
			return {
				sendKey: maskSendKey(sendKey),
				success: true,
				...result,
			};
		} catch (error: any) {
			return {
				sendKey: maskSendKey(sendKey),
				success: false,
				error: error?.message || String(error),
			};
		}
	});

	const results = await Promise.all(promises);

	// 统计成功/失败数量
	const successCount = results.filter((r) => r.success).length;
	const failureCount = results.filter((r) => !r.success).length;

	return {
		results,
		summary: {
			total: sendKeys.length,
			success: successCount,
			failure: failureCount,
		},
	};
}
