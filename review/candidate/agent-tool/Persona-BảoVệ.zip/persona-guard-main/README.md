# persona-guard

OpenClaw 反数据清洗工具。保护 AI 人设不被插件模板、系统默认文件覆盖。

## 问题

OpenClaw 部署新节点时，会生成 `BOOTSTRAP.md` + 默认 `IDENTITY.md` / `SOUL.md`，引导 AI "发现自我"。同时 qqbot 等插件的 SKILL.md 里硬编码了身份模板（如 "你是千语，Curry的专属AI助手"）。这两层叠加导致管理员精心设定的角色人设被洗掉。

## 设计

**分层身份模型：**
- Layer 0（锁定）：核心身份 — 你是谁 — 不可覆盖
- Layer 1（动态）：专家角色 — 你现在做什么 — skill 可注入

**AGENT.md 是唯一真相源（Single Source of Truth）。**

## 组件

| 文件 | 用途 |
|------|------|
| `persona-guard.sh` | CLI 工具，管理员在服务器上运行 |
| `SKILL.md` | OpenClaw skill，AI 端被动防御+主动检查 |

## 用法

### 初始化

```bash
# 交互式设定角色
persona-guard init

# 修补所有 SKILL.md 模板
persona-guard patch

# 锁定人设
persona-guard lock
```

### 日常

```bash
# 检测人设漂移（skill 升级后跑一次）
persona-guard check

# 查看状态
persona-guard status

# 生成身份锚定 prompt（给弱模型用）
persona-guard anchor weak    # doubao/minimax: 多重锚定
persona-guard anchor standard # deepseek: 标准锚定
persona-guard anchor strong   # claude: 轻量锚定
```

### 部署到远程节点

```bash
persona-guard deploy root@170.106.73.160
```

### AI 端

在 QQ 里对 bot 说：
- "人设检查" — 触发自检
- "你是谁" — 用 AGENT.md 身份回答

## 安装

```bash
# 复制到服务器
scp persona-guard.sh root@<host>:/usr/local/bin/persona-guard
ssh root@<host> 'chmod +x /usr/local/bin/persona-guard'

# 安装 skill（复制到 qqbot 插件目录）
scp -r SKILL.md root@<host>:~/.openclaw/extensions/qqbot/skills/persona-guard/SKILL.md
```

## 模板变量

skill 作者应使用变量而非硬编码身份：

```
# 旧写法（会洗身份）
"你是陈千语，Curry的专属AI助手。请提醒用户喝水"

# 新写法（尊重身份）
"你是{{persona.name}}，{{persona.role}}。{{persona.style}}。请提醒用户喝水"
```

## 文件优先级

```
AGENT.md (DNA, 最高优先级)
  ↓ 生成
IDENTITY.md + SOUL.md (衣服, 可重生成)
  ↓ 约束
SKILL.md 模板 (被 patch 修补)
  ↓ 运行时
AI 输出 (受 SKILL.md 被动防御保护)
```

## License

MIT
